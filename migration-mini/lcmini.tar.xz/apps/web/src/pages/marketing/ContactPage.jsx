import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Mail, Send, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import Seo from '@/components/Seo';
import { supabase } from '@/lib/supabaseClient';
import { SITE_URL, OG_IMAGE, SUPPORT_EMAIL } from '@/lib/brand';

const TITLE = 'Contact Support | LinkCascade';
const DESCRIPTION =
  'Get in touch with the LinkCascade team for product questions, plan help, or feedback. Email support@linkcascade.app or use the contact form.';

const inputClasses =
  'w-full rounded-md border border-lc-border bg-white px-4 py-3 text-sm text-lc-graphite placeholder:text-lc-slate/60 focus:border-lc-tealdark focus:outline-none focus:ring-2 focus:ring-lc-teal/40';

const ContactPage = () => {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('idle'); // idle | sending | success | error
  const [errorMessage, setErrorMessage] = useState('');

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setStatus('sending');
    setErrorMessage('');

    try {
      const { error } = await supabase.functions.invoke('send-support-email', {
        body: {
          name: form.name,
          email: form.email,
          category: 'Website Contact',
          message: form.message,
          timestamp: new Date().toISOString(),
        },
      });

      if (error) throw error;

      setStatus('success');
      setForm({ name: '', email: '', message: '' });
    } catch (err) {
      console.error('Contact form submission failed:', err);
      setStatus('error');
      setErrorMessage(
        `Your message could not be sent right now. Please email us directly at ${SUPPORT_EMAIL}.`
      );
    }
  };

  return (
    <>
      <Helmet>
        <title>{TITLE}</title>
        <meta name="description" content={DESCRIPTION} />
      </Helmet>
      <Seo title={TITLE} description={DESCRIPTION} image={OG_IMAGE} url={`${SITE_URL}/contact`} />

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <p className="font-serif text-lg italic text-lc-tealdark">Contact</p>
          <h1 className="mt-3 max-w-3xl text-4xl font-extrabold tracking-tight text-lc-graphite md:text-5xl">
            Contact us
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-lc-slate">
            Questions about the product, plans, or your account? Send us a message and we will get back to you by
            email.
          </p>
        </div>
      </section>

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto grid max-w-6xl gap-12 px-6 py-16 lg:grid-cols-2">
          <div>
            <div className="rounded-xl border-2 border-lc-graphite bg-white p-6 shadow-[6px_6px_0_0_#0B1318]">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-md bg-lc-teal">
                <Mail className="h-5 w-5 text-lc-graphite" aria-hidden="true" />
              </span>
              <h2 className="mt-4 text-lg font-bold text-lc-graphite">Email us directly</h2>
              <p className="mt-2 text-sm leading-relaxed text-lc-slate">
                For product questions, plan help, feedback, or anything else:
              </p>
              <p className="mt-4">
                <a
                  href={`mailto:${SUPPORT_EMAIL}`}
                  className="text-lg font-semibold text-lc-tealdark underline-offset-4 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-lc-tealdark"
                >
                  {SUPPORT_EMAIL}
                </a>
              </p>
            </div>
            <p className="mt-6 text-sm leading-relaxed text-lc-slate">
              Already have an account? You can also reach support from the support widget inside the app.
            </p>
          </div>

          <div>
            <form onSubmit={handleSubmit} className="rounded-xl border-2 border-lc-graphite bg-white p-6 shadow-[6px_6px_0_0_#0B1318]">
              <h2 className="text-lg font-bold text-lc-graphite">Send a message</h2>

              <div className="mt-6 space-y-5">
                <div className="grid gap-2">
                  <label htmlFor="contact-name" className="text-sm font-semibold text-lc-graphite">
                    Name
                  </label>
                  <input
                    id="contact-name"
                    name="name"
                    type="text"
                    required
                    autoComplete="name"
                    value={form.name}
                    onChange={handleChange}
                    className={inputClasses}
                    placeholder="Your name"
                  />
                </div>

                <div className="grid gap-2">
                  <label htmlFor="contact-email" className="text-sm font-semibold text-lc-graphite">
                    Email address
                  </label>
                  <input
                    id="contact-email"
                    name="email"
                    type="email"
                    required
                    autoComplete="email"
                    value={form.email}
                    onChange={handleChange}
                    className={inputClasses}
                    placeholder="you@example.com"
                  />
                </div>

                <div className="grid gap-2">
                  <label htmlFor="contact-message" className="text-sm font-semibold text-lc-graphite">
                    Message
                  </label>
                  <textarea
                    id="contact-message"
                    name="message"
                    required
                    rows={5}
                    value={form.message}
                    onChange={handleChange}
                    className={inputClasses}
                    placeholder="How can we help?"
                  />
                </div>
              </div>

              {status === 'success' && (
                <p role="status" className="mt-4 flex items-start gap-2 rounded-md bg-lc-teal/15 p-3 text-sm font-medium text-lc-tealdark">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                  Your message has been sent. We will reply to your email address.
                </p>
              )}
              {status === 'error' && (
                <p role="alert" className="mt-4 flex items-start gap-2 rounded-md bg-lc-coral/15 p-3 text-sm font-medium text-lc-graphite">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                  {errorMessage}
                </p>
              )}

              <button
                type="submit"
                disabled={status === 'sending'}
                className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-md bg-lc-teal px-6 py-3 text-base font-semibold text-lc-graphite transition-colors hover:bg-lc-teal/85 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {status === 'sending' ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                    Sending…
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" aria-hidden="true" />
                    Send Message
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;
