import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Check } from 'lucide-react';
import Seo from '@/components/Seo';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { PLAN_LIMITS, PRO_PAYMENT_LINK, AGENCY_PAYMENT_LINK } from '@/lib/constants';
import { SITE_URL, APP_SIGNUP_URL, OG_IMAGE } from '@/lib/brand';
import { cn } from '@/lib/utils';

const TITLE = 'Pricing Plans | LinkCascade';
const DESCRIPTION =
  'LinkCascade pricing: Free plan with 5 trackable links and 2 campaigns, Pro at $27/month, and Agency at $97/month with unlimited links and campaigns.';

const ctaTeal =
  'inline-flex w-full items-center justify-center rounded-md bg-lc-teal px-6 py-3 text-base font-semibold text-lc-graphite transition-colors hover:bg-lc-teal/85 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark active:scale-[0.98]';
const ctaOutline =
  'inline-flex w-full items-center justify-center rounded-md border-2 border-lc-graphite px-6 py-3 text-base font-semibold text-lc-graphite transition-colors hover:bg-lc-graphite hover:text-lc-offwhite focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark active:scale-[0.98]';

const plans = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    audience: 'For getting started with link tracking',
    limits: [
      `${PLAN_LIMITS.free.maxLinks} trackable links`,
      `${PLAN_LIMITS.free.maxCampaigns} campaigns`,
      `${PLAN_LIMITS.free.maxTemplates} custom templates`,
    ],
    features: ['Click tracking on every link', 'Basic analytics', 'Manual earnings tracking'],
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 27,
    audience: 'For power users and creators',
    popular: true,
    limits: [
      `${PLAN_LIMITS.pro.maxLinks} trackable links`,
      `${PLAN_LIMITS.pro.maxCampaigns} campaigns`,
      'Unlimited custom templates',
    ],
    features: [
      'Everything in Free',
      'Advanced analytics',
      'Lead capture and lead attribution',
      'CSV exports',
      'Priority support',
    ],
  },
  {
    id: 'agency',
    name: 'Agency',
    price: 97,
    audience: 'For teams and organizations',
    limits: ['Unlimited trackable links', 'Unlimited campaigns', 'Unlimited custom templates'],
    features: [
      'Everything in Pro',
      'Lead capture API access',
      'White-label reports',
      'Priority support',
    ],
  },
];

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Product',
  name: 'LinkCascade',
  description:
    'An easy link-tracking and campaign-organization platform for creators, affiliates, consultants, agencies, and small businesses.',
  brand: { '@type': 'Organization', name: 'LinkCascade', url: `${SITE_URL}/` },
  offers: plans.map((plan) => ({
    '@type': 'Offer',
    name: `LinkCascade ${plan.name}`,
    price: plan.price.toFixed(2),
    priceCurrency: 'USD',
    url: `${SITE_URL}/pricing`,
    availability: 'https://schema.org/InStock',
  })),
};

const Pricing = () => {
  const { user, userProfile } = useAuth();
  const currentPlan = userProfile?.plan || 'free';

  const renderCta = (plan) => {
    if (user) {
      if (currentPlan === plan.id) {
        return (
          <span className="inline-flex w-full cursor-default items-center justify-center rounded-md bg-lc-graphite/10 px-6 py-3 text-base font-semibold text-lc-slate">
            Current Plan
          </span>
        );
      }
      if (plan.id === 'free') {
        return (
          <Link to="/dashboard" className={ctaOutline}>
            Go to Dashboard
          </Link>
        );
      }
      const stripeUrl = plan.id === 'pro' ? PRO_PAYMENT_LINK : AGENCY_PAYMENT_LINK;
      return (
        <a href={stripeUrl} data-stripe-link={stripeUrl} target="_self" className={plan.id === 'pro' ? ctaTeal : ctaOutline}>
          Upgrade to {plan.name}
        </a>
      );
    }

    return (
      <a href={APP_SIGNUP_URL} className={plan.id === 'pro' ? ctaTeal : ctaOutline}>
        {plan.id === 'free' ? 'Start Free' : `Get Started with ${plan.name}`}
      </a>
    );
  };

  return (
    <>
      <Helmet>
        <title>{TITLE}</title>
        <meta name="description" content={DESCRIPTION} />
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      </Helmet>
      <Seo title={TITLE} description={DESCRIPTION} image={OG_IMAGE} url={`${SITE_URL}/pricing`} />

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-16 text-center">
          <p className="font-serif text-lg italic text-lc-tealdark">Pricing</p>
          <h1 className="mx-auto mt-3 max-w-3xl text-4xl font-extrabold tracking-tight text-lc-graphite md:text-5xl">
            Plans that grow with your links
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-lc-slate">
            Start free and upgrade when you need more links, more campaigns, and deeper reporting. Every plan includes
            click tracking on every link you create.
          </p>
        </div>
      </section>

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <div className="grid gap-8 md:grid-cols-3">
            {plans.map((plan) => (
              <div
                key={plan.id}
                className={cn(
                  'relative flex flex-col rounded-xl border-2 border-lc-graphite bg-white p-8',
                  plan.popular ? 'shadow-[8px_8px_0_0_#00C2B8]' : 'shadow-[8px_8px_0_0_#0B1318]'
                )}
              >
                {plan.popular && (
                  <span className="absolute -top-3.5 left-6 rounded-full bg-lc-coral px-3 py-1 text-xs font-bold uppercase tracking-wide text-lc-graphite">
                    Popular
                  </span>
                )}
                <h2 className="text-xl font-extrabold text-lc-graphite">{plan.name}</h2>
                <p className="mt-1 text-sm text-lc-slate">{plan.audience}</p>
                <p className="mt-5 text-4xl font-extrabold text-lc-graphite">
                  ${plan.price}
                  <span className="ml-1 text-base font-medium text-lc-slate">/month</span>
                </p>

                <div className="mt-6 border-t-2 border-lc-graphite pt-5">
                  <h3 className="text-xs font-semibold uppercase tracking-widest text-lc-slate">Included limits</h3>
                  <ul className="mt-3 space-y-2">
                    {plan.limits.map((limit) => (
                      <li key={limit} className="flex items-start gap-2 text-sm text-lc-graphite">
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-lc-tealdark" aria-hidden="true" />
                        {limit}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-5 flex-1">
                  <h3 className="text-xs font-semibold uppercase tracking-widest text-lc-slate">Features</h3>
                  <ul className="mt-3 space-y-2">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2 text-sm text-lc-graphite">
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-lc-tealdark" aria-hidden="true" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-8">{renderCta(plan)}</div>
              </div>
            ))}
          </div>

          <p className="mx-auto mt-12 max-w-2xl text-center text-sm leading-relaxed text-lc-slate">
            Paid plans are billed securely through Stripe. Create your free account first, then upgrade from inside the
            app at any time. Questions about plans?{' '}
            <Link to="/faq" className="font-semibold text-lc-tealdark underline-offset-4 hover:underline">
              Read the FAQ
            </Link>{' '}
            or{' '}
            <Link to="/contact" className="font-semibold text-lc-tealdark underline-offset-4 hover:underline">
              contact us
            </Link>
            .
          </p>
        </div>
      </section>
    </>
  );
};

export default Pricing;
