import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Seo from '@/components/Seo';
import DashboardMockup from '@/components/marketing/DashboardMockup';
import { SITE_URL, APP_SIGNUP_URL, OG_IMAGE } from '@/lib/brand';

const TITLE = 'How LinkCascade Works | LinkCascade';
const DESCRIPTION =
  'Create a trackable link, add it to a campaign, share it through your channels, and review clicks, captured leads, and recorded results in LinkCascade.';

const steps = [
  {
    n: '1',
    title: 'Create a trackable link',
    text: 'Paste any destination URL into the Link Vault and LinkCascade gives you a short, trackable link. Give it a clear title so you can recognize it later.',
  },
  {
    n: '2',
    title: 'Add it to a campaign',
    text: 'Group the link into a campaign—by launch, client, product, or channel—so related links stay organized and easy to compare.',
  },
  {
    n: '3',
    title: 'Share it through your channels',
    text: 'Post your short link on social media, in email newsletters, on your website, in direct messages, or in advertisements. Every open is recorded automatically.',
  },
  {
    n: '4',
    title: 'Review your results',
    text: 'Open your dashboard to review clicks, captured leads, recorded sales, and other available results—per link and per campaign, over the date range you choose.',
  },
];

const ctaPrimary =
  'inline-flex items-center justify-center rounded-md bg-lc-teal px-6 py-3 text-base font-semibold text-lc-graphite transition-colors hover:bg-lc-teal/85 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark active:scale-[0.98]';

const HowItWorksPage = () => {
  return (
    <>
      <Helmet>
        <title>{TITLE}</title>
        <meta name="description" content={DESCRIPTION} />
      </Helmet>
      <Seo title={TITLE} description={DESCRIPTION} image={OG_IMAGE} url={`${SITE_URL}/how-it-works`} />

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <p className="font-serif text-lg italic text-lc-tealdark">How it works</p>
          <h1 className="mt-3 max-w-3xl text-4xl font-extrabold tracking-tight text-lc-graphite md:text-5xl">
            From shared link to measurable result in four steps
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-lc-slate">
            LinkCascade is an easy link-tracking and campaign-organization platform. There is no complicated setup:
            create a link, share it, and watch the activity come in.
          </p>
        </div>
      </section>

      <section className="border-b-2 border-lc-graphite bg-white">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <ol className="space-y-0">
            {steps.map((step, index) => (
              <li
                key={step.n}
                className="grid gap-4 border-t-2 border-lc-graphite py-10 md:grid-cols-12 md:gap-10"
              >
                <div className="md:col-span-2">
                  <p className="font-serif text-5xl italic text-lc-tealdark">{step.n}</p>
                </div>
                <div className="md:col-span-6">
                  <h2 className="text-2xl font-extrabold tracking-tight text-lc-graphite">{step.title}</h2>
                  <p className="mt-3 max-w-xl leading-relaxed text-lc-slate">{step.text}</p>
                </div>
                <div className="hidden md:col-span-4 md:block">
                  {index === 3 ? (
                    <DashboardMockup caption="Your results, in one dashboard" />
                  ) : (
                    <div className="flex h-full items-center justify-center rounded-xl border-2 border-dashed border-lc-border bg-lc-offwhite p-6">
                      <p className="text-center font-serif text-lg italic text-lc-slate">
                        {index === 0 && 'linkcascade.app/go/your-link'}
                        {index === 1 && 'Campaign: Spring Launch'}
                        {index === 2 && 'Social · Email · Web · Messages · Ads'}
                      </p>
                    </div>
                  )}
                </div>
              </li>
            ))}
          </ol>

          <div className="mt-8 rounded-xl border-2 border-lc-graphite bg-lc-offwhite p-6 shadow-[6px_6px_0_0_#0B1318]">
            <h2 className="text-lg font-bold text-lc-graphite">What gets recorded automatically—and what does not</h2>
            <p className="mt-3 text-sm leading-relaxed text-lc-slate">
              Clicks and leads captured through LinkCascade lead forms are recorded automatically. Sales and earnings
              figures come from what you record in your account. LinkCascade does not automatically know your affiliate
              commissions or external earnings unless you record them or supply them through a supported method.
            </p>
          </div>

          <div className="mt-12 flex flex-wrap items-center gap-4">
            <a href={APP_SIGNUP_URL} className={ctaPrimary}>
              Start Free
            </a>
            <Link
              to="/features"
              className="font-semibold text-lc-tealdark underline-offset-4 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-lc-tealdark"
            >
              See the full feature list
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default HowItWorksPage;
