import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Check, MessageSquare } from 'lucide-react';
import Seo from '@/components/Seo';
import DashboardMockup from '@/components/marketing/DashboardMockup';
import { SITE_URL, APP_SIGNUP_URL, OG_IMAGE, SUPPORT_EMAIL } from '@/lib/brand';

const TITLE = 'Early Access: Built for Practical Link Tracking | LinkCascade';
const DESCRIPTION =
  'LinkCascade is in early access. See real product previews, verified capabilities, and example workflows—and help shape what gets built next.';

const ctaPrimary =
  'inline-flex items-center justify-center rounded-md bg-lc-teal px-6 py-3 text-base font-semibold text-lc-graphite transition-colors hover:bg-lc-teal/85 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark active:scale-[0.98]';

const capabilities = [
  'Create short, trackable links and organize them in the Link Vault',
  'Group links into campaigns by launch, client, or channel',
  'See clicks recorded automatically, with date-range analytics',
  'Capture leads through built-in lead forms on supported plans',
  'Record earnings by source and export them to CSV',
  'Save message templates and generate outreach copy',
];

const workflows = [
  {
    label: 'Example workflow',
    title: 'A creator tracking bio links',
    text: 'A creator shares one short link per platform—one in a bio, one in a newsletter, one in a video description—and compares which placements actually produce clicks and captured leads.',
  },
  {
    label: 'Example workflow',
    title: 'A consultant comparing channels',
    text: 'A consultant puts the same offer into two campaigns—one for email, one for social—and uses per-campaign results to decide where to spend the next hour of outreach.',
  },
  {
    label: 'Example workflow',
    title: 'An affiliate organizing offers',
    text: 'An affiliate groups every offer link into campaigns by product, records earnings as they arrive, and reviews which links produced meaningful engagement before renewing promotions.',
  },
];

const EarlyAccessPage = () => {
  return (
    <>
      <Helmet>
        <title>{TITLE}</title>
        <meta name="description" content={DESCRIPTION} />
      </Helmet>
      <Seo title={TITLE} description={DESCRIPTION} image={OG_IMAGE} url={`${SITE_URL}/early-access`} />

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <p className="font-serif text-lg italic text-lc-tealdark">Early access</p>
          <h1 className="mt-3 max-w-3xl text-4xl font-extrabold tracking-tight text-lc-graphite md:text-5xl">
            Built for practical link tracking
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-lc-slate">
            LinkCascade is in early access. Instead of quoting numbers we cannot verify, we would rather show you the
            product itself—what it does today, and how people like you might use it.
          </p>
          <div className="mt-8">
            <a href={APP_SIGNUP_URL} className={ctaPrimary}>
              Start Free
            </a>
          </div>
        </div>
      </section>

      <section className="border-b-2 border-lc-graphite bg-white">
        <div className="mx-auto grid max-w-6xl items-start gap-12 px-6 py-20 lg:grid-cols-2">
          <div>
            <h2 className="text-3xl font-extrabold tracking-tight text-lc-graphite">What the product does today</h2>
            <ul className="mt-8 space-y-4">
              {capabilities.map((capability) => (
                <li key={capability} className="flex items-start gap-3 border-t-2 border-lc-graphite pt-4">
                  <Check className="mt-1 h-4 w-4 shrink-0 text-lc-tealdark" aria-hidden="true" />
                  <span className="leading-relaxed text-lc-slate">{capability}</span>
                </li>
              ))}
            </ul>
            <p className="mt-8 text-sm text-lc-slate">
              Every capability listed here is available in the product right now.{' '}
              <Link to="/features" className="font-semibold text-lc-tealdark underline-offset-4 hover:underline">
                See the full feature list
              </Link>
              .
            </p>
          </div>
          <DashboardMockup float caption="The LinkCascade dashboard — stylized product preview" />
        </div>
      </section>

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <h2 className="text-3xl font-extrabold tracking-tight text-lc-graphite">How people might use it</h2>
          <p className="mt-4 max-w-2xl text-lg text-lc-slate">
            These are illustrative workflows, not customer stories—examples of how the product is designed to be used.
          </p>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {workflows.map((workflow) => (
              <div
                key={workflow.title}
                className="rounded-xl border-2 border-lc-graphite bg-white p-6 shadow-[6px_6px_0_0_#0B1318]"
              >
                <p className="text-xs font-semibold uppercase tracking-widest text-lc-coral">{workflow.label}</p>
                <h3 className="mt-3 text-lg font-bold text-lc-graphite">{workflow.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-lc-slate">{workflow.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-lc-graphite text-lc-offwhite">
        <div className="mx-auto max-w-6xl px-6 py-20 text-center">
          <MessageSquare className="mx-auto h-8 w-8 text-lc-teal" aria-hidden="true" />
          <h2 className="mx-auto mt-4 max-w-2xl text-3xl font-extrabold tracking-tight md:text-4xl">
            Early users shape the roadmap
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-lc-offwhite/75">
            Try LinkCascade free and tell us what would make it more useful for the way you share links. We read every
            message at{' '}
            <a href={`mailto:${SUPPORT_EMAIL}`} className="text-lc-teal underline-offset-4 hover:underline">
              {SUPPORT_EMAIL}
            </a>{' '}
            or through the{' '}
            <Link to="/contact" className="text-lc-teal underline-offset-4 hover:underline">
              contact page
            </Link>
            .
          </p>
          <div className="mt-8">
            <a href={APP_SIGNUP_URL} className={ctaPrimary}>
              Start Free
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default EarlyAccessPage;
