import React from 'react';
import TemplateCard from './TemplateCard';
import { Star } from 'lucide-react';

const FavoritesList = ({ customTemplates, featuredTemplates, onTemplateActions }) => {
  // Filter favorites
  const favoriteCustom = customTemplates.filter(t => t.is_favorite);
  const favoriteFeatured = featuredTemplates.filter(t => t.is_favorite); // Expecting parent to pass featured with is_favorite flag

  const hasFavorites = favoriteCustom.length > 0 || favoriteFeatured.length > 0;

  if (!hasFavorites) {
    return (
      <div className="text-center py-12 bg-gray-50 rounded-xl border-2 border-dashed border-gray-200">
        <div className="w-16 h-16 bg-yellow-50 rounded-full flex items-center justify-center mx-auto mb-4">
          <Star className="w-8 h-8 text-yellow-400 fill-yellow-400" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-1">No Favorites Yet</h3>
        <p className="text-gray-500 max-w-sm mx-auto">
          Star templates you use frequently to access them quickly here.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {favoriteCustom.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <span className="w-2 h-8 bg-lc-teal rounded-full"></span>
            My Favorite Templates
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favoriteCustom.map(template => (
              <TemplateCard
                key={template.id}
                template={template}
                isCustom={true}
                onEdit={onTemplateActions.onEdit}
                onDelete={onTemplateActions.onDelete}
                onMove={onTemplateActions.onMove}
                onToggleFavorite={onTemplateActions.onToggleFavorite}
              />
            ))}
          </div>
        </div>
      )}

      {favoriteFeatured.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <span className="w-2 h-8 bg-lc-tealdark rounded-full"></span>
            Featured Favorites
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favoriteFeatured.map(template => (
              <TemplateCard
                key={template.id}
                template={template}
                isCustom={false}
                onToggleFavorite={onTemplateActions.onToggleFavorite}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default FavoritesList;