import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/supabaseClient';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';

const SupportWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [userInfo, setUserInfo] = useState({ name: 'Anonymous', email: 'Not provided' });
  const [formData, setFormData] = useState({ category: '', message: '' });
  
  const { toast } = useToast();

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) throw error;
        
        if (session?.user) {
          setUserInfo({
            name: session.user.user_metadata?.full_name || 'Anonymous',
            email: session.user.email || 'Not provided',
          });
        } else {
          setUserInfo({ name: 'Anonymous', email: 'Not provided' });
        }
      } catch (error) {
        console.error('Error fetching user for support widget:', error);
        setUserInfo({ name: 'Anonymous', email: 'Not provided' });
      } finally {
        setIsLoading(false);
      }
    };

    fetchUser();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.category || !formData.message.trim()) {
      toast({
        title: "Validation Error",
        description: "Please select a category and enter a message.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const emailData = {
        name: userInfo.name,
        email: userInfo.email,
        category: formData.category,
        message: formData.message,
        timestamp: new Date().toISOString(),
      };

      const { data, error } = await supabase.functions.invoke('send-support-email', {
        body: emailData
      });

      if (error || (data && data.error)) throw error || new Error(data.error);

      setShowConfirmation(true);
      toast({
        title: "Success",
        description: "Your message has been sent successfully.",
      });

      setTimeout(() => {
        setIsOpen(false);
        setShowConfirmation(false);
        setFormData({ category: '', message: '' });
      }, 2000);

    } catch (error) {
      console.error('Support submission error:', error);
      toast({
        title: "Failed to send message",
        description: error.message || "An unexpected error occurred. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <div className="fixed bottom-6 right-6 z-[2147483647] group">
        <div className="absolute bottom-full right-0 mb-2 whitespace-nowrap bg-gray-900 text-white text-xs font-medium px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          Need Help?
          <div className="absolute -bottom-1 right-4 w-2 h-2 bg-gray-900 rotate-45"></div>
        </div>
        <button
          onClick={() => setIsOpen(true)}
          className="w-14 h-14 rounded-full bg-lc-teal hover:bg-lc-tealdark text-lc-graphite shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center group"
          aria-label="Open support"
        >
          <MessageCircle className="w-6 h-6" />
        </button>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[425px] overflow-hidden z-[2147483647]">
          <AnimatePresence mode="wait">
            {showConfirmation ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="flex flex-col items-center justify-center py-12 text-center"
              >
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle2 className="w-8 h-8 text-green-500" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Message Sent!</h3>
                <p className="text-gray-500">Thanks for helping us improve LinkCascade.</p>
              </motion.div>
            ) : (
              <motion.div
                key="form"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
              >
                <DialogHeader>
                  <DialogTitle>We're Listening</DialogTitle>
                  <DialogDescription>
                    Help us improve LinkCascade by sharing your feedback.
                  </DialogDescription>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                  {!isLoading && (
                    <div className="bg-gray-50 p-3 rounded-lg border border-gray-100 flex flex-col text-sm">
                      <span className="text-gray-900 font-medium">{userInfo.name}</span>
                      <span className="text-gray-500">{userInfo.email}</span>
                    </div>
                  )}

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">What can we help with? *</label>
                    <select
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none bg-white text-gray-900 transition-all"
                      required
                      disabled={isSubmitting}
                    >
                      <option value="" disabled>Select a category...</option>
                      <option value="Bug Report">Bug Report</option>
                      <option value="Feature Request">Feature Request</option>
                      <option value="General Question">General Question</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">Message *</label>
                    <textarea
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Tell us what's on your mind..."
                      rows={5}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none bg-white text-gray-900 transition-all resize-none"
                      required
                      disabled={isSubmitting}
                    />
                  </div>

                  <div className="flex items-center gap-3 pt-4">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsOpen(false)}
                      disabled={isSubmitting}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={isSubmitting}
                      className="flex-1 bg-green-500 hover:bg-green-600 text-white"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Sending...
                        </>
                      ) : (
                        'Submit'
                      )}
                    </Button>
                  </div>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default SupportWidget;