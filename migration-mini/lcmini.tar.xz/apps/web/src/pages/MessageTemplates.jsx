import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LayoutGrid, FileText, Folder, Star, Plus, Lock, Library } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { FEATURED_TEMPLATES } from '@/constants/templates';
import { PLAN_LIMITS } from '@/lib/constants';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

import TemplateCard from '@/components/TemplateCard';
import TemplateForm from '@/components/TemplateForm';
import FolderForm from '@/components/FolderForm';
import FolderList from '@/components/FolderList';
import FavoritesList from '@/components/FavoritesList';

const MessageTemplates = () => {
  const { user, userProfile } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState('custom');
  const [templates, setTemplates] = useState([]);
  const [folders, setFolders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [featuredFavorites, setFeaturedFavorites] = useState(() => JSON.parse(localStorage.getItem('featuredFavorites') || '[]'));
  
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [isFolderModalOpen, setIsFolderModalOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [editingFolder, setEditingFolder] = useState(null);
  const [selectedFolderId, setSelectedFolderId] = useState(null);

  const isPro = userProfile?.plan === 'pro' || userProfile?.plan === 'agency';
  const userPlan = userProfile?.plan || 'free';
  const maxTemplates = PLAN_LIMITS[userPlan]?.maxTemplates || 10;

  useEffect(() => { if (user) fetchData(); }, [user]);
  useEffect(() => { localStorage.setItem('featuredFavorites', JSON.stringify(featuredFavorites)); }, [featuredFavorites]);

  // Handle auto-open creation from Template Library
  useEffect(() => {
    if (location.state?.createFromTemplate) {
      const srcTpl = location.state.createFromTemplate;
      setEditingTemplate({
        title: srcTpl.title,
        body: srcTpl.body || srcTpl.content,
        platform: srcTpl.platform,
        tone: srcTpl.tone
      });
      setIsTemplateModalOpen(true);
      // Clear state to prevent reopening on reload
      window.history.replaceState({}, document.title);
    }
  }, [location]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [tRes, fRes] = await Promise.all([
        supabase.from('message_templates').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
        supabase.from('template_folders').select('*').eq('user_id', user.id).order('name', { ascending: true })
      ]);
      if (tRes.error) throw tRes.error;
      if (fRes.error) throw fRes.error;
      setTemplates(tRes.data);
      setFolders(fRes.data);
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to load templates.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveTemplate = async (data) => {
    try {
      // Check if editing existing template vs creating new (even from library it's new custom)
      if (editingTemplate && editingTemplate.id) {
        const { error } = await supabase.from('message_templates').update(data).eq('id', editingTemplate.id).eq('user_id', user.id);
        if (error) throw error;
        setTemplates(templates.map(t => t.id === editingTemplate.id ? { ...t, ...data } : t));
        toast({ title: 'Success', description: 'Template updated.' });
      } else {
        if (maxTemplates !== -1 && templates.length >= maxTemplates) {
          toast({ title: 'Limit Reached', description: 'Upgrade to Pro to create unlimited templates.', variant: 'destructive' });
          return;
        }
        const { data: newT, error } = await supabase.from('message_templates').insert([{ ...data, user_id: user.id }]).select().single();
        if (error) throw error;
        setTemplates([newT, ...templates]);
        toast({ title: 'Success', description: 'Template created.' });
        setActiveTab('custom');
      }
      setIsTemplateModalOpen(false); setEditingTemplate(null); setSelectedFolderId(null);
    } catch (e) { toast({ title: 'Error', description: 'Failed to save template.', variant: 'destructive' }); }
  };

  const handleDeleteTemplate = async (template) => {
    if (!confirm('Delete this template?')) return;
    try {
      const { error } = await supabase.from('message_templates').delete().eq('id', template.id);
      if (error) throw error;
      setTemplates(templates.filter(t => t.id !== template.id));
      toast({ title: 'Deleted', description: 'Template removed.' });
    } catch (e) { toast({ title: 'Error', description: 'Could not delete template.', variant: 'destructive' }); }
  };

  const handleToggleFavorite = async (template) => {
    if (template.id && !template.id.toString().startsWith('featured') && !template.id.toString().startsWith('sys')) {
      try {
        const newStatus = !template.is_favorite;
        const { error } = await supabase.from('message_templates').update({ is_favorite: newStatus }).eq('id', template.id);
        if (error) throw error;
        setTemplates(templates.map(t => t.id === template.id ? { ...t, is_favorite: newStatus } : t));
      } catch (e) { toast({ title: 'Error', description: 'Failed to update status.', variant: 'destructive' }); }
    } else {
      setFeaturedFavorites(featuredFavorites.includes(template.id) ? featuredFavorites.filter(id => id !== template.id) : [...featuredFavorites, template.id]);
    }
  };

  const handleSaveFolder = async (data) => {
    try {
      if (editingFolder) {
        const { error } = await supabase.from('template_folders').update(data).eq('id', editingFolder.id);
        if (error) throw error;
        setFolders(folders.map(f => f.id === editingFolder.id ? { ...f, ...data } : f));
      } else {
        const { data: newF, error } = await supabase.from('template_folders').insert([{ ...data, user_id: user.id }]).select().single();
        if (error) throw error;
        setFolders([...folders, newF]);
      }
      setIsFolderModalOpen(false); setEditingFolder(null);
    } catch (e) { toast({ title: 'Error', description: 'Failed to save folder.', variant: 'destructive' }); }
  };

  const handleDeleteFolder = async (folder) => {
    if (!confirm('Delete folder?')) return;
    try {
      await supabase.from('template_folders').delete().eq('id', folder.id);
      setFolders(folders.filter(f => f.id !== folder.id));
      setTemplates(templates.map(t => t.folder_id === folder.id ? { ...t, folder_id: null } : t));
    } catch (e) { toast({ title: 'Error', description: 'Could not delete folder.', variant: 'destructive' }); }
  };

  const featuredWithFavs = FEATURED_TEMPLATES.map(t => ({ ...t, is_favorite: featuredFavorites.includes(t.id) }));

  const tabs = [
    { id: 'custom', label: 'My Templates', icon: FileText },
    { id: 'folders', label: 'Folders', icon: Folder },
    { id: 'favorites', label: 'Favorites', icon: Star },
  ];

  return (
    <>
      <Helmet><title>Message Templates - LinkCascade</title></Helmet>
      
      <div className="p-6 md:p-8 max-w-7xl mx-auto min-h-screen">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Message Templates</h1>
            <p className="text-gray-500 mt-2">Manage your custom templates and folders.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => navigate('/template-library')} variant="outline" className="border-lc-border text-lc-tealdark hover:bg-lc-teal/10">
              <Library className="w-4 h-4 mr-2" /> Browse Library
            </Button>
            <Button onClick={() => { setEditingTemplate(null); setSelectedFolderId(null); setIsTemplateModalOpen(true); }} className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
              <Plus className="w-4 h-4 mr-2" /> New Template
            </Button>
            {isPro && <Button onClick={() => setIsFolderModalOpen(true)} variant="secondary" className="bg-lc-teal/10 text-lc-tealdark hover:bg-lc-teal/20"><Folder className="w-4 h-4 mr-2" /> New Folder</Button>}
          </div>
        </div>

        <div className="bg-white p-1 rounded-xl border border-gray-200 inline-flex mb-8 shadow-sm">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${isActive ? 'bg-lc-teal/10 text-lc-tealdark shadow-sm' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'}`}
              >
                <Icon className="w-4 h-4" /> {tab.label}
              </button>
            );
          })}
        </div>

        <div className="min-h-[400px]">
          {loading ? (
             <div className="flex justify-center py-20"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-lc-teal"></div></div>
          ) : (
            <AnimatePresence mode="wait">
              <motion.div key={activeTab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                {activeTab === 'custom' && (
                  templates.length === 0 ? (
                    <div className="text-center py-16 bg-white rounded-xl border border-dashed border-gray-200">
                      <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                      <h3 className="text-lg font-bold text-gray-900">No Custom Templates</h3>
                      <p className="text-gray-500 mb-6">Create your own templates or start from our library.</p>
                      <div className="flex justify-center gap-3">
                        <Button onClick={() => navigate('/template-library')} variant="outline">Browse Library</Button>
                        <Button onClick={() => setIsTemplateModalOpen(true)} className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">Create Custom</Button>
                      </div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {templates.map(t => (
                        <TemplateCard key={t.id} template={t} isCustom={true} 
                          onEdit={(t) => { setEditingTemplate(t); setIsTemplateModalOpen(true); }}
                          onDelete={handleDeleteTemplate}
                          onToggleFavorite={handleToggleFavorite}
                        />
                      ))}
                    </div>
                  )
                )}

                {activeTab === 'folders' && (
                  !isPro ? (
                     <div className="bg-lc-teal/10 border border-lc-border rounded-xl p-8 text-center">
                        <Lock className="w-8 h-8 text-lc-teal mx-auto mb-3" />
                        <h3 className="text-lg font-bold text-lc-graphite">Pro Feature</h3>
                        <p className="text-lc-slate mb-6">Upgrade to organize templates into folders.</p>
                        <Button onClick={() => navigate('/pricing')} className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">View Plans</Button>
                     </div>
                  ) : (
                    <FolderList 
                      folders={folders} templates={templates}
                      onEditFolder={(f) => { setEditingFolder(f); setIsFolderModalOpen(true); }}
                      onDeleteFolder={handleDeleteFolder}
                      onCreateTemplate={(id) => { setSelectedFolderId(id); setEditingTemplate(null); setIsTemplateModalOpen(true); }}
                      onTemplateActions={{
                        onEdit: (t) => { setEditingTemplate(t); setIsTemplateModalOpen(true); },
                        onDelete: handleDeleteTemplate,
                        onToggleFavorite: handleToggleFavorite
                      }}
                    />
                  )
                )}

                {activeTab === 'favorites' && (
                  <FavoritesList 
                    customTemplates={templates} featuredTemplates={featuredWithFavs}
                    onTemplateActions={{
                      onEdit: (t) => { setEditingTemplate(t); setIsTemplateModalOpen(true); },
                      onDelete: handleDeleteTemplate,
                      onToggleFavorite: handleToggleFavorite
                    }}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          )}
        </div>

        <Dialog open={isTemplateModalOpen} onOpenChange={setIsTemplateModalOpen}>
          <DialogContent className="max-w-2xl"><DialogHeader><DialogTitle>{editingTemplate ? 'Edit Template' : 'Create New Template'}</DialogTitle></DialogHeader>
            <TemplateForm 
              template={editingTemplate} 
              folders={folders} 
              onSubmit={handleSaveTemplate} 
              onCancel={() => setIsTemplateModalOpen(false)} 
              loading={loading} 
              initialFolderId={selectedFolderId}
              currentTemplateCount={templates.length}
            />
          </DialogContent>
        </Dialog>

        <Dialog open={isFolderModalOpen} onOpenChange={setIsFolderModalOpen}>
          <DialogContent><DialogHeader><DialogTitle>{editingFolder ? 'Edit Folder' : 'Create New Folder'}</DialogTitle></DialogHeader>
            <FolderForm folder={editingFolder} onSubmit={handleSaveFolder} onCancel={() => setIsFolderModalOpen(false)} loading={loading} />
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default MessageTemplates;