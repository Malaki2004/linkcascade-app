import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Rocket, 
  BarChart3, 
  Layout, 
  FolderOpen,
  Lock,
  Target,
  Plus,
  Edit,
  Trash2,
  Calendar,
  Link2,
  ChevronDown,
  ChevronUp,
  Info,
  Copy,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import CampaignForm from '@/components/CampaignForm';
import { PLAN_LIMITS } from '@/lib/constants';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from '@/components/ui/dialog';
import { getShortLinkUrl } from '@/utils/linkGeneration';

const SOURCE_CHANNELS = ['Facebook', 'Instagram', 'TikTok', 'YouTube', 'Email', 'LinkedIn', 'Website', 'Other'];

const CampaignBuilder = () => {
  const { user, userProfile, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [campaigns, setCampaigns] = useState([]);
  const [links, setLinks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  
  // Edit State
  const [editingCampaign, setEditingCampaign] = useState(null);
  const [editFormData, setEditFormData] = useState({ name: '', description: '' });
  const [isSaving, setIsSaving] = useState(false);

  // Link Creation inside Campaign
  const [isLinkCreateOpen, setIsLinkCreateOpen] = useState(false);
  const [activeCampaignIdForLink, setActiveCampaignIdForLink] = useState(null);
  const [linkFormData, setLinkFormData] = useState({ title: '', original_url: '', source_channel: '' });
  const [isLinkSaving, setIsLinkSaving] = useState(false);
  
  // Success Message State
  const [successLink, setSuccessLink] = useState(null);

  // Link Actions State
  const [togglingLinkId, setTogglingLinkId] = useState(null);
  const [copiedLinkId, setCopiedLinkId] = useState(null);

  // UI State
  const [expandedCampaigns, setExpandedCampaigns] = useState({});

  const userPlan = userProfile?.plan || 'free';
  const isPro = userPlan === 'pro' || userPlan === 'agency';
  const maxCampaigns = PLAN_LIMITS[userPlan]?.maxCampaigns || 2;
  const canCreateCampaign = maxCampaigns === -1 || campaigns.length < maxCampaigns;
  
  const maxLinks = PLAN_LIMITS[userPlan]?.maxLinks || 5;
  const canCreateLink = maxLinks === -1 || links.length < maxLinks;

  useEffect(() => {
    fetchData();
  }, [user?.id, authLoading]);

  const fetchData = async () => {
    if (authLoading) return;
    if (!user?.id) { setLoading(false); return; }
    try {
      const [campaignsRes, linksRes] = await Promise.all([
        supabase.from('campaigns').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
        supabase.from('links').select('id, title, short_code, original_url, campaign_id, source_channel, enable_lead_capture, created_at, last_activity, clicks(count)').eq('user_id', user.id)
      ]);
        
      if (campaignsRes.error) throw campaignsRes.error;
      if (linksRes.error) throw linksRes.error;
      
      setCampaigns(campaignsRes.data || []);
      setLinks(linksRes.data || []);
    } catch (error) {
      console.error('Data fetch error:', error);
      const errorMessage = error?.message || error?.details || 'Failed to load data';
      toast({ title: 'Error', description: errorMessage, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCampaign = async (formData) => {
    if (!user?.id) return;
    if (!canCreateCampaign) {
      toast({ title: 'Limit Reached', description: 'Upgrade your plan to create more campaigns.', variant: 'destructive' });
      return;
    }

    try {
      const { data, error } = await supabase
        .from('campaigns')
        .insert([{ ...formData, user_id: user.id, status: 'active' }])
        .select()
        .single();
        
      if (error) throw error;
      setCampaigns([data, ...campaigns]);
      setIsFormOpen(false);
      toast({ title: 'Success', description: 'Campaign created successfully!' });
    } catch (error) {
      console.error('Campaign creation error:', error);
      const errorMessage = error?.message || error?.details || 'Failed to create campaign.';
      toast({ title: 'Error', description: errorMessage, variant: 'destructive' });
      throw error;
    }
  };

  const handleDeleteCampaign = async (campaignId) => {
    if (!confirm('Are you sure you want to delete this campaign? Links within this campaign will not be deleted, but will be detached.')) return;
    try {
      const { error } = await supabase
        .from('campaigns')
        .delete()
        .eq('id', campaignId)
        .eq('user_id', user.id);
        
      if (error) throw error;
      setCampaigns(campaigns.filter(c => c.id !== campaignId));
      setLinks(links.map(l => l.campaign_id === campaignId ? { ...l, campaign_id: null } : l));
      toast({ title: 'Deleted', description: 'Campaign removed.' });
    } catch (error) {
      console.error('Campaign deletion error:', error);
      const errorMessage = error?.message || error?.details || 'Failed to delete campaign';
      toast({ title: 'Error', description: errorMessage, variant: 'destructive' });
    }
  };

  const handleEditClick = (campaign) => {
    setEditingCampaign(campaign);
    setEditFormData({
      name: campaign.name,
      description: campaign.description || ''
    });
  };

  const handleEditFormChange = (field, value) => {
    setEditFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveEdit = async () => {
    if (!editFormData.name.trim()) {
      toast({ title: 'Validation Error', description: 'Campaign name is required.', variant: 'destructive' });
      return;
    }

    setIsSaving(true);
    try {
      const { data, error } = await supabase
        .from('campaigns')
        .update({
          name: editFormData.name,
          description: editFormData.description,
          updated_at: new Date().toISOString()
        })
        .eq('id', editingCampaign.id)
        .select()
        .single();

      if (error) throw error;

      setCampaigns(campaigns.map(c => c.id === editingCampaign.id ? data : c));
      setEditingCampaign(null);
      toast({ title: 'Updated', description: 'Campaign updated successfully.' });
    } catch (error) {
      console.error('Campaign update error:', error);
      const errorMessage = error?.message || error?.details || 'Failed to update campaign.';
      toast({ title: 'Error', description: errorMessage, variant: 'destructive' });
    } finally {
      setIsSaving(false);
    }
  };

  const toggleExpand = (id) => {
    setExpandedCampaigns(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCreateLink = async (e) => {
    e.preventDefault();
    
    // Validate form fields
    if (!linkFormData.title || !linkFormData.title.trim()) {
      toast({ title: 'Validation Error', description: 'Link title is required.', variant: 'destructive' });
      return;
    }
    
    if (!linkFormData.original_url || !linkFormData.original_url.trim()) {
      toast({ title: 'Validation Error', description: 'Destination URL is required.', variant: 'destructive' });
      return;
    }
    
    // Check link limit
    if (!canCreateLink) {
      toast({ title: 'Limit Reached', description: 'Upgrade your plan to create more links.', variant: 'destructive' });
      return;
    }
    
    setIsLinkSaving(true);
    setSuccessLink(null);
    
    try {
      // Get authenticated user
      const { data: { user: currentUser }, error: userError } = await supabase.auth.getUser();
      
      if (userError) throw userError;
      if (!currentUser) {
        throw new Error('User not authenticated');
      }
      
      // Generate short code inline
      const shortCode = Math.random().toString(36).substring(2, 8);
      
      // Prepare link data
      const newLink = {
        user_id: currentUser.id,
        title: linkFormData.title.trim(),
        original_url: linkFormData.original_url.trim(),
        short_code: shortCode,
        clicks: 0,
        enable_lead_capture: false,
        campaign_id: activeCampaignIdForLink,
        source_channel: linkFormData.source_channel || null
      };

      // Insert link into database
      const { data, error } = await supabase
        .from('links')
        .insert([newLink])
        .select('*, clicks(count)')
        .single();

      if (error) throw error;
      
      // Upsert to public_links table
      await supabase.from('public_links').upsert(
        { short_code: data.short_code, original_url: data.original_url },
        { onConflict: 'short_code' }
      );

      // Update local state
      setLinks([data, ...links]);
      
      // Clear form fields
      setLinkFormData({ title: '', original_url: '', source_channel: '' });
      setIsLinkCreateOpen(false);
      
      // Auto expand campaign to show new link
      setExpandedCampaigns(prev => ({ ...prev, [activeCampaignIdForLink]: true })); 
      setActiveCampaignIdForLink(null);
      
      // Show success message
      setSuccessLink(data);
      
      // Show success toast
      toast({ 
        title: 'Success', 
        description: 'Link created successfully!' 
      });
      
    } catch (error) {
      // Log full error details to console
      console.error('=== LINK CREATION ERROR ===');
      console.error('Full error object:', error);
      console.error('Error message:', error?.message);
      console.error('Error details:', error?.details);
      console.error('Error hint:', error?.hint);
      console.error('Error code:', error?.code);
      console.error('Error stack:', error?.stack);
      console.error('=== END ERROR ===');
      
      // Build real error message
      const errorMessage = error?.message || error?.details || error?.hint || 'Failed to create link. Please try again.';
      
      // Show error toast
      toast({ 
        title: 'Error Creating Link', 
        description: errorMessage, 
        variant: 'destructive' 
      });
    } finally {
      setIsLinkSaving(false);
    }
  };

  const openLinkCreateModal = (campaignId) => {
    setActiveCampaignIdForLink(campaignId);
    setLinkFormData({ title: '', original_url: '', source_channel: '' });
    setIsLinkCreateOpen(true);
  };
  
  const navigateToLinkVault = (linkId) => {
    navigate('/links', { state: { highlightLinkId: linkId } });
  };

  // New Link Card Functions
  const handleToggleLeadCapture = async (linkId, currentState) => {
    setTogglingLinkId(linkId);
    try {
      const { error } = await supabase.from('links').update({ enable_lead_capture: !currentState }).eq('id', linkId);
      if (error) throw error;
      
      setLinks(links.map(l => l.id === linkId ? { ...l, enable_lead_capture: !currentState } : l));
      console.log(`Lead capture ${!currentState ? 'enabled' : 'disabled'} for link ${linkId}`);
    } catch (err) {
      console.error('Error toggling lead capture:', err);
      const errorMessage = err?.message || err?.details || 'Failed to toggle lead capture.';
      toast({ title: 'Error', description: errorMessage, variant: 'destructive' });
    } finally {
      setTogglingLinkId(null);
    }
  };

  const handleCopyLink = async (slug) => {
    try {
      const url = getShortLinkUrl(slug);
      await navigator.clipboard.writeText(url);
      setCopiedLinkId(slug);
      setTimeout(() => {
        setCopiedLinkId(null);
      }, 2000);
    } catch (err) {
      console.error('Error copying link:', err);
      toast({ title: 'Error', description: 'Failed to copy link to clipboard.', variant: 'destructive' });
    }
  };

  const getLinkStatus = (link) => {
    const isReady = Boolean(link.source_channel && link.short_code);
    return isReady 
      ? { isReady: true, label: 'READY', color: '#4caf50' } 
      : { isReady: false, label: 'INCOMPLETE', color: '#ff9800' };
  };

  return (
    <>
      <Helmet><title>Campaigns - LinkCascade</title></Helmet>
      
      <div className="p-4 md:p-8 max-w-7xl mx-auto min-h-screen">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Campaigns</h1>
            <p className="text-gray-500 mt-2">Organize links by purpose and track aggregated goals.</p>
          </div>
          {!canCreateCampaign ? (
             <Button onClick={() => navigate('/pricing')} className="shrink-0 bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">Upgrade to Pro</Button>
          ) : (
            !isFormOpen && (
              <Button onClick={() => setIsFormOpen(true)} className="shrink-0 bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
                <Plus className="w-4 h-4 mr-2" /> Create Campaign
              </Button>
            )
          )}
        </div>
        
        {/* Instructional Info Box */}
        <div style={{ backgroundColor: '#f3f4f6', padding: '20px', borderRadius: '12px', marginBottom: '24px', border: '1px solid #e5e7eb' }}>
          <h3 style={{ fontSize: '16px', fontWeight: 'bold', marginBottom: '12px', color: '#111827', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Info size={18} color="#6b7280" /> How Campaign Links Work
          </h3>
          <ol style={{ margin: 0, paddingLeft: '24px', color: '#4b5563', fontSize: '14px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
             <li><strong>Add a link</strong> to your campaign directly from this page.</li>
             <li><strong>Open in Link Vault</strong> by clicking the button on your newly created link.</li>
             <li><strong>Turn on Lead Capture</strong> directly on the card or in the Link Vault to collect emails before redirecting.</li>
             <li><strong>Copy and share</strong> your short link to start tracking clicks and conversions!</li>
          </ol>
        </div>

        {/* Success Message Notification */}
        {successLink && (
          <div style={{ backgroundColor: '#dcfce3', borderColor: '#86efac', color: '#166534', padding: '16px', borderRadius: '8px', marginBottom: '24px', borderStyle: 'solid', borderWidth: '1px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
            <div>
              <strong style={{ display: 'block', marginBottom: '4px', fontSize: '16px' }}>Link added successfully!</strong>
              <span style={{ fontSize: '14px' }}>Your link "<strong>{successLink.title}</strong>" has been added. Open it in the Link Vault to enable Lead Capture.</span>
            </div>
            <button 
              onClick={() => navigateToLinkVault(successLink.id)} 
              style={{ backgroundColor: '#16a34a', color: '#fff', padding: '10px 20px', borderRadius: '6px', fontSize: '14px', fontWeight: 'bold', border: 'none', cursor: 'pointer', whiteSpace: 'nowrap', transition: 'background-color 0.2s' }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#15803d'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#16a34a'}
            >
              Open in Link Vault
            </button>
          </div>
        )}

        <div className="relative">
          {!canCreateCampaign && !isPro && (
             <div className="bg-lc-teal/10 p-6 rounded-xl mb-8 border border-lc-border flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                   <h3 className="font-bold text-gray-900 flex items-center gap-2">
                     <Lock className="w-4 h-4 text-lc-tealdark" />
                     Campaign Limit Reached
                   </h3>
                   <p className="text-gray-600 text-sm mt-1">
                     You've reached the free limit of {maxCampaigns} campaigns. Upgrade to Pro for unlimited campaigns and advanced features.
                   </p>
                </div>
                <Button onClick={() => navigate('/pricing')} className="shrink-0 bg-lc-teal hover:bg-lc-tealdark w-full md:w-auto text-lc-graphite">
                  Upgrade Plan
                </Button>
             </div>
          )}

          {isFormOpen ? (
             <CampaignForm onSubmit={handleCreateCampaign} onCancel={() => setIsFormOpen(false)} />
          ) : (
             loading ? (
               <div className="flex justify-center py-20"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-lc-teal"></div></div>
             ) : (
               <div className="grid gap-6">
                 {campaigns.length === 0 ? (
                    <div className="text-center py-16 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                      <Target className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900">No campaigns yet</h3>
                      <p className="text-gray-500 mb-6">Create your first campaign to start tracking.</p>
                      <Button variant="outline" onClick={() => setIsFormOpen(true)}>Create Campaign</Button>
                    </div>
                 ) : (
                   campaigns.map((campaign) => {
                     const campaignLinks = links.filter(l => l.campaign_id === campaign.id);
                     const isExpanded = expandedCampaigns[campaign.id];

                     return (
                       <motion.div 
                         key={campaign.id}
                         initial={{ opacity: 0, y: 10 }}
                         animate={{ opacity: 1, y: 0 }}
                         className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden hover:shadow-md transition-shadow"
                       >
                         <div className="p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                            <div className="flex-1 cursor-pointer w-full" onClick={() => toggleExpand(campaign.id)}>
                              <div className="flex items-center gap-3 mb-1">
                                <h3 className="font-bold text-xl text-gray-900">{campaign.name}</h3>
                                <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                                  campaign.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
                                }`}>
                                  {campaign.status}
                                </span>
                              </div>
                              {campaign.description && (
                                <p className="text-gray-600 text-sm mb-3">{campaign.description}</p>
                              )}
                              <div className="flex items-center gap-4 text-sm text-gray-500">
                                 <span className="flex items-center gap-1 font-medium bg-gray-100 px-2 py-1 rounded-md">
                                   <Link2 className="w-4 h-4" />
                                   {campaignLinks.length} {campaignLinks.length === 1 ? 'Link' : 'Links'}
                                 </span>
                                 <span className="flex items-center gap-1 text-xs text-gray-400">
                                   <Calendar className="w-3 h-3" />
                                   {new Date(campaign.created_at).toLocaleDateString()}
                                 </span>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 w-full md:w-auto border-t md:border-t-0 pt-4 md:pt-0 mt-2 md:mt-0 justify-end">
                               <Button variant="outline" size="sm" onClick={() => navigate(`/analytics?campaign=${campaign.id}`)}>
                                 <BarChart3 className="w-4 h-4 mr-2" />
                                 Analytics
                               </Button>
                               <div
                                 role="button"
                                 aria-label="Edit campaign"
                                 onClick={() => handleEditClick(campaign)}
                                 className="p-2 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer text-gray-600 hover:text-blue-600 ml-2"
                               >
                                 <Edit className="w-4 h-4" />
                               </div>
                               <Button 
                                 size="icon" 
                                 variant="ghost" 
                                 className="text-gray-400 hover:text-red-600 hover:bg-red-50 h-9 w-9"
                                 onClick={() => handleDeleteCampaign(campaign.id)}
                               >
                                 <Trash2 className="w-4 h-4" />
                               </Button>
                               <Button 
                                 size="icon" 
                                 variant="ghost" 
                                 onClick={() => toggleExpand(campaign.id)}
                                 className="ml-2 bg-gray-50 hover:bg-gray-100 text-gray-600"
                               >
                                 {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                               </Button>
                            </div>
                         </div>

                         {/* Links Accordion */}
                         {isExpanded && (
                           <div className="bg-gray-50 border-t border-gray-200 p-4 md:p-6">
                             <div className="flex justify-between items-center mb-4">
                               <h4 className="font-semibold text-gray-800 flex items-center gap-2">
                                 Campaign Links
                               </h4>
                               <Button size="sm" className="bg-white border-gray-300 text-gray-700 hover:bg-gray-100 shadow-sm" variant="outline" onClick={() => openLinkCreateModal(campaign.id)}>
                                 <Plus className="w-3 h-3 mr-1" /> Add Link
                               </Button>
                             </div>

                             {campaignLinks.length === 0 ? (
                               <p className="text-sm text-gray-500 py-4 text-center border border-dashed border-gray-300 rounded-lg bg-white">No links attached to this campaign yet.</p>
                             ) : (
                               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                 {campaignLinks.map(link => {
                                   const status = getLinkStatus(link);
                                   const missing = [];
                                   if (!link.source_channel) missing.push('Source Channel');
                                   if (!link.short_code) missing.push('Short Link');
                                   
                                   return (
                                     <div key={link.id} style={{ border: '1px solid #e5e7eb', borderRadius: '8px', padding: '16px', backgroundColor: '#fff', display: 'flex', flexDirection: 'column', gap: '12px', boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)', transition: 'border-color 0.2s' }} onMouseOver={(e) => e.currentTarget.style.borderColor = '#c4b5fd'} onMouseOut={(e) => e.currentTarget.style.borderColor = '#e5e7eb'}>
                                       
                                       {/* Header */}
                                       <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '8px' }}>
                                         <strong style={{ fontSize: '15px', color: '#111827', wordBreak: 'break-word', lineHeight: '1.2' }}>{link.title}</strong>
                                         <span style={{ backgroundColor: status.isReady ? '#e8f5e9' : '#fff3e0', color: status.color, padding: '4px 8px', borderRadius: '4px', fontSize: '10px', fontWeight: 'bold', whiteSpace: 'nowrap', flexShrink: 0 }}>
                                           {status.label}
                                         </span>
                                       </div>

                                       {/* Short Link Display */}
                                       <div style={{ backgroundColor: '#f3f4f6', padding: '8px', borderRadius: '6px', fontFamily: 'monospace', fontSize: '12px', color: '#4f46e5', wordBreak: 'break-all' }}>
                                         {getShortLinkUrl(link.short_code)}
                                       </div>

                                       {/* Missing Info Alert */}
                                       {!status.isReady && (
                                         <div style={{ color: '#ea580c', fontSize: '12px', fontWeight: '600', backgroundColor: '#fff7ed', padding: '6px 8px', borderRadius: '4px', border: '1px solid #fed7aa' }}>
                                           Missing: {missing.join(', ')}
                                         </div>
                                       )}

                                       {/* Source Channel & Clicks */}
                                       <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#6b7280', flexWrap: 'wrap', gap: '8px', marginBottom: '4px' }}>
                                         {link.source_channel ? (
                                           <span style={{ backgroundColor: '#f1f5f9', padding: '2px 8px', borderRadius: '4px' }}>Source: <strong style={{ color: '#374151' }}>{link.source_channel}</strong></span>
                                         ) : <span />}
                                       </div>
                                       
                                       <div style={{fontSize: '13px', color: '#666', marginBottom: '12px'}}>
                                         <strong>Clicks:</strong> {link.clicks?.[0]?.count || 0}
                                         <span style={{ marginLeft: '12px' }}>
                                           <strong>Last Activity:</strong> {link.last_activity ? new Date(link.last_activity).toLocaleDateString('en-US', { month: 'numeric', day: 'numeric', year: 'numeric' }) : '-'}
                                         </span>
                                       </div>

                                       {/* Lead Capture Toggle */}
                                       <label style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px', borderRadius: '6px', backgroundColor: link.enable_lead_capture ? '#dcfce3' : '#f3f4f6', cursor: togglingLinkId === link.id ? 'not-allowed' : 'pointer', border: '1px solid transparent', transition: 'border-color 0.2s' }} onMouseOver={(e) => { if(togglingLinkId !== link.id) e.currentTarget.style.borderColor = link.enable_lead_capture ? '#86efac' : '#d1d5db' }} onMouseOut={(e) => { if(togglingLinkId !== link.id) e.currentTarget.style.borderColor = 'transparent' }}>
                                         <input
                                           type="checkbox"
                                           checked={link.enable_lead_capture || false}
                                           disabled={togglingLinkId === link.id}
                                           onChange={() => handleToggleLeadCapture(link.id, link.enable_lead_capture)}
                                           style={{ width: '16px', height: '16px', cursor: togglingLinkId === link.id ? 'not-allowed' : 'pointer', accentColor: '#16a34a' }}
                                         />
                                         <span style={{ fontSize: '13px', fontWeight: '600', color: link.enable_lead_capture ? '#166534' : '#4b5563', userSelect: 'none' }}>
                                           {togglingLinkId === link.id ? 'Updating...' : `Lead Capture: ${link.enable_lead_capture ? 'ENABLED' : 'OFF'}`}
                                         </span>
                                       </label>

                                       {/* Quick Action Buttons */}
                                       <div style={{ display: 'flex', gap: '8px', marginTop: 'auto', paddingTop: '12px', borderTop: '1px solid #f3f4f6' }}>
                                         <button
                                           onClick={() => handleCopyLink(link.short_code)}
                                           style={{ flex: 1, padding: '8px', borderRadius: '6px', border: 'none', cursor: 'pointer', fontWeight: '600', fontSize: '13px', backgroundColor: copiedLinkId === link.short_code ? '#22c55e' : '#3b82f6', color: '#fff', transition: 'background-color 0.2s', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '6px' }}
                                           onMouseOver={(e) => { if (copiedLinkId !== link.short_code) e.currentTarget.style.backgroundColor = '#2563eb' }}
                                           onMouseOut={(e) => { if (copiedLinkId !== link.short_code) e.currentTarget.style.backgroundColor = '#3b82f6' }}
                                         >
                                           {copiedLinkId === link.short_code ? (
                                              <><Check size={14} /> Copied</>
                                           ) : (
                                              <><Copy size={14} /> Copy Link</>
                                           )}
                                         </button>
                                         <button
                                           onClick={() => navigateToLinkVault(link.id)}
                                           style={{ flex: 1, padding: '8px', borderRadius: '6px', border: 'none', cursor: 'pointer', fontWeight: '600', fontSize: '13px', backgroundColor: '#7c3aed', color: '#fff', transition: 'background-color 0.2s', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '4px' }}
                                           onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#6d28d9'}
                                           onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#7c3aed'}
                                         >
                                           Advanced
                                         </button>
                                       </div>
                                     </div>
                                   );
                                 })}
                               </div>
                             )}
                           </div>
                         )}
                       </motion.div>
                     );
                   })
                 )}
               </div>
             )
          )}
        </div>

        {/* Edit Campaign Dialog */}
        <Dialog open={!!editingCampaign} onOpenChange={(open) => !open && !isSaving && setEditingCampaign(null)}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Edit Campaign</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="name" className="text-sm font-medium text-gray-700">Campaign Name</label>
                <input
                  id="name"
                  value={editFormData.name}
                  onChange={(e) => handleEditFormChange('name', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none transition-all"
                  placeholder="e.g. Summer Sale 2024"
                  disabled={isSaving}
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="description" className="text-sm font-medium text-gray-700">Description</label>
                <textarea
                  id="description"
                  value={editFormData.description}
                  onChange={(e) => handleEditFormChange('description', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none min-h-[100px] resize-none transition-all"
                  placeholder="Optional description..."
                  disabled={isSaving}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingCampaign(null)} disabled={isSaving}>
                Cancel
              </Button>
              <Button onClick={handleSaveEdit} disabled={isSaving} className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
                {isSaving ? 'Saving...' : 'Save Changes'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Create Link Dialog within Campaign */}
        <Dialog open={isLinkCreateOpen} onOpenChange={(val) => { setIsLinkCreateOpen(val); if(!val && !isLinkSaving) { setActiveCampaignIdForLink(null); setLinkFormData({title:'', original_url:'', source_channel:''}); } }}>
          <DialogContent>
            <DialogHeader><DialogTitle>Add Link to Campaign</DialogTitle></DialogHeader>
            <form onSubmit={handleCreateLink} className="space-y-4 pt-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input required disabled={isLinkSaving} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none bg-white text-gray-900" placeholder="e.g. Summer Promo" value={linkFormData.title} onChange={e => setLinkFormData({...linkFormData, title: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Destination URL</label>
                <input required type="url" disabled={isLinkSaving} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none bg-white text-gray-900" placeholder="https://..." value={linkFormData.original_url} onChange={e => setLinkFormData({...linkFormData, original_url: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Source Channel (Optional)</label>
                <select disabled={isLinkSaving} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none bg-white text-gray-900" value={linkFormData.source_channel} onChange={e => setLinkFormData({...linkFormData, source_channel: e.target.value})}>
                  <option value="">Select Channel</option>
                  {SOURCE_CHANNELS.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <Button type="submit" disabled={isLinkSaving} className="w-full bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
                {isLinkSaving ? 'Adding...' : 'Add Link'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default CampaignBuilder;