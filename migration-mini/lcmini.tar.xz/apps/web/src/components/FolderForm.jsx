import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

const FolderForm = ({ folder, onSubmit, onCancel, loading }) => {
  const [name, setName] = useState('');

  useEffect(() => {
    if (folder) {
      setName(folder.name);
    }
  }, [folder]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ name });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Folder Name <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
          placeholder="e.g., Marketing Campaigns"
        />
      </div>

      <div className="flex justify-end gap-3 pt-2">
        <Button type="button" variant="outline" onClick={onCancel} className="border-gray-200 text-gray-700 hover:bg-lc-teal/10 hover:text-lc-tealdark">
          Cancel
        </Button>
        <Button type="submit" disabled={loading} className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
          {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
          {folder ? 'Update Folder' : 'Create Folder'}
        </Button>
      </div>
    </form>
  );
};

export default FolderForm;