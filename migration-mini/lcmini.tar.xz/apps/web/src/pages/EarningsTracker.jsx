import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, DollarSign, TrendingUp, Download, Calendar } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { EARNINGS_SOURCES } from '@/lib/constants';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Helmet } from 'react-helmet';

const EarningsTracker = () => {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [earnings, setEarnings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [formData, setFormData] = useState({
    amount: '',
    source: 'Affiliate',
    sourceName: '',
    date: new Date().toISOString().split('T')[0],
    notes: '',
  });

  useEffect(() => {
    fetchEarnings();
  }, [userProfile?.id]);

  const fetchEarnings = async () => {
    if (!userProfile?.id) {
      setLoading(false);
      return;
    }
    try {
      const { data, error } = await supabase
        .from('earnings')
        .select('*')
        .eq('user_id', userProfile.id)
        .order('date', { ascending: false });

      if (error) throw error;
      setEarnings(data || []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();

    if (!formData.sourceName.trim()) {
      toast({
        title: 'Validation Error',
        description: 'Please enter a Source Name (e.g., Amazon Associates).',
        variant: 'destructive',
      });
      return;
    }

    try {
      const { error } = await supabase.from('earnings').insert([
        {
          amount: parseFloat(formData.amount),
          user_id: userProfile.id,
          source: formData.source,
          source_name: formData.sourceName,
          date: formData.date,
          notes: formData.notes,
        },
      ]);

      if (error) throw error;

      toast({ title: 'Logged!', description: 'Earnings recorded.' });
      setFormData({
        amount: '',
        source: 'Affiliate',
        sourceName: '',
        date: new Date().toISOString().split('T')[0],
        notes: '',
      });
      setIsCreateOpen(false);
      fetchEarnings();
    } catch (e) {
      toast({ title: 'Error', description: 'Failed to log earnings.', variant: 'destructive' });
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete entry?')) return;
    try {
      await supabase.from('earnings').delete().eq('id', id);
      fetchEarnings();
      toast({ title: 'Deleted', description: 'Entry removed.' });
    } catch (e) {
      toast({ title: 'Error', variant: 'destructive' });
    }
  };

  // CSV helpers
  const csvEscape = (value) => {
    const str = value === null || value === undefined ? '' : String(value);
    return `"${str.replace(/"/g, '""')}"`;
  };

  const userPlan = (userProfile?.plan || 'free').toLowerCase();
  const canExportCsv = userPlan === 'pro' || userPlan === 'agency';

  const handleExportCsv = () => {
    if (!canExportCsv) {
      toast({
        title: 'Pro feature',
        description: 'CSV Export is available on Pro and Agency plans.',
        variant: 'destructive',
      });
      return;
    }

    if (!earnings || earnings.length === 0) {
      toast({
        title: 'Nothing to export',
        description: 'Log at least one earnings entry first.',
        variant: 'destructive',
      });
      return;
    }

    const headers = ['Date', 'Category', 'Source Name', 'Amount', 'Notes'];

    const rows = earnings.map((e) => {
      const dateStr = e.date ? new Date(e.date).toISOString().split('T')[0] : '';
      const category = e.source || '';
      const sourceName = e.source_name || '';
      const amount =
        typeof e.amount === 'number'
          ? e.amount.toFixed(2)
          : e.amount
            ? Number(e.amount).toFixed(2)
            : '0.00';
      const notes = e.notes || '';

      return [
        csvEscape(dateStr),
        csvEscape(category),
        csvEscape(sourceName),
        csvEscape(amount),
        csvEscape(notes),
      ].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const today = new Date().toISOString().split('T')[0];
    const filename = `linkcascade-earnings-${today}.csv`;

    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    URL.revokeObjectURL(url);

    toast({ title: 'Export started', description: `Downloading ${filename}` });
  };

  const totalEarnings = earnings.reduce((sum, e) => sum + parseFloat(e.amount), 0);
  const avgEarnings = earnings.length ? totalEarnings / earnings.length : 0;

  const stats = [
    { label: 'Total Earnings', value: `$${totalEarnings.toFixed(2)}`, icon: DollarSign, color: 'text-green-600', bg: 'bg-green-100' },
    { label: 'Avg. per Entry', value: `$${avgEarnings.toFixed(2)}`, icon: TrendingUp, color: 'text-lc-tealdark', bg: 'bg-lc-teal/15' },
    { label: 'Entries', value: earnings.length, icon: Calendar, color: 'text-lc-tealdark', bg: 'bg-lc-teal/15' },
    { label: 'Growth', value: '—', icon: TrendingUp, color: 'text-orange-600', bg: 'bg-orange-100' },
  ];

  return (
    <>
      <Helmet><title>Earnings - LinkCascade</title></Helmet>
      <div className="p-6 md:p-8 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Earnings Tracker</h1>
            <p className="text-gray-500 mt-2">Monitor your revenue streams.</p>
          </div>

          <div className="flex gap-2">
            <Button
              variant="outline"
              className="hidden md:flex border-lc-border text-lc-tealdark hover:bg-lc-teal/10"
              onClick={handleExportCsv}
              disabled={loading}
              title={
                loading
                  ? 'Loading...'
                  : canExportCsv
                    ? 'Export your earnings to CSV'
                    : 'CSV Export is available on Pro and Agency'
              }
            >
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>

            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <DialogTrigger asChild>
                <Button className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
                  <Plus className="w-4 h-4 mr-2" /> Log Earnings
                </Button>
              </DialogTrigger>

              <DialogContent>
                <DialogHeader><DialogTitle>Log New Earnings</DialogTitle></DialogHeader>
                <form onSubmit={handleCreate} className="space-y-4 pt-4">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Category</label>
                    <select
                      value={formData.source}
                      onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                      className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500 bg-white"
                    >
                      {EARNINGS_SOURCES.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">
                      Source Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={formData.sourceName}
                      onChange={(e) => setFormData({ ...formData, sourceName: e.target.value })}
                      required
                      placeholder="Example: Amazon Associates, Bank of America referral, TikTok Shop"
                      className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Amount ($)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.amount}
                      onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                      required
                      className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">Date</label>
                    <input
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      required
                      className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>

                  <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700">
                    Log Earnings
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm"
              >
                <div className="flex justify-between items-start mb-4">
                  <div className={`p-2 rounded-lg ${stat.bg}`}>
                    <Icon className={`w-5 h-5 ${stat.color}`} />
                  </div>
                </div>
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">{stat.label}</h3>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              </motion.div>
            );
          })}
        </div>

        {earnings.length === 0 ? (
          <div className="bg-white rounded-xl border border-dashed border-gray-300 p-16 text-center">
            <div className="w-16 h-16 bg-lc-teal/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <DollarSign className="w-8 h-8 text-lc-teal" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">No earnings logged</h3>
            <p className="text-gray-500 mb-6">Start tracking your income today.</p>
            <Button onClick={() => setIsCreateOpen(true)} className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
              Log Earnings
            </Button>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Date</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Category</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Source Name</th>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Amount</th>
                  <th className="px-6 py-4 text-right text-xs font-bold text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {earnings.map((e) => (
                  <tr key={e.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-6 py-4 text-sm text-gray-900 font-medium">
                      {new Date(e.date).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-2 py-1 bg-gray-100 rounded text-xs font-bold text-gray-600 uppercase">
                        {e.source}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-700">{e.source_name || '(Unknown)'}</td>
                    <td className="px-6 py-4 text-sm font-bold text-green-600">${Number(e.amount).toFixed(2)}</td>
                    <td className="px-6 py-4 text-right">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-gray-400 hover:text-red-600"
                        onClick={() => handleDelete(e.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
};

export default EarningsTracker;