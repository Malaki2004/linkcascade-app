import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/supabaseClient';
import LeadCaptureForm from '@/components/LeadCaptureForm';

const Redirect = () => {
  const { slug } = useParams();
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [linkRecord, setLinkRecord] = useState(null);

  useEffect(() => {
    const fetchLinkData = async () => {
      try {
        const { data, error: fetchError } = await supabase
          .from('links')
          .select('*')
          .eq('short_code', slug)
          .single();

        if (fetchError || !data) {
          setError(true);
          setLoading(false);
          return;
        }

        // 1. Fire-and-forget click tracking (Non-blocking)
        supabase.from('clicks').insert([{
          link_id: data.id,
          campaign_id: data.campaign_id || null,
          source_channel: data.source_channel || null,
          user_id: data.user_id,
          clicked_at: new Date().toISOString()
        }]).then();
        
        // 2. Fire-and-forget activity tracking (Non-blocking)
        supabase.from('links').update({ 
          last_activity: new Date().toISOString(),
          last_clicked_at: new Date().toISOString() 
        }).eq('id', data.id).then();

        // 3. Immediate Redirect if no lead capture
        if (!data.enable_lead_capture) {
          window.location.replace(data.original_url);
          // Keep loading true to maintain the "Redirecting..." white screen while browser navigates
          return; 
        }

        // 4. Set state to render LeadCaptureForm
        setLinkRecord(data);
        setLoading(false);
      } catch (err) {
        setError(true);
        setLoading(false);
      }
    };

    if (slug) {
      fetchLinkData();
    }
  }, [slug]);

  if (error) {
    return (
      <div style={{
        width: '100vw',
        height: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#FFFFFF',
        fontFamily: 'system-ui, -apple-system, sans-serif',
        position: 'fixed',
        top: 0,
        left: 0,
        zIndex: 9999,
        padding: '20px',
        boxSizing: 'border-box'
      }}>
        <div style={{
          textAlign: 'center',
          maxWidth: '400px',
          width: '100%'
        }}>
          <h1 style={{ color: '#333333', marginTop: 0, marginBottom: '12px', fontSize: '24px', fontWeight: '500' }}>
            Link Not Found
          </h1>
          <p style={{ color: '#666666', margin: 0, fontSize: '15px' }}>
            This link may have expired or been removed.
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div style={{
        width: '100vw',
        height: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#FFFFFF',
        fontFamily: 'system-ui, -apple-system, sans-serif',
        position: 'fixed',
        top: 0,
        left: 0,
        zIndex: 9999
      }}>
        <p style={{ color: '#666666', fontSize: '16px', margin: 0 }}>Redirecting...</p>
      </div>
    );
  }

  // Render the lead capture form if enabled
  if (linkRecord?.enable_lead_capture) {
    return (
      <>
        <Helmet>
          <title>Access Content | LinkCascade</title>
          <meta name="robots" content="noindex, nofollow" />
        </Helmet>
        <LeadCaptureForm
          linkId={linkRecord.id}
          campaignId={linkRecord.campaign_id || null} 
          sourceChannel={linkRecord.source_channel || null}
          userId={linkRecord.user_id}
          linkTitle={linkRecord.title}
          destinationUrl={linkRecord.original_url}
          slug={slug}
        />
      </>
    );
  }

  return null;
};

export default Redirect;