import React from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, CreditCard, Shield } from 'lucide-react';
import { Helmet } from 'react-helmet';
import { cn } from '@/lib/utils';

const SettingsLayout = () => {
  const navItems = [
    { name: 'Account', path: '.', icon: User, end: true },
    { name: 'Billing', path: 'billing', icon: CreditCard, end: false },
    { name: 'Security', path: 'security', icon: Shield, end: false },
  ];

  return (
    <>
      <Helmet><title>Settings - LinkCascade</title></Helmet>
      <div className="p-6 md:p-8 max-w-6xl mx-auto min-h-screen">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Settings</h1>
          <p className="text-gray-500 mt-2">Manage your account preferences and subscription.</p>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Left Sidebar Navigation */}
          <aside className="w-full md:w-64 flex-shrink-0 space-y-2">
            <nav className="flex md:flex-col overflow-x-auto md:overflow-visible gap-2 pb-2 md:pb-0">
              {navItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  end={item.end}
                  className={({ isActive }) =>
                    cn(
                      "flex items-center gap-3 px-4 py-3 text-sm font-medium rounded-lg transition-all duration-200 whitespace-nowrap",
                      isActive
                        ? "bg-purple-50 text-purple-700 border-l-4 border-purple-600 shadow-sm"
                        : "text-gray-600 hover:bg-gray-50 hover:text-gray-900 border-l-4 border-transparent"
                    )
                  }
                >
                  <item.icon className="w-4 h-4" />
                  {item.name}
                </NavLink>
              ))}
            </nav>
          </aside>

          {/* Right Content Area */}
          <main className="flex-1 min-w-0">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden"
            >
              <Outlet />
            </motion.div>
          </main>
        </div>
      </div>
    </>
  );
};

export default SettingsLayout;