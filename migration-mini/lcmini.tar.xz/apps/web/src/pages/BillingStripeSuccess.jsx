import React, { useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Loader2, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Helmet } from 'react-helmet';

const BillingStripeSuccess = () => {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('session_id');
  const { user, userProfile, refreshProfile } = useAuth();

  useEffect(() => {
    if (sessionId) {
      localStorage.setItem('stripe_session_id_pending', sessionId);
    }
  }, [sessionId]);

  // Try to refresh the profile if user is logged in
  useEffect(() => {
    if (user) {
      refreshProfile();
    }
  }, [user, refreshProfile]);

  const isProOrAgency = userProfile?.plan === 'pro' || userProfile?.plan === 'agency';

  return (
    <>
      <Helmet>
        <title>Activating Plan - LinkCascade</title>
        <meta name="description" content="Processing your subscription payment." />
      </Helmet>
      
      <div className="min-h-screen flex items-center justify-center bg-lc-offwhite p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100 p-8 text-center"
        >
          <div className="mx-auto w-16 h-16 bg-lc-teal/15 rounded-full flex items-center justify-center mb-6">
            {isProOrAgency ? (
                <CheckCircle2 className="w-8 h-8 text-green-600" />
            ) : (
                <Loader2 className="w-8 h-8 text-lc-tealdark animate-spin" />
            )}
          </div>

          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            {isProOrAgency ? 'Plan Activated!' : 'Activating your plan...'}
          </h1>

          <div className="bg-gray-50 rounded-lg p-4 mb-6 border border-gray-200 flex flex-col items-center justify-center gap-2">
            <ShieldCheck className="w-5 h-5 text-lc-teal" />
            <p className="text-sm text-gray-600 font-mono break-all">
              Session ID: {sessionId ? `${sessionId.substring(0, 16)}...` : 'N/A'}
            </p>
          </div>

          {!user && (
            <div className="space-y-4">
              <p className="text-gray-500 text-sm">
                Please log in to complete the activation process.
              </p>
              <Button asChild className="w-full bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
                <Link to="/login">Continue to login</Link>
              </Button>
            </div>
          )}

          {user && (
            <div className="space-y-4">
                <p className="text-sm text-gray-500">
                    {isProOrAgency 
                        ? `You are now on the ${userProfile.plan} plan.` 
                        : "We are verifying your payment with Stripe. This may take a moment."}
                </p>
                <Button asChild className="w-full bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
                    <Link to="/dashboard">Go to Dashboard</Link>
                </Button>
            </div>
          )}

        </motion.div>
      </div>
    </>
  );
};

export default BillingStripeSuccess;