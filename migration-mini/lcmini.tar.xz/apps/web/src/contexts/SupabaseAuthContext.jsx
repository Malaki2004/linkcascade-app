import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();
  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  // Function to load profile from DB
  const loadProfile = useCallback(async (uid, email) => {
    if (!uid) return;
    
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', uid)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          // Profile doesn't exist (PGRST116), create one
          console.log("Profile not found, creating new profile...");
          const { data: newProfile, error: createError } = await supabase
            .from('profiles')
            .insert([{ 
              id: uid, 
              email: email, 
              plan: 'free' 
            }])
            .select()
            .single();

          if (createError) {
            console.error("Error creating profile:", createError);
            // Don't throw here to avoid blocking auth completely, but warn
            toast({
              title: "Profile Error",
              description: "Could not initialize user profile.",
              variant: "destructive"
            });
          } else {
            setUserProfile(newProfile);
          }
        } else {
          console.error("Error fetching profile:", error);
        }
      } else {
        setUserProfile(data);
      }
    } catch (err) {
      console.error("Unexpected error loading profile:", err);
    }
  }, [toast]);

  // Helper to handle session updates
  const handleSession = useCallback(async (currentSession) => {
    setSession(currentSession);
    const currentUser = currentSession?.user ?? null;
    setUser(currentUser);
    
    if (currentUser) {
      await loadProfile(currentUser.id, currentUser.email);
    } else {
      setUserProfile(null);
    }
    
    setLoading(false);
  }, [loadProfile]);

  const refreshProfile = useCallback(async () => {
    if (user) {
      await loadProfile(user.id, user.email);
    }
  }, [user, loadProfile]);

  useEffect(() => {
    let mounted = true;

    const initAuth = async () => {
      try {
        const { data, error } = await supabase.auth.getSession();
        if (error) throw error;
        
        if (mounted) {
          await handleSession(data.session);
        }
      } catch (error) {
        console.error("Error checking session:", error);
        if (mounted) setLoading(false);
      }
    };

    initAuth();

    let subscription = null;
    try {
      const { data } = supabase.auth.onAuthStateChange(async (_event, session) => {
        if (mounted) {
          await handleSession(session);
        }
      });
      subscription = data.subscription;
    } catch (error) {
      console.error("Error setting up auth listener:", error);
    }

    return () => {
      mounted = false;
      if (subscription) subscription.unsubscribe();
    };
  }, [handleSession]);

  const signUp = useCallback(async (email, password, options) => {
    try {
      const { error } = await supabase.auth.signUp({ email, password, options });
      if (error) throw error;
      return { error: null };
    } catch (err) {
      toast({ title: "Sign up Failed", description: err.message, variant: "destructive" });
      return { error: err };
    }
  }, [toast]);

  const signIn = useCallback(async (email, password) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      // Profile load is triggered by onAuthStateChange, but we can return success here
      return { error: null };
    } catch (err) {
      toast({ title: "Sign in Failed", description: err.message, variant: "destructive" });
      return { error: err };
    }
  }, [toast]);

  const signOut = useCallback(async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      setUserProfile(null);
      return { error: null };
    } catch (err) {
      toast({ title: "Sign out Failed", description: err.message, variant: "destructive" });
      return { error: err };
    }
  }, [toast]);

  const value = useMemo(() => ({
    user,
    session,
    userProfile,
    loading,
    signUp,
    signIn,
    signOut,
    refreshProfile
  }), [user, session, userProfile, loading, signUp, signIn, signOut, refreshProfile]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const useSupabaseAuth = useAuth;