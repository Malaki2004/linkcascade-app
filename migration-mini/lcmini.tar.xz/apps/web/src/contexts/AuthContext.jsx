// Redirect legacy imports to the robust SupabaseAuthContext
export * from './SupabaseAuthContext';
export { AuthProvider as default } from './SupabaseAuthContext';