import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { PLAN_LIMITS } from '@/lib/constants';

const TemplateForm = ({ template, folders, onSubmit, onCancel, loading, currentTemplateCount }) => {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    title: '',
    body: '',
    platform: 'Email',
    tone: 'Professional',
    folder_id: ''
  });

  useEffect(() => {
    if (template) {
      setFormData({
        title: template.title || '',
        body: template.body || '',
        platform: template.platform || 'Email',
        tone: template.tone || 'Professional',
        folder_id: template.folder_id || ''
      });
    }
  }, [template]);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!template) {
      const userPlan = userProfile?.plan || 'free';
      const maxTemplates = PLAN_LIMITS[userPlan]?.maxTemplates || 10;
      
      if (maxTemplates !== -1 && currentTemplateCount >= maxTemplates) {
        toast({
          title: "Limit Reached",
          description: "Upgrade to Pro to create unlimited templates.",
          variant: "destructive"
        });
        return;
      }
    }

    onSubmit({
      ...formData,
      folder_id: formData.folder_id || null // Ensure empty string becomes null
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Template Title <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            required
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="e.g., Weekly Update"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Folder (Optional)
          </label>
          <select
            value={formData.folder_id}
            onChange={(e) => setFormData({ ...formData, folder_id: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white"
          >
            <option value="">No Folder</option>
            {folders.map(folder => (
              <option key={folder.id} value={folder.id}>{folder.name}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Platform
          </label>
          <select
            value={formData.platform}
            onChange={(e) => setFormData({ ...formData, platform: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white"
          >
            <option value="Email">Email</option>
            <option value="Instagram">Instagram</option>
            <option value="Twitter">Twitter</option>
            <option value="LinkedIn">LinkedIn</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Tone
          </label>
          <select
            value={formData.tone}
            onChange={(e) => setFormData({ ...formData, tone: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white"
          >
            <option value="Professional">Professional</option>
            <option value="Casual">Casual</option>
            <option value="Friendly">Friendly</option>
            <option value="Urgent">Urgent</option>
            <option value="Excited">Excited</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Message Body <span className="text-red-500">*</span>
        </label>
        <textarea
          required
          rows={6}
          value={formData.body}
          onChange={(e) => setFormData({ ...formData, body: e.target.value })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono text-sm"
          placeholder="Write your message template here..."
        />
      </div>

      <div className="flex justify-end gap-3 pt-2">
        <Button type="button" variant="outline" onClick={onCancel} className="border-gray-200 text-gray-700 hover:bg-lc-teal/10 hover:text-lc-tealdark">
          Cancel
        </Button>
        <Button type="submit" disabled={loading} className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
          {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
          {template ? 'Update Template' : 'Create Template'}
        </Button>
      </div>
    </form>
  );
};

export default TemplateForm;