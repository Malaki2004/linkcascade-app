import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { MousePointerClick, Users, DollarSign, Scale } from 'lucide-react';
import Seo from '@/components/Seo';
import { SITE_URL, APP_SIGNUP_URL, OG_IMAGE } from '@/lib/brand';

const TITLE = 'Track Links, Leads and Attributable Results | LinkCascade';
const DESCRIPTION =
  'Connect link activity with captured leads, recorded sales, and campaign results so you can focus on the channels producing meaningful outcomes.';

const ctaPrimary =
  'inline-flex items-center justify-center rounded-md bg-lc-teal px-6 py-3 text-base font-semibold text-lc-graphite transition-colors hover:bg-lc-teal/85 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark active:scale-[0.98]';

const blocks = [
  {
    icon: MousePointerClick,
    title: 'Clicks, captured automatically',
    text: 'Every time someone opens one of your short links, LinkCascade records it. You always know which links and campaigns are producing engagement.',
  },
  {
    icon: Users,
    title: 'Leads, captured where supported',
    text: 'Attach a lead-capture form to a tracked link and connect the people who respond to the exact link that brought them in.',
  },
  {
    icon: DollarSign,
    title: 'Sales and earnings, recorded by you',
    text: 'Log earnings by source and associate buyer activity with your links and campaigns, so your records sit next to the activity that produced them.',
  },
];

const EarnMorePage = () => {
  return (
    <>
      <Helmet>
        <title>{TITLE}</title>
        <meta name="description" content={DESCRIPTION} />
      </Helmet>
      <Seo title={TITLE} description={DESCRIPTION} image={OG_IMAGE} url={`${SITE_URL}/earn-more`} />

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <p className="font-serif text-lg italic text-lc-tealdark">Earn more from what you share</p>
          <h1 className="mt-3 max-w-3xl text-4xl font-extrabold tracking-tight text-lc-graphite md:text-5xl">
            Know which links lead to real opportunities
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-lc-slate">
            LinkCascade helps you compare link activity with captured leads, recorded sales, and the earnings
            information available inside your account—so you can focus your effort on the channels producing
            meaningful outcomes.
          </p>
          <div className="mt-8">
            <a href={APP_SIGNUP_URL} className={ctaPrimary}>
              Start Free
            </a>
          </div>
        </div>
      </section>

      <section className="border-b-2 border-lc-graphite bg-white">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <h2 className="text-3xl font-extrabold tracking-tight text-lc-graphite">
            Connect link activity to real outcomes
          </h2>
          <div className="mt-12 grid gap-x-10 gap-y-12 md:grid-cols-3">
            {blocks.map((block) => {
              const Icon = block.icon;
              return (
                <div key={block.title} className="border-t-2 border-lc-graphite pt-6">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-md bg-lc-teal">
                    <Icon className="h-5 w-5 text-lc-graphite" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-bold text-lc-graphite">{block.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-lc-slate">{block.text}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <div className="grid items-start gap-12 lg:grid-cols-2">
            <div>
              <h2 className="text-3xl font-extrabold tracking-tight text-lc-graphite">
                Compare, then decide where to focus
              </h2>
              <ul className="mt-8 space-y-5">
                {[
                  'Compare clicks, captured leads, and the results recorded in your account—per link and per campaign.',
                  'See which campaigns are producing meaningful engagement, not just raw traffic.',
                  'Use available attribution information to make better decisions about where to share next.',
                  'Export your earnings records to CSV on Pro and Agency plans for your own reporting.',
                ].map((point) => (
                  <li key={point} className="flex items-start gap-3 border-t-2 border-lc-graphite pt-4 text-lc-slate">
                    <Scale className="mt-1 h-4 w-4 shrink-0 text-lc-tealdark" aria-hidden="true" />
                    <span className="leading-relaxed">{point}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-xl border-2 border-lc-graphite bg-white p-6 shadow-[8px_8px_0_0_#0B1318]">
              <h3 className="text-lg font-bold text-lc-graphite">What LinkCascade does not do</h3>
              <p className="mt-3 text-sm leading-relaxed text-lc-slate">
                LinkCascade does not automatically verify affiliate commissions, external sales, or revenue that happen
                on other platforms. Clicks and captured leads are recorded automatically; sales and earnings figures
                come from what you record in your account or capture through supported lead forms. We would rather you
                trust the numbers than be impressed by them.
              </p>
              <p className="mt-4 text-sm leading-relaxed text-lc-slate">
                Want the full picture?{' '}
                <Link to="/features" className="font-semibold text-lc-tealdark underline-offset-4 hover:underline">
                  See every feature
                </Link>{' '}
                or{' '}
                <Link to="/how-it-works" className="font-semibold text-lc-tealdark underline-offset-4 hover:underline">
                  read how it works
                </Link>
                .
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-lc-graphite text-lc-offwhite">
        <div className="mx-auto max-w-6xl px-6 py-20 text-center">
          <h2 className="mx-auto max-w-2xl text-3xl font-extrabold tracking-tight md:text-4xl">
            Start connecting your links to results
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-lc-offwhite/75">
            Create your free account and see which of your shared links produce clicks, leads, and recorded results.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <a href={APP_SIGNUP_URL} className={ctaPrimary}>
              Start Free
            </a>
            <Link
              to="/pricing"
              className="inline-flex items-center justify-center rounded-md border-2 border-lc-offwhite px-6 py-3 text-base font-semibold text-lc-offwhite transition-colors hover:bg-lc-offwhite hover:text-lc-graphite focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-teal active:scale-[0.98]"
            >
              View Pricing
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default EarnMorePage;
