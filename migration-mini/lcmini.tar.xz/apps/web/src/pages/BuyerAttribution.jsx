/*
 * PHASE 1 ARCHITECTURE: Buyer Attribution
 * This component currently implements the UI and data presentation layer for buyer attributions.
 * Data is fetched from the 'buyer_attributions' table which currently contains mock/sample data 
 * seeded for UI testing purposes.
 * 
 * Future Phases:
 * Real webhooks integrations (Stripe, Shopify, WooCommerce) will be implemented to automatically
 * populate this table. The database structure is fully prepared for webhook handlers, and no
 * changes to existing tables or code paths are necessary.
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { 
  TrendingUp, 
  Users, 
  DollarSign, 
  Link as LinkIcon, 
  Search, 
  Filter, 
  Info,
  ChevronLeft,
  ChevronRight,
  ArrowUpDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const PLATFORMS = ['All', 'Stripe', 'Shopify', 'WooCommerce'];
const DATE_PRESETS = [
  { label: 'All Time', days: null },
  { label: 'Last 7 Days', days: 7 },
  { label: 'Last 30 Days', days: 30 },
  { label: 'Last 90 Days', days: 90 },
];

const BuyerAttribution = () => {
  const { user } = useAuth();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Filters state
  const [search, setSearch] = useState('');
  const [platform, setPlatform] = useState('All');
  const [dateRange, setDateRange] = useState(30); // 30 days default
  
  // Pagination and Sort state
  const [currentPage, setCurrentPage] = useState(1);
  const [sortConfig, setSortConfig] = useState({ key: 'purchase_timestamp', direction: 'desc' });
  const itemsPerPage = 10;

  useEffect(() => {
    fetchAttributions();
  }, []);

  const fetchAttributions = async () => {
    setLoading(true);
    try {
      // Phase 1: Load shared mock data directly without user_id filtering or joins
      const { data: attributions, error } = await supabase
        .from('buyer_attributions')
        .select('*')
        .order('purchase_timestamp', { ascending: false })
        .limit(50);

      if (error) throw error;
      setData(attributions || []);
    } catch (err) {
      console.error('Error fetching buyer attributions:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const filteredAndSortedData = useMemo(() => {
    let filtered = [...data];

    // Apply Search
    if (search) {
      const s = search.toLowerCase();
      filtered = filtered.filter(item => 
        (item.customer_name && item.customer_name.toLowerCase().includes(s)) ||
        (item.customer_email && item.customer_email.toLowerCase().includes(s)) ||
        (item.product_name && item.product_name.toLowerCase().includes(s))
      );
    }

    // Apply Platform
    if (platform !== 'All') {
      filtered = filtered.filter(item => item.source_platform === platform);
    }

    // Apply Date Range
    if (dateRange !== null) {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - dateRange);
      filtered = filtered.filter(item => new Date(item.purchase_timestamp) >= cutoffDate);
    }

    // Apply Sort
    filtered.sort((a, b) => {
      let aVal = a[sortConfig.key];
      let bVal = b[sortConfig.key];

      if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });

    return filtered;
  }, [data, search, platform, dateRange, sortConfig]);

  // Derived Metrics
  const metrics = useMemo(() => {
    const totalBuyers = new Set(filteredAndSortedData.map(d => d.customer_email)).size;
    const totalRevenue = filteredAndSortedData.reduce((sum, d) => sum + Number(d.order_value || 0), 0);
    const averageOrderValue = totalBuyers > 0 ? totalRevenue / totalBuyers : 0;
    
    // Top Channel Calculation based on raw link_id for Phase 1
    const linkCounts = {};
    filteredAndSortedData.forEach(d => {
      const linkName = d.link_id ? `Channel ID: ${d.link_id.substring(0, 8)}` : 'Organic/Direct';
      linkCounts[linkName] = (linkCounts[linkName] || 0) + 1;
    });
    const topLink = Object.entries(linkCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

    return { totalBuyers, totalRevenue, averageOrderValue, topLink };
  }, [filteredAndSortedData]);

  // Pagination
  const totalPages = Math.ceil(filteredAndSortedData.length / itemsPerPage);
  const paginatedData = filteredAndSortedData.slice(
    (currentPage - 1) * itemsPerPage, 
    currentPage * itemsPerPage
  );

  const formatCurrency = (amount, currency = 'USD') => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(amount);
  };

  const clearFilters = () => {
    setSearch('');
    setPlatform('All');
    setDateRange(30);
    setCurrentPage(1);
  };

  return (
    <>
      <Helmet>
        <title>Buyer Attribution - LinkCascade</title>
      </Helmet>

      <div className="p-6 md:p-8 max-w-7xl mx-auto min-h-screen">
        {/* Header & Info Banner */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 tracking-tight flex items-center gap-2">
            <TrendingUp className="w-8 h-8 text-purple-600" />
            Buyer Attribution
          </h1>
          
          <div className="mt-4 bg-blue-50 border border-blue-200 p-4 rounded-xl flex items-start gap-3 text-blue-800 shadow-sm">
            <Info className="w-5 h-5 flex-shrink-0 mt-0.5 text-blue-600" />
            <p className="text-sm font-medium">
              Phase 1 Preview Mode - Showing shared mock attribution data for UI testing. Live integrations coming soon.
            </p>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex items-center gap-4">
            <div className="bg-blue-50 p-3 rounded-lg text-blue-600">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Total Attributed Buyers</p>
              <p className="text-2xl font-bold text-gray-900">{metrics.totalBuyers}</p>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex items-center gap-4">
            <div className="bg-green-50 p-3 rounded-lg text-green-600">
              <DollarSign className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(metrics.totalRevenue)}</p>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex items-center gap-4">
            <div className="bg-purple-50 p-3 rounded-lg text-purple-600">
              <LinkIcon className="w-6 h-6" />
            </div>
            <div className="overflow-hidden">
              <p className="text-sm text-gray-500 font-medium">Top Converting Channel</p>
              <p className="text-lg font-bold text-gray-900 truncate" title={metrics.topLink}>
                {metrics.topLink}
              </p>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex items-center gap-4">
            <div className="bg-orange-50 p-3 rounded-lg text-orange-600">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500 font-medium">Average Order Value</p>
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(metrics.averageOrderValue)}</p>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm mb-6 flex flex-col lg:flex-row gap-4 justify-between items-end">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full lg:w-3/4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Search Buyers</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="Name, email, product..." 
                  value={search}
                  onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
                  className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Platform</label>
              <select 
                value={platform} 
                onChange={(e) => { setPlatform(e.target.value); setCurrentPage(1); }}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none"
              >
                {PLATFORMS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Date Range</label>
              <select 
                value={dateRange === null ? 'null' : dateRange} 
                onChange={(e) => { setDateRange(e.target.value === 'null' ? null : Number(e.target.value)); setCurrentPage(1); }}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none"
              >
                {DATE_PRESETS.map(p => <option key={p.label} value={p.days === null ? 'null' : p.days}>{p.label}</option>)}
              </select>
            </div>
          </div>
          
          <Button variant="outline" onClick={clearFilters} className="w-full lg:w-auto text-gray-600 border-gray-300 gap-2">
            <Filter className="w-4 h-4" /> Clear Filters
          </Button>
        </div>

        {/* Data Table */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200 text-xs uppercase tracking-wider text-gray-500 font-semibold">
                  <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('customer_name')}>
                    <div className="flex items-center gap-1">Buyer Name <ArrowUpDown className="w-3 h-3" /></div>
                  </th>
                  <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('product_name')}>
                    <div className="flex items-center gap-1">Product <ArrowUpDown className="w-3 h-3" /></div>
                  </th>
                  <th className="px-6 py-4 cursor-pointer hover:bg-gray-100 text-right" onClick={() => handleSort('order_value')}>
                    <div className="flex items-center justify-end gap-1">Order Value <ArrowUpDown className="w-3 h-3" /></div>
                  </th>
                  <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('purchase_timestamp')}>
                    <div className="flex items-center gap-1">Purchase Date <ArrowUpDown className="w-3 h-3" /></div>
                  </th>
                  <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('link_id')}>
                    <div className="flex items-center gap-1">Source Channel <ArrowUpDown className="w-3 h-3" /></div>
                  </th>
                  <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('source_platform')}>
                    <div className="flex items-center gap-1">Platform <ArrowUpDown className="w-3 h-3" /></div>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {loading ? (
                  <tr>
                    <td colSpan="6" className="px-6 py-10 text-center">
                      <div className="flex justify-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div></div>
                    </td>
                  </tr>
                ) : paginatedData.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="px-6 py-12 text-center text-gray-500">
                      <TrendingUp className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-lg font-medium text-gray-900">No attribution records found</p>
                      <p className="text-sm">Try adjusting your filters or search query.</p>
                    </td>
                  </tr>
                ) : (
                  paginatedData.map((row) => (
                    <tr key={row.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium text-gray-900">{row.customer_name || 'Anonymous'}</div>
                        <div className="text-sm text-gray-500 cursor-pointer hover:text-purple-600">
                          <a href={`mailto:${row.customer_email}`}>{row.customer_email}</a>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                        {row.product_name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900 text-right">
                        {formatCurrency(row.order_value, row.currency)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                        {new Date(row.purchase_timestamp).toLocaleDateString('en-US', {
                          year: 'numeric', month: 'short', day: 'numeric',
                          hour: '2-digit', minute: '2-digit'
                        })}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                        {row.link_id ? (
                          <div className="flex items-center gap-1.5 text-purple-700 font-medium">
                            <LinkIcon className="w-3.5 h-3.5" />
                            ID: {row.link_id.substring(0, 8)}
                          </div>
                        ) : (
                          <span className="text-gray-400 italic">Organic</span>
                        )}
                        {row.campaign_id && (
                          <div className="text-xs text-gray-500 mt-0.5 ml-5">
                            Camp: {row.campaign_id.substring(0, 8)}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border
                          ${row.source_platform === 'Stripe' ? 'bg-indigo-50 text-indigo-700 border-indigo-200' :
                            row.source_platform === 'Shopify' ? 'bg-green-50 text-green-700 border-green-200' :
                            row.source_platform === 'WooCommerce' ? 'bg-purple-50 text-purple-700 border-purple-200' :
                            'bg-gray-100 text-gray-800 border-gray-200'
                          }`}>
                          {row.source_platform}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          
          {/* Pagination Controls */}
          {!loading && filteredAndSortedData.length > 0 && (
            <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between bg-gray-50/50">
              <div className="text-sm text-gray-500">
                Showing <span className="font-medium text-gray-900">{((currentPage - 1) * itemsPerPage) + 1}</span> to <span className="font-medium text-gray-900">{Math.min(currentPage * itemsPerPage, filteredAndSortedData.length)}</span> of <span className="font-medium text-gray-900">{filteredAndSortedData.length}</span> results
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="bg-white"
                >
                  <ChevronLeft className="w-4 h-4 mr-1" /> Prev
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="bg-white"
                >
                  Next <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default BuyerAttribution;