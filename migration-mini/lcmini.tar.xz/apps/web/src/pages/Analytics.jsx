import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BarChart3, TrendingUp, MousePointer2, RefreshCw, Calendar, ChevronDown, Check, Loader2, Copy, ExternalLink } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { supabase } from '@/lib/supabaseClient';
import { useAnalyticsQueries } from '@/hooks/useAnalyticsQueries';

const Analytics = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const { getTotalClicks, getActiveLinks, getConversionRate, getAverageCTR } = useAnalyticsQueries();
  
  // State Management
  const [dateRange, setDateRange] = useState("30");
  const [dateRangeLabel, setDateRangeLabel] = useState("Last 30 Days");
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Data State
  const [links, setLinks] = useState([]);
  const [stats, setStats] = useState({
    totalClicks: 0,
    activeLinks: 0,
    avgCTR: "0.0%",
    conversionRate: "0.00%"
  });

  // Calculate start/end dates based on range
  const getDateRange = (range) => {
    const endDate = new Date();
    const startDate = new Date();
    
    // Set time to end of day for endDate to include today fully
    endDate.setHours(23, 59, 59, 999);
    
    // Set time to start of day for startDate
    startDate.setHours(0, 0, 0, 0);

    switch (range) {
      case "7":
        startDate.setDate(endDate.getDate() - 7);
        break;
      case "30":
        startDate.setDate(endDate.getDate() - 30);
        break;
      case "90":
        startDate.setDate(endDate.getDate() - 90);
        break;
      case "all":
        startDate.setFullYear(2020, 0, 1); 
        break;
      default:
        startDate.setDate(endDate.getDate() - 30);
    }
    
    return {
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString()
    };
  };

  const handleRefresh = async () => {
    if (!user?.id) return;
    
    setIsRefreshing(true);
    const { startDate, endDate } = getDateRange(dateRange);

    try {
      const [
        totalClicksData,
        activeLinksData,
        conversionData,
        ctrData
      ] = await Promise.all([
        getTotalClicks(user.id, startDate, endDate),
        getActiveLinks(user.id, startDate, endDate),
        getConversionRate(user.id, startDate, endDate),
        getAverageCTR(user.id, startDate, endDate)
      ]);

      setStats({
        totalClicks: totalClicksData,
        activeLinks: activeLinksData,
        avgCTR: activeLinksData > 0 ? ctrData : "0%",
        conversionRate: `${conversionData}%`
      });

      // Direct query to match user request: id, title, slug, campaign_id, source_channel, clicks(count), leads(count)
      const { data: linkPerformanceData, error } = await supabase
        .from('links')
        .select(`
          id, 
          title, 
          short_code, 
          original_url, 
          campaign_id, 
          source_channel, 
          created_at, 
          last_clicked_at,
          clicks(count),
          leads(count)
        `)
        .eq('user_id', user.id);
        
      if (error) throw error;

      setLinks(linkPerformanceData || []);
      
      toast({ title: "Success", description: "Analytics data updated." });

    } catch (error) {
      console.error("Error refreshing analytics:", error);
      toast({ 
        title: "Error", 
        description: "Failed to refresh data. Please try again.", 
        variant: "destructive" 
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleDateRangeSelect = (range, label) => {
    setDateRange(range);
    setDateRangeLabel(label);
  };

  const handleCopyLink = (shortCode) => {
    const url = `${window.location.origin}/r/${shortCode}`;
    navigator.clipboard.writeText(url);
    toast({ title: "Copied", description: "Short link copied to clipboard" });
  };

  useEffect(() => {
    handleRefresh();
  }, [user?.id, dateRange]);

  const statCards = [
    { title: "Total Clicks (In Range)", value: stats.totalClicks, icon: MousePointer2, color: "text-lc-tealdark", bg: "bg-lc-teal/15" },
    { title: "New Links (In Range)", value: stats.activeLinks, icon: TrendingUp, color: "text-green-600", bg: "bg-green-100" },
    { title: "Avg. Clicks/Link", value: stats.avgCTR, icon: BarChart3, color: "text-lc-tealdark", bg: "bg-lc-teal/15" },
    { title: "Conversion Rate", value: stats.conversionRate, icon: TrendingUp, color: "text-orange-600", bg: "bg-orange-100" }
  ];

  return (
    <>
      <Helmet><title>Analytics - LinkCascade</title></Helmet>
      <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Analytics</h1>
            <p className="text-gray-500 mt-2">Deep dive into your performance metrics.</p>
          </div>
          
          <div className="flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="border-gray-200 text-gray-700 hover:bg-gray-50 min-w-[160px] justify-between">
                  <span className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    {dateRangeLabel}
                  </span>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[160px]">
                {[
                  { label: "Last 7 Days", value: "7" },
                  { label: "Last 30 Days", value: "30" },
                  { label: "Last 90 Days", value: "90" },
                  { label: "All Time", value: "all" },
                ].map((option) => (
                  <DropdownMenuItem 
                    key={option.value}
                    onClick={() => handleDateRangeSelect(option.value, option.label)}
                    className={cn(
                      "cursor-pointer",
                      dateRange === option.value && "bg-lc-teal/10 text-lc-tealdark font-medium"
                    )}
                  >
                    {option.label}
                    {dateRange === option.value && <Check className="w-3 h-3 ml-auto" />}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Button 
              onClick={handleRefresh} 
              disabled={isRefreshing}
              className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite min-w-[120px]"
            >
              {isRefreshing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Refreshing...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh
                </>
              )}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {statCards.map((s, i) => {
            const Icon = s.icon;
            return (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                transition={{ delay: i * 0.05 }} 
                className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm"
              >
                <div className={`w-10 h-10 rounded-lg ${s.bg} flex items-center justify-center mb-4`}>
                   <Icon className={`w-5 h-5 ${s.color}`} />
                </div>
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">{s.title}</h3>
                <p className="text-2xl font-bold text-gray-900">{s.value}</p>
              </motion.div>
            )
          })}
        </div>

        {links.length === 0 ? (
          <div className="bg-white rounded-xl border border-dashed border-gray-300 p-16 text-center">
             <div className="w-16 h-16 bg-lc-teal/10 rounded-full flex items-center justify-center mx-auto mb-4">
               <BarChart3 className="w-8 h-8 text-lc-teal" />
             </div>
             <h3 className="text-xl font-bold text-gray-900 mb-2">No links found</h3>
             <p className="text-gray-500">Create new links to see performance data.</p>
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
             <div className="p-6 border-b border-gray-100 flex justify-between items-center">
               <h2 className="font-bold text-gray-900">Link Performance</h2>
               <span className="text-xs text-gray-500 font-medium px-2 py-1 bg-gray-100 rounded-full">
                 {links.length} links found
               </span>
             </div>
             <div className="overflow-x-auto">
               <table className="w-full">
                 <thead className="bg-gray-50 border-b border-gray-200">
                   <tr>
                     <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Link</th>
                     <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Created</th>
                     <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Source</th>
                     <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Total Clicks</th>
                     <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Total Leads</th>
                     <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase">Last Activity</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-gray-100">
                   {links.map(l => (
                     <tr key={l.id} className="hover:bg-gray-50/50 transition-colors">
                       <td className="px-6 py-4">
                         <div className="font-medium text-gray-900 mb-1">{l.title || "Untitled Link"}</div>
                         <div className="flex items-center gap-2">
                            <a 
                              href={`${window.location.origin}/r/${l.short_code}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-sm text-blue-600 hover:underline cursor-pointer flex items-center gap-1 font-mono"
                            >
                              {window.location.host}/r/{l.short_code}
                            </a>
                            <Button size="icon" variant="ghost" className="h-6 w-6 text-gray-400 hover:text-gray-600" onClick={() => handleCopyLink(l.short_code)} title="Copy Link">
                              <Copy className="w-3 h-3" />
                            </Button>
                            <a 
                               href={`${window.location.origin}/r/${l.short_code}`} 
                               target="_blank" 
                               rel="noopener noreferrer"
                               className="text-gray-400 hover:text-blue-600"
                               title="Open Link"
                            >
                              <ExternalLink className="w-3 h-3" />
                            </a>
                         </div>
                       </td>
                       <td className="px-6 py-4 text-gray-500 text-sm">{new Date(l.created_at).toLocaleDateString()}</td>
                       <td className="px-6 py-4 text-gray-500 text-sm">{l.source_channel || '-'}</td>
                       <td className="px-6 py-4 font-medium text-gray-900">
                         {l.clicks?.[0]?.count || 0}
                       </td>
                       <td className="px-6 py-4 font-medium text-gray-900">
                         {l.leads?.[0]?.count || 0}
                       </td>
                       <td className="px-6 py-4 text-gray-500 text-sm">
                         {l.last_clicked_at ? new Date(l.last_clicked_at).toLocaleDateString() : '-'}
                       </td>
                     </tr>
                   ))}
                 </tbody>
               </table>
             </div>
          </div>
        )}
      </div>
    </>
  );
};

export default Analytics;