import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, ArrowLeft, Key, Loader2, CheckCircle } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Helmet } from 'react-helmet';

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Trim and lowercase email input
    const emailToReset = email.trim().toLowerCase();

    if (!emailToReset) {
      toast({
        title: "Email required",
        description: "Please enter your email address.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);

    try {
      console.log("Attempting password reset for:", emailToReset);

      // We explicitly set the redirect URL to our reset-password page
      // This ensures the link in the email goes to the correct route to handle the token exchange
      const redirectTo = `${window.location.origin}/reset-password`;

      const { data, error } = await supabase.auth.resetPasswordForEmail(emailToReset, {
        redirectTo: redirectTo,
      });

      console.log("resetPasswordForEmail result", { data, error });

      if (error) {
        throw error;
      }

      setSuccess(true);
      toast({
        title: 'Success',
        description: 'Reset link sent successfully.',
      });

    } catch (error) {
      console.error("Reset password error:", error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to send reset link.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Forgot Password - LinkCascade</title>
        <meta name="description" content="Reset your LinkCascade account password." />
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>
      <div className="min-h-screen flex items-center justify-center bg-lc-graphite p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <div className="bg-white rounded-xl shadow-xl p-8">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-lc-teal/15 rounded-full mb-4">
                <Key className="w-8 h-8 text-lc-tealdark" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">Forgot Password?</h1>
              <p className="text-gray-600 mt-2">
                {success 
                  ? 'Check your email for the reset link' 
                  : 'Enter your email to receive reset instructions'}
              </p>
            </div>

            {!success ? (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-lc-teal focus:border-transparent transition outline-none bg-white text-gray-900"
                      placeholder="you@example.com"
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-lc-teal hover:bg-lc-tealdark text-lc-graphite py-3 rounded-lg font-bold shadow-lg transition-all hover:shadow-xl"
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    'Send Reset Link'
                  )}
                </Button>
              </form>
            ) : (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6 text-center"
              >
                <div className="flex justify-center mb-3">
                  <CheckCircle className="w-12 h-12 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold text-green-900 mb-2">Reset Link Sent</h3>
                <p className="text-green-800 text-sm">
                  We've sent a password reset link to <strong>{email}</strong>.
                </p>
                <p className="text-green-700 text-xs mt-2">
                  Please check your inbox (and spam folder) for the link.
                </p>
              </motion.div>
            )}

            <div className="mt-6 text-center">
              <Link
                to="/login"
                className="inline-flex items-center text-lc-tealdark hover:text-lc-tealdark font-medium transition"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Login
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default ForgotPasswordPage;