import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Copy, Edit, Trash2, Search, ExternalLink, Link2, Lock, CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { PLAN_LIMITS } from '@/lib/constants';
import { useNavigate, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Helmet } from 'react-helmet';
import { generateShortLink, getShortLinkUrl } from '@/utils/linkGeneration';
import { useLinkData } from '@/hooks/useLinkData';

const SOURCE_CHANNELS = ['Facebook', 'Instagram', 'TikTok', 'YouTube', 'Email', 'LinkedIn', 'Website', 'Other'];

const LinkVault = () => {
  const { user, userProfile, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  const highlightLinkId = location.state?.highlightLinkId || null;
  
  // Using shared hook - same data as Dashboard
  const { links, setLinks, loading: linksLoading, error: linksError, fetchLinks } = useLinkData();
  
  const [campaigns, setCampaigns] = useState([]);
  const [campaignsLoading, setCampaignsLoading] = useState(true);
  const [filteredLinks, setFilteredLinks] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const [editingLink, setEditingLink] = useState(null);
  const [formData, setFormData] = useState({ 
    title: '', 
    original_url: '', 
    campaign_id: '', 
    source_channel: '' 
  });

  const currentPlan = userProfile?.plan || 'free';
  const maxLinks = PLAN_LIMITS[currentPlan]?.maxLinks || 5;
  const canCreateLink = maxLinks === -1 || links.length < maxLinks;
  const canUseLeadCapture = currentPlan === 'pro' || currentPlan === 'agency';

  useEffect(() => {
    if (!authLoading && user?.id) {
      const fetchCampaigns = async () => {
        try {
          const { data, error } = await supabase.from('campaigns').select('id, name').eq('user_id', user.id).order('name', { ascending: true });
          if (!error) setCampaigns(data || []);
        } finally {
          setCampaignsLoading(false);
        }
      };
      fetchCampaigns();
    } else if (!authLoading) {
      setCampaignsLoading(false);
    }
  }, [user?.id, authLoading]);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredLinks(links);
    } else {
      const lower = searchQuery.toLowerCase();
      setFilteredLinks(links.filter(l => 
        l.title?.toLowerCase().includes(lower) || 
        l.original_url?.toLowerCase().includes(lower) ||
        l.short_code?.toLowerCase().includes(lower)
      ));
    }
  }, [searchQuery, links]);

  const loading = linksLoading || campaignsLoading;

  const handleCreate = async (e) => {
    // Prevent form submission if event exists
    if (e) {
      e.preventDefault();
    }
    
    // Validate form fields
    if (!formData.title || !formData.title.trim()) {
      toast.error('Link title is required.');
      return;
    }
    
    if (!formData.original_url || !formData.original_url.trim()) {
      toast.error('Destination URL is required.');
      return;
    }
    
    // Check link limit
    if (!canCreateLink) {
      toast.error('Upgrade your plan to create more links.');
      return;
    }
    
    setIsSaving(true);
    
    try {
      // Get authenticated user
      const { data: { user: currentUser }, error: userError } = await supabase.auth.getUser();
      
      if (userError) throw userError;
      if (!currentUser) {
        throw new Error('User not authenticated');
      }
      
      // Generate short code inline
      const shortCode = Math.random().toString(36).substring(2, 8);
      
      // Create insert payload
      const payload = {
        user_id: currentUser.id,
        title: formData.title.trim(),
        original_url: formData.original_url.trim(),
        short_code: shortCode,
        clicks: 0,
        enable_lead_capture: false,
        campaign_id: formData.campaign_id || null,
        source_channel: formData.source_channel || null
      };

      // Insert into links table ONLY
      const { data, error } = await supabase
        .from('links')
        .insert([payload])
        .select('*, campaigns(name), clicks(count)')
        .single();

      if (error) throw error;
      
      // Clear form fields
      setFormData({ 
        title: '', 
        original_url: '', 
        campaign_id: '', 
        source_channel: '' 
      });
      
      // Close dialog
      setIsCreateOpen(false);
      
      // Show success toast
      toast.success("Link created successfully!");
      
      // Force full page reload
      window.location.reload();
      
    } catch (error) {
      // Log full error details to console
      console.error('LinkVault create link failed:', error);
      
      // Show error toast with real error message
      toast.error(`Error creating link. ${error?.message || 'Unknown error'}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const updates = {
        title: formData.title,
        original_url: formData.original_url,
        campaign_id: formData.campaign_id || null,
        source_channel: formData.source_channel || null,
      };

      const { data, error } = await supabase.from('links')
        .update(updates)
        .eq('id', editingLink.id)
        .select('*, campaigns(name), clicks(count)')
        .single();

      if (error) throw error;
      
      await supabase.from("public_links").update({ original_url: formData.original_url }).eq('short_code', editingLink.short_code);

      setLinks(links.map(l => l.id === editingLink.id ? data : l));
      setEditingLink(null);
      resetForm();
      toast.success('Link updated successfully.');
    } catch (error) {
      console.error('Link update error:', error);
      const errorMessage = error?.message || error?.details || 'Failed to update link.';
      toast.error(errorMessage);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this link?')) return;
    try {
      const { error } = await supabase.from('links').delete().eq('id', id);
      if (error) throw error;
      setLinks(links.filter(l => l.id !== id));
      toast.success('Link removed.');
    } catch (error) {
      console.error('Link deletion error:', error);
      const errorMessage = error?.message || error?.details || 'Failed to delete link.';
      toast.error(errorMessage);
    }
  };

  const handleToggleLeadCapture = async (id, currentVal) => {
    if (!canUseLeadCapture) {
      toast.error('Lead capture is available on Pro and Agency plans.');
      return;
    }

    const newVal = !currentVal;
    try {
      const { error } = await supabase.from('links').update({ enable_lead_capture: newVal }).eq('id', id);
      if (error) throw error;
      
      setLinks(links.map(l => l.id === id ? { ...l, enable_lead_capture: newVal } : l));
      toast.success(newVal ? 'Lead Capture Enabled' : 'Lead Capture Disabled');
    } catch (error) {
      console.error('Lead capture toggle error:', error);
      const errorMessage = error?.message || error?.details || 'Failed to update lead capture settings.';
      toast.error(errorMessage);
    }
  };

  const handleOpenLink = (shortCode) => {
    const shortUrl = getShortLinkUrl(shortCode);
    window.open(shortUrl, "_blank", "noopener,noreferrer");
  };

  const getShortLinkText = (code) => {
    return generateShortLink(code);
  };

  const copyLink = (code) => {
    const url = getShortLinkUrl(code);
    navigator.clipboard.writeText(url);
    toast.success('Short link copied to clipboard.');
  };

  const openEditModal = (link) => {
    setEditingLink(link);
    setFormData({
      title: link.title || '',
      original_url: link.original_url || '',
      campaign_id: link.campaign_id || '',
      source_channel: link.source_channel || ''
    });
  };

  const resetForm = () => {
    setFormData({ title: '', original_url: '', campaign_id: '', source_channel: '' });
  };

  if (linksError) {
    console.error(linksError);
  }

  return (
    <>
      <Helmet><title>Link Vault - LinkCascade</title></Helmet>
      
      <div className="p-6 md:p-8 max-w-7xl mx-auto min-h-screen">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Link Vault</h1>
            <p className="text-gray-500 mt-2">Manage and track your shortened links.</p>
          </div>
          <div className="flex gap-3 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search links..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none bg-white text-gray-900"
              />
            </div>

            {!canCreateLink ? (
              <Button onClick={() => navigate('/pricing')} className="shrink-0 bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
                Upgrade Plan
              </Button>
            ) : (
              <Dialog open={isCreateOpen} onOpenChange={(val) => { setIsCreateOpen(val); if(!val) resetForm(); }}>
                <DialogTrigger asChild>
                  <Button className="shrink-0 bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
                    <Plus className="w-4 h-4 mr-2" /> Create Link
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>Create New Link</DialogTitle></DialogHeader>
                  <form onSubmit={handleCreate} className="space-y-4 pt-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                      <input required disabled={isSaving} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none bg-white text-gray-900" placeholder="e.g. Summer Promo" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Destination URL</label>
                      <input required type="url" disabled={isSaving} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none bg-white text-gray-900" placeholder="https://..." value={formData.original_url} onChange={e => setFormData({...formData, original_url: e.target.value})} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Campaign (Optional)</label>
                      <select disabled={isSaving} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none bg-white text-gray-900" value={formData.campaign_id} onChange={e => setFormData({...formData, campaign_id: e.target.value})}>
                        <option value="">No Campaign</option>
                        {campaigns.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Source Channel (Optional)</label>
                      <select disabled={isSaving} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none bg-white text-gray-900" value={formData.source_channel} onChange={e => setFormData({...formData, source_channel: e.target.value})}>
                        <option value="">Select Channel</option>
                        {SOURCE_CHANNELS.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <Button type="submit" disabled={isSaving} className="w-full bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
                      {isSaving ? 'Creating...' : 'Create Link'}
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>

        {!canCreateLink && (
           <div className="bg-lc-teal/10 p-6 rounded-xl mb-8 border border-lc-border flex flex-col md:flex-row items-center justify-between gap-4">
              <div>
                 <h3 className="font-bold text-gray-900 flex items-center gap-2">
                   <Lock className="w-4 h-4 text-lc-tealdark" />
                   Link Limit Reached
                 </h3>
                 <p className="text-gray-600 text-sm mt-1">
                   You've reached your plan's limit of {maxLinks} links. Upgrade to Pro for unlimited links and advanced analytics.
                 </p>
              </div>
              <Button onClick={() => navigate('/pricing')} className="shrink-0 bg-lc-teal hover:bg-lc-tealdark w-full md:w-auto text-lc-graphite">
                Upgrade to Pro
              </Button>
           </div>
        )}

        {loading ? (
          <div className="flex justify-center py-20"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-lc-teal"></div></div>
        ) : filteredLinks.length === 0 ? (
          <div className="bg-white rounded-xl border border-dashed border-gray-300 p-16 text-center">
            <div className="w-16 h-16 bg-lc-teal/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Link2 className="w-8 h-8 text-lc-teal" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">No links found</h3>
            <p className="text-gray-500 mb-6">Create your first link to start tracking.</p>
            <Button onClick={() => setIsCreateOpen(true)} className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">Create Link</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredLinks.map(link => {
              const isHighlighted = link.id === highlightLinkId;

              return (
                <motion.div 
                  key={link.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  style={isHighlighted ? { backgroundColor: '#fffbeb', borderColor: '#f59e0b', borderWidth: '2px' } : {}}
                  className={cn(
                    "rounded-xl border transition-all duration-300 p-5 flex flex-col group",
                    !isHighlighted && (link.enable_lead_capture 
                      ? "border-lc-teal bg-lc-teal/5 shadow-md hover:shadow-lg" 
                      : "border-gray-200 bg-white shadow-sm hover:shadow-md")
                  )}
                >
                  <div className="flex justify-between items-start mb-4">
                    <div 
                      onClick={() => handleOpenLink(link.short_code)}
                      className={`p-2 rounded-lg transition-colors cursor-pointer ${isHighlighted ? 'text-amber-700 hover:bg-amber-100' : 'text-gray-600 hover:bg-lc-teal/15 hover:text-lc-tealdark'}`}
                      aria-label="Open link"
                      title="Open Short Link"
                    >
                      <ExternalLink className="w-5 h-5" />
                    </div>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" className={`h-8 w-8 ${isHighlighted ? 'text-amber-600 hover:text-amber-800' : 'text-gray-400 hover:text-lc-tealdark'}`} onClick={() => copyLink(link.short_code)} title="Copy Short Link">
                        <Copy className="w-4 h-4" />
                      </Button>
                      <Dialog open={editingLink?.id === link.id} onOpenChange={(val) => { if(!val && !isSaving) setEditingLink(null); }}>
                        <DialogTrigger asChild>
                          <Button size="icon" variant="ghost" className={`h-8 w-8 ${isHighlighted ? 'text-amber-600 hover:text-amber-800' : 'text-gray-400 hover:text-gray-900'}`} onClick={() => openEditModal(link)}>
                            <Edit className="w-4 h-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                            <DialogHeader><DialogTitle>Edit Link</DialogTitle></DialogHeader>
                            <form onSubmit={handleUpdate} className="space-y-4 pt-4">
                              <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                                <input required disabled={isSaving} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none bg-white text-gray-900" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} />
                              </div>
                              <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Destination URL</label>
                                <input required type="url" disabled={isSaving} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none bg-white text-gray-900" value={formData.original_url} onChange={e => setFormData({...formData, original_url: e.target.value})} />
                              </div>
                              <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Campaign (Optional)</label>
                                <select disabled={isSaving} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none bg-white text-gray-900" value={formData.campaign_id} onChange={e => setFormData({...formData, campaign_id: e.target.value})}>
                                  <option value="">No Campaign</option>
                                  {campaigns.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                </select>
                              </div>
                              <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Source Channel (Optional)</label>
                                <select disabled={isSaving} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none bg-white text-gray-900" value={formData.source_channel} onChange={e => setFormData({...formData, source_channel: e.target.value})}>
                                  <option value="">Select Channel</option>
                                  {SOURCE_CHANNELS.map(c => <option key={c} value={c}>{c}</option>)}
                                </select>
                              </div>
                              <Button type="submit" disabled={isSaving} className="w-full bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
                                {isSaving ? 'Updating...' : 'Update Link'}
                              </Button>
                            </form>
                        </DialogContent>
                      </Dialog>
                      <Button size="icon" variant="ghost" className={`h-8 w-8 ${isHighlighted ? 'text-amber-600 hover:text-red-600' : 'text-gray-400 hover:text-red-600'}`} onClick={() => handleDelete(link.id)} title="Delete Link">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold text-gray-900 line-clamp-1" title={link.title}>{link.title}</h3>
                      {link.enable_lead_capture && (
                        <span className="bg-lc-teal text-lc-graphite flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap shadow-sm">
                          <CheckCircle2 className="w-3 h-3" />
                          Lead Capture ON
                        </span>
                      )}
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mb-3 mt-1">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${isHighlighted ? 'bg-amber-100 text-amber-800 border-amber-200' : 'bg-blue-50 text-blue-700 border-blue-100'}`}>
                        Camp: {link.campaigns?.name || '-'}
                      </span>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${isHighlighted ? 'bg-amber-100 text-amber-800 border-amber-200' : 'bg-orange-50 text-orange-700 border-orange-100'}`}>
                        Src: {link.source_channel || '-'}
                      </span>
                    </div>

                    <div 
                      onClick={() => handleOpenLink(link.short_code)}
                      className={`flex items-center gap-2 text-sm px-2 py-1.5 rounded-md w-fit max-w-full cursor-pointer transition-colors border ${isHighlighted ? 'text-amber-700 bg-amber-100/50 border-amber-200 hover:bg-amber-200' : 'text-lc-tealdark bg-lc-teal/10 border-lc-border hover:bg-lc-teal/20'}`}
                    >
                      <Link2 className="w-4 h-4 flex-shrink-0" />
                      <span className="truncate font-mono font-medium">{getShortLinkText(link.short_code)}</span>
                    </div>
                    <a href={link.original_url} target="_blank" rel="noopener noreferrer" className={`text-xs mt-3 truncate block transition-colors ${isHighlighted ? 'text-amber-600 hover:text-amber-800' : 'text-gray-500 hover:text-lc-tealdark'}`}>
                      {link.original_url}
                    </a>
                  </div>

                  <div className={`mt-auto border-t pt-4 ${isHighlighted ? 'border-amber-200' : 'border-gray-100'}`}>
                    <div className={cn(
                      "flex items-center justify-between rounded-lg p-3 mb-4 border transition-colors",
                      isHighlighted 
                        ? (link.enable_lead_capture ? "bg-amber-100 border-amber-300" : "bg-white/50 border-amber-200") 
                        : (link.enable_lead_capture ? "bg-lc-teal/10 border-lc-border" : "bg-gray-50 border-gray-100")
                    )}>
                      <div className="flex flex-col pr-3">
                        <span className={`text-sm font-semibold ${isHighlighted ? 'text-amber-900' : 'text-gray-900'}`}>Enable Lead Capture</span>
                        <span className={`text-xs mt-0.5 ${isHighlighted ? 'text-amber-700' : 'text-gray-500'}`}>
                          {link.enable_lead_capture 
                            ? "Visitors will see a form before redirecting" 
                            : "Visitors will redirect immediately"}
                        </span>
                      </div>
                      <Switch 
                        checked={link.enable_lead_capture || false}
                        disabled={!canUseLeadCapture}
                        onCheckedChange={() => handleToggleLeadCapture(link.id, link.enable_lead_capture)}
                      />
                    </div>

                    <div style={{fontSize: '13px', color: '#666', marginBottom: '8px'}}><strong>Clicks:</strong> {link.clicks?.[0]?.count || 0}</div>

                    <div className="grid grid-cols-2 gap-2 text-center mt-2 border-t pt-2 border-dashed border-gray-200">
                      <div>
                        <div className={`text-xs uppercase font-semibold mb-1 ${isHighlighted ? 'text-amber-700' : 'text-gray-500'}`}>Created</div>
                        <div className={`font-bold text-[10px] md:text-xs py-1 ${isHighlighted ? 'text-amber-900' : 'text-gray-900'}`}>
                          {link.created_at ? new Date(link.created_at).toLocaleDateString() : 'N/A'}
                        </div>
                      </div>
                      <div className={`border-l ${isHighlighted ? 'border-amber-200' : 'border-gray-200'}`}>
                        <div className={`text-xs uppercase font-semibold mb-1 ${isHighlighted ? 'text-amber-700' : 'text-gray-500'}`}>Activity</div>
                        <div className={`font-bold text-[10px] md:text-xs py-1 ${isHighlighted ? 'text-amber-900' : 'text-gray-900'}`}>
                          {link.last_activity ? new Date(link.last_activity).toLocaleDateString('en-US', { month: 'numeric', day: 'numeric', year: 'numeric' }) : '-'}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
};

export default LinkVault;