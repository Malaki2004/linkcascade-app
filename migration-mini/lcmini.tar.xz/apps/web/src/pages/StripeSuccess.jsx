import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, XCircle, Loader2, ArrowRight, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Helmet } from 'react-helmet';

const StripeSuccess = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  
  const [status, setStatus] = useState('loading'); // 'loading', 'success', 'error'
  const [sessionId, setSessionId] = useState(null);

  useEffect(() => {
    // Wait for auth to initialize
    if (authLoading) return;

    const urlSessionId = searchParams.get('session_id');

    // 1. Handle Unauthenticated User
    if (!user) {
      if (urlSessionId) {
        // Save to localStorage as requested
        localStorage.setItem('stripe_session_id_pending', urlSessionId);
        
        // Redirect to login with next param, only the base path is encoded in 'next'
        const nextPath = '/billing/stripe-success'; // The path without session_id
        navigate(`/login?next=${encodeURIComponent(nextPath)}`);
      } else {
        // No session ID in URL and not logged in, just go to login
        navigate('/login');
      }
      return;
    }

    // 2. Handle Authenticated User
    let finalSessionId = urlSessionId;

    // If missing from URL, check localStorage
    if (!finalSessionId) {
      const storedSessionId = localStorage.getItem('stripe_session_id_pending');
      if (storedSessionId) {
        finalSessionId = storedSessionId;
        // Clear it after retrieval
        localStorage.removeItem('stripe_session_id_pending');
      }
    }

    // 3. Set Final State
    if (finalSessionId) {
      setSessionId(finalSessionId);
      setStatus('success');
      
      // Optional: Auto-redirect after a delay for better UX
      const timer = setTimeout(() => {
        navigate('/settings');
      }, 5000);
      return () => clearTimeout(timer);
    } else {
      setStatus('error');
    }

  }, [user, authLoading, searchParams, navigate]);

  return (
    <>
      <Helmet>
        <title>Payment Status - LinkCascade</title>
        <meta name="description" content="Processing your subscription payment." />
      </Helmet>
      
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 to-indigo-100 p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-lg"
        >
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
            <div className="p-8 text-center">
              
              {/* LOADING STATE */}
              {status === 'loading' && (
                <div className="py-8">
                  <div className="relative mx-auto w-20 h-20 mb-6">
                    <div className="absolute inset-0 bg-purple-100 rounded-full animate-pulse"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Loader2 className="w-10 h-10 text-purple-600 animate-spin" />
                    </div>
                  </div>
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">
                    Activating your plan...
                  </h1>
                  <p className="text-gray-600">
                    Please wait while we process your payment.
                  </p>
                </div>
              )}

              {/* SUCCESS STATE */}
              {status === 'success' && (
                <div className="py-4">
                  <motion.div 
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="mx-auto w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6"
                  >
                    <CheckCircle className="w-10 h-10 text-green-600" />
                  </motion.div>
                  
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">
                    Payment detected!
                  </h1>
                  <p className="text-gray-600 mb-6">
                    Payment detected — next step is plan activation.
                  </p>

                  <div className="bg-gray-50 rounded-lg p-4 mb-6 border border-gray-200">
                    <div className="flex items-center justify-center gap-2 text-sm text-gray-500 font-mono break-all">
                      <ShieldCheck className="w-4 h-4 text-purple-500 flex-shrink-0" />
                      <span>Session ID: {sessionId}</span>
                    </div>
                  </div>

                  <p className="text-sm text-gray-500 mb-8">
                    Your plan is being activated. You'll be redirected shortly.
                  </p>

                  <Button asChild className="w-full bg-purple-600 hover:bg-purple-700">
                    <Link to="/settings">
                      Go to Settings <ArrowRight className="ml-2 w-4 h-4" />
                    </Link>
                  </Button>
                </div>
              )}

              {/* ERROR STATE */}
              {status === 'error' && (
                <div className="py-8">
                  <div className="mx-auto w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mb-6">
                    <XCircle className="w-10 h-10 text-amber-600" />
                  </div>
                  
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">
                    Payment confirmation pending
                  </h1>
                  <p className="text-gray-600 mb-8">
                    We couldn't confirm your payment yet. If you believe this is an error, please contact support or check your settings.
                  </p>

                  <Button asChild variant="outline" className="w-full">
                    <Link to="/settings">
                      Return to Settings
                    </Link>
                  </Button>
                </div>
              )}

            </div>
            
            {/* Footer decoration */}
            <div className="bg-gray-50 px-8 py-4 border-t border-gray-100 flex justify-center">
              <p className="text-xs text-gray-400">
                Secure payment processing via Stripe
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default StripeSuccess;