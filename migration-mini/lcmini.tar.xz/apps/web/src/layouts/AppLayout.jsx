import React from 'react';
import { Outlet } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Sidebar from '@/components/Sidebar';
import SupportWidget from '@/components/SupportWidget';

const AppLayout = () => {
  return (
    <div className="flex min-h-screen w-full bg-gray-50 relative">
      <Helmet>
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>
      <Sidebar />
      <main className="flex-1 overflow-x-hidden overflow-y-auto h-screen w-full">
        <div className="container mx-auto p-8">
          <Outlet />
        </div>
      </main>
      <SupportWidget />
    </div>
  );
};

export default AppLayout;