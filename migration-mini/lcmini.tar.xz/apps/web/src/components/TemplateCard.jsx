import React from 'react';
import { Copy, Star, Edit, Trash2, ShieldCheck, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { copyToClipboard, highlightPlaceholders } from '@/lib/templateUtils';
import { motion } from 'framer-motion';

const TemplateCard = ({ template, isCustom, onEdit, onDelete, onToggleFavorite, onUseCreate }) => {
  const isSystem = template.user_id === null || !isCustom; // Adjust logic based on context

  const handleCopy = () => {
    copyToClipboard(template.body || template.content);
  };

  const getPlatformColor = (platform) => {
    switch (platform?.toLowerCase()) {
      case 'email': return 'bg-lc-teal/10 text-lc-tealdark border-lc-border';
      case 'instagram': return 'bg-pink-50 text-pink-700 border-pink-100';
      case 'twitter': return 'bg-sky-50 text-sky-700 border-sky-100';
      case 'linkedin': return 'bg-indigo-50 text-indigo-700 border-indigo-100';
      case 'sms': return 'bg-green-50 text-green-700 border-green-100';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getToneColor = (tone) => {
    return 'bg-gray-50 text-gray-600 border-gray-200';
  };

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white rounded-xl shadow-sm border p-5 flex flex-col h-full hover:shadow-lg transition-all duration-200 group relative ${isSystem ? 'border-indigo-200 bg-indigo-50/10' : 'border-gray-200'}`}
    >
      {isSystem && (
        <div className="absolute -top-3 -right-2 bg-indigo-100 text-indigo-700 text-[10px] font-bold px-2 py-1 rounded-full flex items-center gap-1 shadow-sm border border-indigo-200">
          <ShieldCheck className="w-3 h-3" /> System Template
        </div>
      )}

      <div className="flex justify-between items-start mb-4">
        <div className="pr-4">
          <h3 className="font-bold text-gray-900 line-clamp-1 text-base" title={template.title}>
            {template.title}
          </h3>
          {template.category && (
             <p className="text-xs text-gray-500 mt-1">{template.category}</p>
          )}
          <div className="flex gap-2 mt-2 flex-wrap">
            {template.platform && (
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border uppercase tracking-wide ${getPlatformColor(template.platform)}`}>
                {template.platform}
              </span>
            )}
            {template.tone && (
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border uppercase tracking-wide ${getToneColor(template.tone)}`}>
                {template.tone}
              </span>
            )}
          </div>
        </div>
        <button 
          onClick={() => onToggleFavorite && onToggleFavorite(template)}
          className={`transition-colors p-1 rounded-md hover:bg-lc-teal/10 ${template.is_favorite ? 'text-yellow-400' : 'text-gray-300 hover:text-yellow-400'}`}
        >
          <Star className={`w-5 h-5 ${template.is_favorite ? 'fill-current' : ''}`} />
        </button>
      </div>

      <div className="flex-1 bg-gray-50/50 rounded-lg p-3 mb-4 border border-gray-100 overflow-hidden">
        <p className="text-sm text-gray-600 font-mono whitespace-pre-wrap line-clamp-4 leading-relaxed">
          {highlightPlaceholders(template.body || template.content)}
        </p>
      </div>

      <div className="flex items-center gap-2 pt-2">
        <Button variant="outline" size="sm" className="flex-1 gap-2 border-gray-200 hover:bg-lc-teal/10 text-gray-700 hover:text-lc-tealdark" onClick={handleCopy}>
          <Copy className="w-3.5 h-3.5" />
          Copy
        </Button>
        
        {isSystem && onUseCreate && (
          <Button variant="secondary" size="sm" className="bg-indigo-50 text-indigo-700 hover:bg-indigo-100 gap-1" onClick={() => onUseCreate(template)}>
            <Sparkles className="w-3.5 h-3.5" /> Use
          </Button>
        )}

        {!isSystem && onEdit && onDelete && (
          <div className="flex gap-1 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
            <Button variant="ghost" size="icon" className="h-9 w-9 text-gray-400 hover:text-lc-tealdark" onClick={() => onEdit(template)}>
              <Edit className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-9 w-9 text-gray-400 hover:text-red-600" onClick={() => onDelete(template)}>
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default TemplateCard;