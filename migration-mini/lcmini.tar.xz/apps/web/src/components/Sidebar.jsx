import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import {
  LayoutDashboard,
  Link2,
  Megaphone,
  FileText,
  Sparkles,
  DollarSign,
  BarChart3,
  Settings,
  LogOut,
  ChevronLeft,
  Users,
  Zap,
  Loader2
} from 'lucide-react';

const Sidebar = () => {
  const location = useLocation();
  const { user, signOut } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [userPlan, setUserPlan] = useState('free');
  const [loadingPlan, setLoadingPlan] = useState(true);

  useEffect(() => {
    const fetchPlan = async () => {
      if (!user) {
        setLoadingPlan(false);
        return;
      }
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('plan')
          .eq('id', user.id)
          .single();
        
        if (error) throw error;
        setUserPlan(data?.plan || 'free');
      } catch (err) {
        console.error('Error fetching plan in Sidebar:', err);
        setUserPlan('free');
      } finally {
        setLoadingPlan(false);
      }
    };

    fetchPlan();
  }, [user]);

  const hasProAccess = userPlan === 'pro' || userPlan === 'agency';

  // Base navigation items
  const baseNavItems = [
    { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/links', label: 'Link Vault', icon: Link2 },
    { href: '/campaigns', label: 'Campaigns', icon: Megaphone },
  ];

  // Pro/Agency navigation items
  const proNavItems = [
    { href: '/lead-attribution', label: 'Lead Attribution', icon: Users },
    { href: '/lead-capture-setup', label: 'Lead Capture Setup', icon: Zap },
  ];

  // Rest of navigation items
  const restNavItems = [
    { href: '/analytics', label: 'Analytics', icon: BarChart3 },
    { href: '/templates', label: 'Templates', icon: FileText },
    { href: '/copy', label: 'Copy Generator', icon: Sparkles },
    { href: '/earnings', label: 'Earnings', icon: DollarSign },
    { href: '/settings', label: 'Settings', icon: Settings },
  ];

  const navItems = [
    ...baseNavItems,
    ...(!loadingPlan && hasProAccess ? proNavItems : []),
    ...restNavItems
  ];

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-white border-r border-gray-200">
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-lc-teal rounded-lg flex items-center justify-center">
            <Link2 className="w-5 h-5 text-lc-graphite" />
          </div>
          <span className="text-xl font-extrabold text-lc-graphite tracking-tight">
            LinkCascade
          </span>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.href || (item.href === '/templates' && location.pathname.startsWith('/message-templates'));
          
          return (
            <Link
              key={item.href}
              to={item.href}
              onClick={() => setIsMobileMenuOpen(false)}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg text-sm transition-all duration-200 group",
                isActive
                  ? "bg-lc-teal/10 text-lc-tealdark font-bold border-l-[3px] border-lc-teal shadow-sm"
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900 font-medium"
              )}
            >
              <Icon
                size={20}
                className={cn(
                  "transition-colors",
                  isActive ? "text-lc-tealdark" : "text-gray-400 group-hover:text-gray-600"
                )}
              />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-100">
        {loadingPlan ? (
          <div className="flex items-center justify-center py-2 text-gray-400">
            <Loader2 className="w-5 h-5 animate-spin" />
          </div>
        ) : (
          <div className="px-4 py-2 mb-2">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Plan: {userPlan}</span>
          </div>
        )}
        <Button
          variant="ghost"
          className="w-full justify-start text-gray-600 hover:text-red-600 hover:bg-red-50 gap-3 px-4"
          onClick={() => signOut()}
        >
          <LogOut size={20} />
          <span className="font-medium">Sign Out</span>
        </Button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile Overlay */}
      <div className={`md:hidden fixed inset-0 z-40 bg-black/50 transition-opacity ${isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={() => setIsMobileMenuOpen(false)} />
      
      {/* Mobile Toggle */}
      <button
        className="md:hidden fixed bottom-4 right-4 z-50 bg-lc-teal text-lc-graphite p-3 rounded-full shadow-lg"
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
      >
        {isMobileMenuOpen ? <ChevronLeft size={24} /> : <LayoutDashboard size={24} />}
      </button>

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-40 w-64 bg-white transform transition-transform duration-300 ease-in-out md:translate-x-0 md:static md:h-screen
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <SidebarContent />
      </aside>
    </>
  );
};

export default Sidebar;