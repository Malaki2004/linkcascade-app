import { supabase } from '@/lib/supabaseClient';

export const useAnalyticsQueries = () => {

  const getTotalClicks = async (userId, startDate, endDate) => {
    try {
      // Query clicks table
      const { count, error } = await supabase
        .from('clicks')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .gte('clicked_at', startDate)
        .lte('clicked_at', endDate);

      if (error) throw error;
      return count || 0;
    } catch (error) {
      console.error('Error fetching total clicks:', error);
      return 0;
    }
  };

  const getLinkPerformance = async (userId, startDate, endDate) => {
    try {
      // Fetch links
      const { data: links, error: linksError } = await supabase
        .from('links')
        .select('id, title, short_code, clicks, created_at, last_clicked_at')
        .eq('user_id', userId);

      if (linksError) throw linksError;

      // For each link, count clicks in range
      // This is n+1 but unavoidable without complex joins/views in client-side Supabase
      // Optimization: Fetch all clicks in range for user, then aggregate in JS
      
      const { data: rangeClicks, error: clicksError } = await supabase
        .from('clicks')
        .select('link_id')
        .eq('user_id', userId)
        .gte('clicked_at', startDate)
        .lte('clicked_at', endDate);

      if (clicksError) throw clicksError;

      // Map clicks to links
      const clicksMap = {};
      rangeClicks.forEach(c => {
        clicksMap[c.link_id] = (clicksMap[c.link_id] || 0) + 1;
      });

      // Merge data
      const performanceData = links.map(link => ({
        ...link,
        clicksInRange: clicksMap[link.id] || 0
      }));

      // Sort by clicks in range descending
      return performanceData.sort((a, b) => b.clicksInRange - a.clicksInRange);

    } catch (error) {
      console.error('Error fetching link performance:', error);
      return [];
    }
  };

  const getActiveLinks = async (userId, startDate, endDate) => {
    try {
      const { count, error } = await supabase
        .from('links')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .gte('created_at', startDate)
        .lte('created_at', endDate);

      if (error) throw error;
      return count || 0;
    } catch (error) {
      console.error('Error fetching active links:', error);
      return 0;
    }
  };

  const getConversionRate = async (userId, startDate, endDate) => {
    // Placeholder logic as we don't have a robust 'conversions' table tracking yet in this prompt context
    // But we will try to query analytics table for 'conversion' events if they exist
    try {
      const totalClicks = await getTotalClicks(userId, startDate, endDate);
      if (totalClicks === 0) return "0.00";

      // Assuming 'analytics' table still holds conversion events
      const { count, error } = await supabase
        .from('analytics')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .eq('event_type', 'conversion') // Assuming this column exists or was planned
        .gte('date', startDate) // Analytics usually uses 'date'
        .lte('date', endDate);
      
      // If error (e.g. column doesn't exist), return 0
      if (error) return "0.00";

      return ((count / totalClicks) * 100).toFixed(2);
    } catch (error) {
      return "0.00";
    }
  };

  const getAverageCTR = async (userId, startDate, endDate) => {
    // Avg Clicks Per Link in range
    try {
      const totalClicks = await getTotalClicks(userId, startDate, endDate);
      
      // Get count of links that existed before or during this period
      // Actually simpler metric: Total Clicks / Total Links Active
      const { count: totalLinks } = await supabase
        .from('links')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId);

      if (!totalLinks || totalLinks === 0) return "0.0";
      
      // This isn't technically CTR (requires impressions), but serves as "Avg Clicks/Link"
      return (totalClicks / totalLinks).toFixed(1);
    } catch (error) {
      return "0.0";
    }
  };

  return {
    getTotalClicks,
    getLinkPerformance,
    getActiveLinks,
    getConversionRate,
    getAverageCTR
  };
};