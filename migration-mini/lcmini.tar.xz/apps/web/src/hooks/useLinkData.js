import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';

/**
 * Custom hook to fetch and manage user links.
 * Returns dynamic metrics calculated from the links.
 */
export const useLinkData = () => {
  const { user, loading: authLoading } = useAuth();
  const [links, setLinks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchLinks = useCallback(async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const { data, error: fetchError } = await supabase
        .from('links')
        .select('id, title, short_code, original_url, campaign_id, source_channel, enable_lead_capture, user_id, created_at, last_clicked_at, last_activity, campaigns(name), clicks(count)')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setLinks(data || []);
    } catch (err) {
      console.error('Error fetching links:', err);
      setError(err);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    if (!authLoading) {
      fetchLinks();
    }
  }, [authLoading, fetchLinks]);

  // Dynamically calculate total clicks
  const totalClicks = useMemo(() => 
    links?.reduce((sum, link) => sum + (link.clicks?.[0]?.count || 0), 0) || 0
  , [links]);

  // Dynamically calculate the top performing link
  const topLink = useMemo(() => 
    links?.length > 0 
      ? links.reduce((max, link) => {
          const linkClicks = link.clicks?.[0]?.count || 0;
          const maxClicks = max.clicks?.[0]?.count || 0;
          return linkClicks > maxClicks ? link : max;
        }, links[0])
      : null
  , [links]);

  return { links, totalClicks, topLink, loading, error, refetch: fetchLinks };
};