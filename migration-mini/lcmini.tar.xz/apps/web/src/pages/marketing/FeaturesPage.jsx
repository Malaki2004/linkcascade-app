import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Seo from '@/components/Seo';
import { SITE_URL, APP_SIGNUP_URL, OG_IMAGE } from '@/lib/brand';
import { cn } from '@/lib/utils';

const TITLE = 'Features: Trackable Links, Campaigns and Reports | LinkCascade';
const DESCRIPTION =
  'Explore LinkCascade features: trackable links, campaign organization, click reporting, lead attribution, earnings records, templates, and export tools.';

const badges = {
  auto: { label: 'Captured automatically', classes: 'bg-lc-teal/15 text-lc-tealdark' },
  manual: { label: 'Recorded by you', classes: 'bg-lc-graphite/10 text-lc-graphite' },
  external: { label: 'Uses your external accounts', classes: 'bg-lc-coral/15 text-lc-graphite' },
};

const Badge = ({ type }) => (
  <span className={cn('inline-block rounded-full px-2.5 py-0.5 text-[11px] font-semibold', badges[type].classes)}>
    {badges[type].label}
  </span>
);

const groups = [
  {
    title: 'Trackable Links',
    items: [
      { name: 'Short, trackable links', text: 'Turn any destination URL into a short LinkCascade link you can share anywhere.', badge: 'auto' },
      { name: 'Automatic click recording', text: 'Every time someone opens your short link, the click is recorded for you.', badge: 'auto' },
      { name: 'Link Vault organization', text: 'Search, edit, copy, and manage all of your links from one place.', badge: 'auto' },
      { name: 'Optional lead-capture step', text: 'On supported plans, show a lead form before sending visitors to the destination.', badge: 'auto' },
    ],
  },
  {
    title: 'Campaign Organization',
    items: [
      { name: 'Campaigns', text: 'Group related links into campaigns by launch, client, product, or channel.', badge: 'auto' },
      { name: 'Campaign-level view', text: 'See the links inside each campaign and how they perform together.', badge: 'auto' },
    ],
  },
  {
    title: 'Click and Performance Reporting',
    items: [
      { name: 'Dashboard totals', text: 'See total clicks, active links, and your top-performing link at a glance.', badge: 'auto' },
      { name: 'Date-range analytics', text: 'Review clicks, conversions, and average click-through rate over the period you choose.', badge: 'auto' },
      { name: 'Per-link performance', text: 'Compare individual links to see which ones earn engagement.', badge: 'auto' },
    ],
  },
  {
    title: 'Lead and Buyer Attribution',
    planNote: 'Available on Pro and Agency plans.',
    items: [
      { name: 'Built-in lead capture', text: 'Collect names and emails through a lead-capture page attached to a tracked link.', badge: 'auto' },
      { name: 'Lead lists', text: 'Filter, sort, and review the leads your links have captured.', badge: 'auto' },
      { name: 'Buyer attribution records', text: 'Associate recorded buyer activity with the links and campaigns in your account.', badge: 'manual' },
    ],
  },
  {
    title: 'Earnings Records',
    items: [
      { name: 'Earnings log', text: 'Record earnings by source—affiliate, sponsorship, or other—so you can review them alongside link activity.', badge: 'manual' },
      { name: 'Earnings history', text: 'Review totals and entries over time inside your account.', badge: 'manual' },
    ],
  },
  {
    title: 'Message Templates and Copy Tools',
    items: [
      { name: 'Template library', text: 'Browse ready-made message templates with search and category filters.', badge: 'auto' },
      { name: 'Custom templates and folders', text: 'Save your own outreach messages and organize them into folders.', badge: 'manual' },
      { name: 'Copy generator', text: 'Generate DM, social, and professional message drafts to share with your links.', badge: 'auto' },
    ],
  },
  {
    title: 'Export and Reporting Tools',
    planNote: 'CSV export is available on Pro and Agency plans.',
    items: [
      { name: 'CSV export', text: 'Export your earnings records to CSV for your own reporting or bookkeeping.', badge: 'manual' },
      { name: 'Lead capture API', text: 'Send leads into LinkCascade from your own forms using an API key.', badge: 'external' },
    ],
  },
];

const ctaPrimary =
  'inline-flex items-center justify-center rounded-md bg-lc-teal px-6 py-3 text-base font-semibold text-lc-graphite transition-colors hover:bg-lc-teal/85 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark active:scale-[0.98]';

const FeaturesPage = () => {
  return (
    <>
      <Helmet>
        <title>{TITLE}</title>
        <meta name="description" content={DESCRIPTION} />
      </Helmet>
      <Seo title={TITLE} description={DESCRIPTION} image={OG_IMAGE} url={`${SITE_URL}/features`} />

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <p className="font-serif text-lg italic text-lc-tealdark">Features</p>
          <h1 className="mt-3 max-w-3xl text-4xl font-extrabold tracking-tight text-lc-graphite md:text-5xl">
            Everything you need to track the links you share
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-lc-slate">
            LinkCascade focuses on doing a few things well: creating trackable links, keeping them organized, and
            showing you the activity they produce. Here is exactly what the product does today—and where the
            information comes from.
          </p>

          <div className="mt-8 flex flex-wrap gap-3" aria-label="How to read the feature labels">
            {Object.values(badges).map((badge) => (
              <span key={badge.label} className={cn('rounded-full px-3 py-1 text-xs font-semibold', badge.classes)}>
                {badge.label}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <div className="space-y-16">
            {groups.map((group) => (
              <div key={group.title}>
                <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1 border-t-2 border-lc-graphite pt-6">
                  <h2 className="text-2xl font-extrabold tracking-tight text-lc-graphite">{group.title}</h2>
                  {group.planNote && <p className="text-sm font-medium text-lc-tealdark">{group.planNote}</p>}
                </div>
                <ul className="mt-8 grid gap-x-10 gap-y-8 md:grid-cols-2">
                  {group.items.map((item) => (
                    <li key={item.name} className="rounded-lg border border-lc-border bg-white p-5">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <h3 className="text-base font-bold text-lc-graphite">{item.name}</h3>
                        <Badge type={item.badge} />
                      </div>
                      <p className="mt-2 text-sm leading-relaxed text-lc-slate">{item.text}</p>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-16 rounded-xl border-2 border-lc-graphite bg-white p-6 shadow-[6px_6px_0_0_#0B1318]">
            <h2 className="text-lg font-bold text-lc-graphite">An honest note about attribution</h2>
            <p className="mt-3 text-sm leading-relaxed text-lc-slate">
              LinkCascade records clicks and captured leads automatically. Sales and earnings figures come from what
              you record in your account or capture through supported lead forms—LinkCascade does not automatically
              verify external affiliate commissions or sales that happen on other platforms.
            </p>
          </div>

          <div className="mt-12 flex flex-wrap items-center gap-4">
            <a href={APP_SIGNUP_URL} className={ctaPrimary}>
              Start Free
            </a>
            <Link
              to="/pricing"
              className="font-semibold text-lc-tealdark underline-offset-4 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-lc-tealdark"
            >
              Compare plans
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default FeaturesPage;
