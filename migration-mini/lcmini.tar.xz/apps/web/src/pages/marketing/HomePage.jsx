import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Link2, FolderKanban, BarChart3, Users, DollarSign, FileText, ArrowRight } from 'lucide-react';
import Seo from '@/components/Seo';
import DashboardMockup from '@/components/marketing/DashboardMockup';
import { SITE_URL, APP_SIGNUP_URL, OG_IMAGE, SUPPORT_EMAIL } from '@/lib/brand';

const TITLE = 'Link Tracking and Campaign Analytics | LinkCascade';
const DESCRIPTION =
  'Create trackable links, organize campaigns, capture leads, and understand which shared links are producing meaningful results with LinkCascade.';

const ctaPrimary =
  'inline-flex items-center justify-center rounded-md bg-lc-teal px-6 py-3 text-base font-semibold text-lc-graphite transition-colors hover:bg-lc-teal/85 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark active:scale-[0.98]';
const ctaSecondary =
  'inline-flex items-center justify-center rounded-md border-2 border-lc-graphite px-6 py-3 text-base font-semibold text-lc-graphite transition-colors hover:bg-lc-graphite hover:text-lc-offwhite focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark active:scale-[0.98]';

const capabilities = [
  {
    icon: Link2,
    title: 'Trackable links',
    text: 'Create short links in the Link Vault and see every click recorded automatically.',
  },
  {
    icon: FolderKanban,
    title: 'Campaign organization',
    text: 'Group links into campaigns by launch, client, or channel so results stay organized.',
  },
  {
    icon: BarChart3,
    title: 'Performance reporting',
    text: 'Review click totals, top links, and campaign performance over the date range you choose.',
  },
  {
    icon: Users,
    title: 'Lead attribution',
    text: 'Capture leads through built-in lead forms and connect them to the links that produced them.',
  },
  {
    icon: DollarSign,
    title: 'Earnings records',
    text: 'Record earnings by source and compare them with the link activity in your account.',
  },
  {
    icon: FileText,
    title: 'Templates and copy tools',
    text: 'Save message templates and generate outreach copy for the channels you share on.',
  },
];

const steps = [
  { n: '01', title: 'Create a trackable link', text: 'Add a destination and get a short link you can share.' },
  { n: '02', title: 'Add it to a campaign', text: 'Keep related links grouped so results are easy to compare.' },
  { n: '03', title: 'Share it anywhere', text: 'Post it on social media, email, websites, messages, and ads.' },
  { n: '04', title: 'Review your results', text: 'See clicks, captured leads, and the results recorded in your account.' },
];

const jsonLd = [
  {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'LinkCascade',
    url: `${SITE_URL}/`,
    logo: OG_IMAGE,
    email: SUPPORT_EMAIL,
  },
  {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: 'LinkCascade',
    url: `${SITE_URL}/`,
  },
  {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: 'LinkCascade',
    applicationCategory: 'BusinessApplication',
    operatingSystem: 'Web',
    url: `${SITE_URL}/`,
    description:
      'An easy link-tracking and campaign-organization platform that helps creators, affiliates, consultants, agencies, and small businesses understand which shared links produce clicks, leads, and attributable results.',
  },
];

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>{TITLE}</title>
        <meta name="description" content={DESCRIPTION} />
        {jsonLd.map((obj, i) => (
          <script key={i} type="application/ld+json">
            {JSON.stringify(obj)}
          </script>
        ))}
      </Helmet>
      <Seo title={TITLE} description={DESCRIPTION} image={OG_IMAGE} url={`${SITE_URL}/`} />

      {/* Hero */}
      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-6 pb-20 pt-16 lg:grid-cols-12">
          <div className="lg:col-span-6">
            <p className="font-serif text-lg italic text-lc-tealdark">Link tracking &amp; campaign organization</p>
            <h1 className="mt-4 text-4xl font-extrabold tracking-tight text-lc-graphite md:text-5xl">
              Track every link. See what drives clicks, leads, and sales.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-lc-slate">
              LinkCascade helps creators, affiliates, consultants, agencies, and small businesses create trackable
              links, organize campaigns, and connect shared links to measurable activity—all from one straightforward
              dashboard.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <a href={APP_SIGNUP_URL} className={ctaPrimary}>
                Start Free
              </a>
              <Link to="/how-it-works" className={ctaSecondary}>
                See How It Works
              </Link>
            </div>
            <p className="mt-4 text-sm text-lc-slate">Free plan included. Sign up with just an email and password.</p>
          </div>
          <div className="lg:col-span-6 lg:pl-4">
            <DashboardMockup float />
          </div>
        </div>
      </section>

      {/* Audience strip */}
      <section className="border-b-2 border-lc-graphite bg-white">
        <div className="mx-auto max-w-6xl px-6 py-10">
          <p className="text-xs font-semibold uppercase tracking-widest text-lc-slate">
            Built for people who share links for a living
          </p>
          <ul className="mt-4 flex flex-wrap gap-x-8 gap-y-2 font-serif text-xl italic text-lc-graphite">
            <li>Creators</li>
            <li>Affiliates</li>
            <li>Consultants</li>
            <li>Agencies</li>
            <li>Small businesses</li>
          </ul>
        </div>
      </section>

      {/* Capabilities */}
      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <div className="max-w-2xl">
            <h2 className="text-3xl font-extrabold tracking-tight text-lc-graphite">What you can do with LinkCascade</h2>
            <p className="mt-4 text-lg text-lc-slate">
              One dashboard for the links you share and the activity they produce.
            </p>
          </div>
          <div className="mt-12 grid gap-x-10 gap-y-12 md:grid-cols-2 lg:grid-cols-3">
            {capabilities.map((cap) => {
              const Icon = cap.icon;
              return (
                <div key={cap.title} className="border-t-2 border-lc-graphite pt-6">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-md bg-lc-teal">
                    <Icon className="h-5 w-5 text-lc-graphite" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-bold text-lc-graphite">{cap.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-lc-slate">{cap.text}</p>
                </div>
              );
            })}
          </div>
          <p className="mt-10">
            <Link
              to="/features"
              className="inline-flex items-center gap-2 font-semibold text-lc-tealdark underline-offset-4 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-lc-tealdark"
            >
              Explore all features <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </p>
        </div>
      </section>

      {/* How it works teaser */}
      <section className="border-b-2 border-lc-graphite bg-white">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <h2 className="text-3xl font-extrabold tracking-tight text-lc-graphite">How it works</h2>
          <ol className="mt-12 grid gap-x-10 gap-y-10 md:grid-cols-2 lg:grid-cols-4">
            {steps.map((step) => (
              <li key={step.n} className="border-t-2 border-lc-graphite pt-5">
                <p className="font-serif text-2xl italic text-lc-tealdark">{step.n}</p>
                <h3 className="mt-2 text-base font-bold text-lc-graphite">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-lc-slate">{step.text}</p>
              </li>
            ))}
          </ol>
          <p className="mt-10">
            <Link
              to="/how-it-works"
              className="inline-flex items-center gap-2 font-semibold text-lc-tealdark underline-offset-4 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-lc-tealdark"
            >
              See the full workflow <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </p>
        </div>
      </section>

      {/* Plans teaser */}
      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <div className="max-w-2xl">
            <h2 className="text-3xl font-extrabold tracking-tight text-lc-graphite">Simple plans, starting free</h2>
            <p className="mt-4 text-lg text-lc-slate">
              Start on the Free plan and upgrade when you need more links, campaigns, and reporting.
            </p>
          </div>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {[
              { name: 'Free', price: '$0', blurb: '5 trackable links and 2 campaigns to get started.' },
              { name: 'Pro', price: '$27', blurb: '50 links, 10 campaigns, advanced analytics, and lead attribution.' },
              { name: 'Agency', price: '$97', blurb: 'Unlimited links and campaigns for teams and organizations.' },
            ].map((plan) => (
              <div
                key={plan.name}
                className="rounded-xl border-2 border-lc-graphite bg-white p-6 shadow-[6px_6px_0_0_#0B1318]"
              >
                <h3 className="text-lg font-bold text-lc-graphite">{plan.name}</h3>
                <p className="mt-2 text-3xl font-extrabold text-lc-graphite">
                  {plan.price}
                  <span className="text-sm font-medium text-lc-slate">/month</span>
                </p>
                <p className="mt-3 text-sm leading-relaxed text-lc-slate">{plan.blurb}</p>
              </div>
            ))}
          </div>
          <p className="mt-10">
            <Link
              to="/pricing"
              className="inline-flex items-center gap-2 font-semibold text-lc-tealdark underline-offset-4 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-lc-tealdark"
            >
              Compare plans in detail <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </p>
        </div>
      </section>

      {/* CTA band */}
      <section className="bg-lc-graphite text-lc-offwhite">
        <div className="mx-auto max-w-6xl px-6 py-20 text-center">
          <p className="font-serif text-lg italic text-lc-teal">Ready when you are</p>
          <h2 className="mx-auto mt-3 max-w-2xl text-3xl font-extrabold tracking-tight md:text-4xl">
            Start tracking your links today
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-lc-offwhite/75">
            Create your first trackable link in minutes and see exactly which shared links produce clicks, leads, and
            recorded results.
          </p>
          <div className="mt-8">
            <a href={APP_SIGNUP_URL} className={ctaPrimary}>
              Start Free
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;
