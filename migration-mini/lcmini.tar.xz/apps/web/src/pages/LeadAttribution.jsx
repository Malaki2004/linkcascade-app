import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  TrendingUp, 
  Share2, 
  FileText, 
  Search, 
  Filter, 
  Info,
  ChevronLeft,
  ChevronRight,
  ArrowUpDown,
  Lock,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const initialFilters = {
  search: '',
  startDate: null,
  endDate: null,
  sourceChannel: 'All',
  campaign: 'All',
  formName: 'All',
  status: 'All'
};

const LeadAttribution = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [filters, setFilters] = useState(initialFilters);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortConfig, setSortConfig] = useState({ key: 'created_at', direction: 'desc' });
  const itemsPerPage = 10;

  const [userPlan, setUserPlan] = useState('free');
  const [planLoading, setPlanLoading] = useState(true);

  useEffect(() => {
    const fetchPlan = async () => {
      if (!user) {
        setPlanLoading(false);
        setLoading(false);
        return;
      }
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('plan')
          .eq('id', user.id)
          .single();
        if (error) throw error;
        setUserPlan(data?.plan || 'free');
      } catch (err) {
        console.error('Error fetching plan:', err);
        setUserPlan('free');
      } finally {
        setPlanLoading(false);
      }
    };
    fetchPlan();
  }, [user]);

  const hasProAccess = userPlan === 'pro' || userPlan === 'agency';

  useEffect(() => {
    if (user && !planLoading) {
      if (hasProAccess) {
        fetchLeads();
      } else {
        setLoading(false);
      }
    }
  }, [user, planLoading, hasProAccess]);

  const fetchLeads = async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('id, lead_name, lead_email, lead_phone, link_id, campaign_id, user_id, status, created_at, source_channel, form_name, campaigns(name)')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }
      setLeads(data || []);
    } catch (err) {
      console.error('[LEAD_ATTRIBUTION] Catch block error:', err);
      setError('Failed to load leads. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const safeLeads = useMemo(() => {
    return leads && Array.isArray(leads) ? leads : [];
  }, [leads]);

  const sourceChannelOptions = useMemo(() => {
    return ['All', ...new Set(safeLeads.map(lead => lead.source_channel || 'Direct'))];
  }, [safeLeads]);

  const formNameOptions = useMemo(() => {
    return ['All', ...new Set(safeLeads.map(lead => lead.form_name).filter(Boolean))];
  }, [safeLeads]);

  const campaignOptions = useMemo(() => {
    return ['All', ...new Set(safeLeads.map(lead => lead.campaigns?.name || lead.campaign_id).filter(Boolean))];
  }, [safeLeads]);

  const statusOptions = ['All', 'New', 'Contacted', 'Qualified', 'Converted', 'Lost', 'new'];

  const filteredAndSortedLeads = useMemo(() => {
    let filtered = [...safeLeads];

    if (filters.search && filters.search.trim() !== '') {
      const s = filters.search.toLowerCase();
      filtered = filtered.filter(item => 
        (item.lead_name && item.lead_name.toLowerCase().includes(s)) ||
        (item.lead_email && item.lead_email.toLowerCase().includes(s)) ||
        (item.form_name && item.form_name.toLowerCase().includes(s)) ||
        (item.source_channel && item.source_channel.toLowerCase().includes(s)) ||
        (item.campaigns?.name && item.campaigns.name.toLowerCase().includes(s))
      );
    }

    if (filters.startDate !== null && filters.startDate !== '') {
      const start = new Date(filters.startDate);
      start.setHours(0, 0, 0, 0);
      filtered = filtered.filter(item => {
        if (!item.created_at) return false;
        return new Date(item.created_at) >= start;
      });
    }

    if (filters.endDate !== null && filters.endDate !== '') {
      const end = new Date(filters.endDate);
      end.setHours(23, 59, 59, 999);
      filtered = filtered.filter(item => {
        if (!item.created_at) return false;
        return new Date(item.created_at) <= end;
      });
    }

    if (filters.sourceChannel !== 'All') {
      filtered = filtered.filter(item => (item.source_channel || 'Direct') === filters.sourceChannel);
    }
    if (filters.formName !== 'All') {
      filtered = filtered.filter(item => item.form_name === filters.formName);
    }
    if (filters.campaign !== 'All') {
      filtered = filtered.filter(item => (item.campaigns?.name || item.campaign_id) === filters.campaign);
    }
    if (filters.status !== 'All') {
      filtered = filtered.filter(item => {
        const itemStatus = item.status ? item.status.toLowerCase() : 'new';
        return itemStatus === filters.status.toLowerCase();
      });
    }

    filtered.sort((a, b) => {
      let aVal = a[sortConfig.key];
      let bVal = b[sortConfig.key];

      if (sortConfig.key === 'campaign_id') {
         aVal = a.campaigns?.name || a.campaign_id || '';
         bVal = b.campaigns?.name || b.campaign_id || '';
      } else {
         aVal = aVal || '';
         bVal = bVal || '';
      }

      if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });

    return filtered;
  }, [safeLeads, filters, sortConfig]);

  const metrics = useMemo(() => {
    const totalLeads = safeLeads.length;
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const leadsThisWeek = safeLeads.filter(d => d.created_at && new Date(d.created_at) >= oneWeekAgo).length;
    
    const channelCounts = {};
    safeLeads.forEach(d => {
      const channel = d.source_channel || 'Direct';
      channelCounts[channel] = (channelCounts[channel] || 0) + 1;
    });
    const topSourceChannel = Object.entries(channelCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

    const formCounts = {};
    safeLeads.forEach(d => {
      if (d.form_name) {
        formCounts[d.form_name] = (formCounts[d.form_name] || 0) + 1;
      }
    });
    const topForm = Object.entries(formCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

    return { totalLeads, leadsThisWeek, topSourceChannel, topForm };
  }, [safeLeads]);

  const totalPages = Math.ceil(filteredAndSortedLeads.length / itemsPerPage) || 1;
  const paginatedLeads = useMemo(() => {
    return filteredAndSortedLeads.slice(
      (currentPage - 1) * itemsPerPage, 
      currentPage * itemsPerPage
    );
  }, [filteredAndSortedLeads, currentPage, itemsPerPage]);

  const handleClearFilters = () => {
    setFilters(initialFilters);
    setCurrentPage(1);
  };

  const handleFilterChange = (filterName, value) => {
    setFilters(prev => ({ ...prev, [filterName]: value }));
    setCurrentPage(1);
  };

  const handleSearchChange = (e) => {
    handleFilterChange('search', e.target.value);
  };

  const handleDateChange = (dateType, value) => {
    setFilters(prev => ({ ...prev, [dateType]: value === '' ? null : value }));
    setCurrentPage(1);
  };

  const getStatusColor = (statusRaw) => {
    const status = statusRaw ? statusRaw.toLowerCase() : 'new';
    switch (status) {
      case 'new': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'contacted': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'qualified': return 'bg-lc-teal/15 text-lc-tealdark border-lc-border';
      case 'converted': return 'bg-green-100 text-green-800 border-green-200';
      case 'lost': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (planLoading) {
    return (
      <div className="p-6 md:p-8 max-w-7xl mx-auto min-h-[80vh] flex flex-col items-center justify-center">
        <Loader2 className="w-10 h-10 text-lc-tealdark animate-spin mb-4" />
        <p className="text-gray-500">Checking your plan...</p>
      </div>
    );
  }

  if (!hasProAccess) {
    return (
      <div className="p-6 md:p-8 max-w-7xl mx-auto min-h-[80vh] flex flex-col items-center justify-center">
        <Helmet>
          <title>Lead Attribution - LinkCascade</title>
        </Helmet>
        <div className="bg-lc-teal/10 border border-lc-border rounded-2xl p-8 max-w-md w-full text-center shadow-sm">
          <div className="w-16 h-16 bg-lc-teal/15 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lock className="w-8 h-8 text-lc-tealdark" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Pro Feature</h2>
          <p className="text-gray-600 mb-6">
            Lead Attribution is only available on Pro and Agency plans. Upgrade your account to unlock this feature.
          </p>
          <Button 
            onClick={() => navigate('/settings?tab=billing')}
            className="w-full bg-lc-teal hover:bg-lc-tealdark text-lc-graphite"
          >
            Upgrade to Pro
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Lead Attribution - LinkCascade</title>
      </Helmet>

      <div className="p-6 md:p-8 max-w-7xl mx-auto min-h-screen space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 tracking-tight flex items-center gap-2">
            <Users className="w-8 h-8 text-lc-tealdark" />
            Lead Attribution
          </h1>
          
          <div className="mt-4 bg-lc-teal/10 border border-lc-border p-4 rounded-xl flex items-start gap-3 text-lc-graphite shadow-sm">
            <Info className="w-5 h-5 flex-shrink-0 mt-0.5 text-lc-tealdark" />
            <p className="text-sm font-medium">
              View all captured leads from your short links and campaigns.
            </p>
          </div>
        </div>

        {error ? (
          <div className="bg-red-50 border border-red-200 p-6 rounded-xl flex flex-col items-center justify-center gap-4 text-center">
             <p className="text-red-700 font-medium">{error}</p>
             <Button onClick={fetchLeads} variant="outline" className="gap-2 border-red-300 text-red-700 hover:bg-red-100">
               <RefreshCw className="w-4 h-4" /> Retry
             </Button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
                <div className="bg-lc-teal/15 p-3 rounded-lg text-lc-tealdark">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">Total Leads</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.totalLeads}</p>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
                <div className="bg-green-50 p-3 rounded-lg text-green-600">
                  <TrendingUp className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">Leads This Week</p>
                  <p className="text-2xl font-bold text-gray-900">{metrics.leadsThisWeek}</p>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
                <div className="bg-lc-teal/15 p-3 rounded-lg text-lc-tealdark">
                  <Share2 className="w-6 h-6" />
                </div>
                <div className="overflow-hidden">
                  <p className="text-sm text-gray-500 font-medium">Top Source Channel</p>
                  <p className="text-lg font-bold text-gray-900 truncate" title={metrics.topSourceChannel}>
                    {metrics.topSourceChannel}
                  </p>
                </div>
              </div>
              
              <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
                <div className="bg-orange-50 p-3 rounded-lg text-orange-600">
                  <FileText className="w-6 h-6" />
                </div>
                <div className="overflow-hidden">
                  <p className="text-sm text-gray-500 font-medium">Top Form</p>
                  <p className="text-lg font-bold text-gray-900 truncate" title={metrics.topForm}>
                    {metrics.topForm}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm flex flex-col xl:flex-row gap-4 justify-between items-end">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-4 w-full">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Search</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input 
                      type="text" 
                      placeholder="Search..." 
                      value={filters.search}
                      onChange={handleSearchChange}
                      className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-lc-teal outline-none"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Start Date</label>
                  <input 
                    type="date"
                    value={filters.startDate || ''}
                    onChange={(e) => handleDateChange('startDate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">End Date</label>
                  <input 
                    type="date"
                    value={filters.endDate || ''}
                    onChange={(e) => handleDateChange('endDate', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Source Channel</label>
                  <select 
                    value={filters.sourceChannel} 
                    onChange={(e) => handleFilterChange('sourceChannel', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none bg-white"
                  >
                    {sourceChannelOptions.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Campaign</label>
                  <select 
                    value={filters.campaign} 
                    onChange={(e) => handleFilterChange('campaign', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none bg-white"
                  >
                    {campaignOptions.map(p => <option key={p} value={p}>{p === 'All' ? 'All' : p.substring(0,20) + (p.length > 20 ? '...' : '')}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Form Name</label>
                  <select 
                    value={filters.formName} 
                    onChange={(e) => handleFilterChange('formName', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none bg-white"
                  >
                    {formNameOptions.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Status</label>
                  <select 
                    value={filters.status} 
                    onChange={(e) => handleFilterChange('status', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none bg-white"
                  >
                    {statusOptions.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
              </div>
              
              <Button variant="outline" onClick={handleClearFilters} className="w-full xl:w-auto text-gray-600 border-gray-300 gap-2 mt-4 xl:mt-0 flex-shrink-0">
                <Filter className="w-4 h-4" /> Clear
              </Button>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse min-w-[900px]">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200 text-xs uppercase tracking-wider text-gray-500 font-semibold">
                      <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('lead_name')}>
                        <div className="flex items-center gap-1">Lead Name <ArrowUpDown className="w-3 h-3" /></div>
                      </th>
                      <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('lead_email')}>
                        <div className="flex items-center gap-1">Email <ArrowUpDown className="w-3 h-3" /></div>
                      </th>
                      <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('lead_phone')}>
                        <div className="flex items-center gap-1">Phone <ArrowUpDown className="w-3 h-3" /></div>
                      </th>
                      <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('source_channel')}>
                        <div className="flex items-center gap-1">Source Channel <ArrowUpDown className="w-3 h-3" /></div>
                      </th>
                      <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('campaign_id')}>
                        <div className="flex items-center gap-1">Campaign <ArrowUpDown className="w-3 h-3" /></div>
                      </th>
                      <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('form_name')}>
                        <div className="flex items-center gap-1">Form Name <ArrowUpDown className="w-3 h-3" /></div>
                      </th>
                      <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('status')}>
                        <div className="flex items-center gap-1">Status <ArrowUpDown className="w-3 h-3" /></div>
                      </th>
                      <th className="px-6 py-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort('created_at')}>
                        <div className="flex items-center gap-1">Submission Date <ArrowUpDown className="w-3 h-3" /></div>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {loading ? (
                      <tr>
                        <td colSpan="8" className="px-6 py-10 text-center">
                          <div className="flex justify-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-lc-teal"></div></div>
                          <p className="mt-2 text-sm text-gray-500">Loading leads...</p>
                        </td>
                      </tr>
                    ) : paginatedLeads.length === 0 ? (
                      <tr>
                        <td colSpan="8" className="px-6 py-12 text-center text-gray-500">
                          <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                          <p className="text-lg font-medium text-gray-900">No leads found</p>
                          <p className="text-sm">Try adjusting your filters or search query.</p>
                        </td>
                      </tr>
                    ) : (
                      paginatedLeads.map((row) => (
                        <tr key={row.id} className="hover:bg-gray-50 transition-colors">
                          <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                            {row.lead_name || '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 hover:text-lc-tealdark transition-colors">
                            {row.lead_email ? <a href={`mailto:${row.lead_email}`}>{row.lead_email}</a> : '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {row.lead_phone || '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 font-medium">
                            {row.source_channel || '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {row.campaigns?.name || '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                            {row.form_name || '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getStatusColor(row.status)} capitalize`}>
                              {row.status || 'new'}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {row.created_at ? new Date(row.created_at).toLocaleDateString('en-US', {
                              year: 'numeric', month: 'short', day: 'numeric',
                              hour: '2-digit', minute: '2-digit'
                            }) : '-'}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
              
              {!loading && filteredAndSortedLeads.length > 0 && (
                <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between bg-gray-50/50">
                  <div className="text-sm text-gray-500">
                    Showing <span className="font-medium text-gray-900">{((currentPage - 1) * itemsPerPage) + 1}</span> to <span className="font-medium text-gray-900">{Math.min(currentPage * itemsPerPage, filteredAndSortedLeads.length)}</span> of <span className="font-medium text-gray-900">{filteredAndSortedLeads.length}</span> results
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                      className="bg-white"
                    >
                      <ChevronLeft className="w-4 h-4 mr-1" /> Prev
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                      className="bg-white"
                    >
                      Next <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default LeadAttribution;