import React, { useState } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { CreditCard, Check, ExternalLink, Loader2, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';

const BillingSettings = () => {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const currentPlan = userProfile?.plan || 'free';
  const isFree = currentPlan === 'free';
  const isPaidUser = currentPlan === 'pro' || currentPlan === 'agency';
  
  const handleManageBilling = async () => {
    setLoading(true);
    try {
      if (!userProfile?.stripe_customer_id) {
          throw new Error("No billing account found. Please upgrade a plan first.");
      }

      const { data, error } = await supabase.functions.invoke('stripe-portal', {
        body: { return_url: window.location.href }
      });

      if (error) throw error;
      if (data?.url) {
        window.location.href = data.url;
      } else {
        throw new Error("Failed to generate portal URL");
      }
    } catch (error) {
      console.error('Portal error:', error);
      toast({
        title: "Billing Portal Error",
        description: error.message || "Could not access billing portal.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-8">
      <div>
        <h2 className="text-xl font-bold text-gray-900">Subscription & Billing</h2>
        <p className="text-gray-500 text-sm mt-1">Manage your plan, payment methods, and invoices.</p>
      </div>

      <div className="bg-lc-teal/10 rounded-xl border border-lc-border p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-white rounded-lg shadow-sm border border-lc-border">
               <CreditCard className="w-5 h-5 text-lc-tealdark" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 capitalize">{currentPlan} Plan</h3>
            <span className="px-2.5 py-0.5 rounded-full bg-green-100 text-green-700 text-xs font-bold border border-green-200 flex items-center gap-1">
               <Check className="w-3 h-3" /> Active
            </span>
          </div>
          <p className="text-gray-600 text-sm">
            {isFree 
              ? "You are currently on the free tier. Upgrade to unlock more features." 
              : "Your subscription is active and renews automatically."}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
          {!isFree && (
            <Button 
              onClick={handleManageBilling} 
              disabled={loading}
              variant="outline" 
              className="bg-white border-lc-border text-lc-tealdark hover:bg-lc-teal/10 hover:text-lc-tealdark hover:border-lc-teal"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <>Manage Billing <ExternalLink className="w-4 h-4 ml-2" /></>
              )}
            </Button>
          )}
          
          <Button 
            onClick={() => navigate('/pricing')}
            className={isFree ? "bg-lc-teal hover:bg-lc-tealdark text-lc-graphite" : "bg-white border border-gray-200 text-gray-700 hover:bg-gray-50"}
            variant={isFree ? "default" : "outline"}
          >
            {isFree ? "Upgrade Plan" : "Change Plan"}
          </Button>
        </div>
      </div>

      {isPaidUser && (
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Billing Portal</h3>
          <p className="text-gray-600 text-sm mb-4">
            Access your Stripe customer portal to manage your subscription, payment methods, and billing history.
          </p>
          <Button 
            onClick={() => window.open('https://billing.stripe.com/p/login/7sY7sNek8ekW3zB8E64Ni00', '_blank', 'noopener,noreferrer')}
            className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite"
          >
            Manage Billing <ExternalLink className="w-4 h-4 ml-2" />
          </Button>
          <p className="text-gray-500 text-xs mt-3">
            Update your payment method, change your subscription, or cancel your plan securely through Stripe.
          </p>
        </div>
      )}

      <div className="border-t border-gray-100 pt-6">
         <h4 className="text-sm font-bold text-gray-900 mb-4 uppercase tracking-wide">Plan Features</h4>
         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start gap-3 p-4 rounded-lg bg-gray-50 border border-gray-200">
               <div className="mt-0.5"><Check className="w-5 h-5 text-green-600" /></div>
               <div>
                  <div className="font-medium text-gray-900">Link Analytics</div>
                  <div className="text-sm text-gray-500">Track clicks and conversions</div>
               </div>
            </div>
            {currentPlan !== 'free' && (
                <div className="flex items-start gap-3 p-4 rounded-lg bg-gray-50 border border-gray-200">
                    <div className="mt-0.5"><Check className="w-5 h-5 text-green-600" /></div>
                    <div>
                        <div className="font-medium text-gray-900">Advanced Campaigns</div>
                        <div className="text-sm text-gray-500">Organize and track multiple links</div>
                    </div>
                </div>
            )}
             {currentPlan === 'agency' && (
                <div className="flex items-start gap-3 p-4 rounded-lg bg-gray-50 border border-gray-200">
                    <div className="mt-0.5"><Check className="w-5 h-5 text-green-600" /></div>
                    <div>
                        <div className="font-medium text-gray-900">Agency Features</div>
                        <div className="text-sm text-gray-500">Team management and white-labeling</div>
                    </div>
                </div>
            )}
         </div>
      </div>

      {!userProfile?.stripe_customer_id && !isFree && (
         <div className="rounded-lg bg-yellow-50 border border-yellow-200 p-4 flex gap-3">
             <AlertCircle className="w-5 h-5 text-yellow-600 shrink-0" />
             <div>
                <h4 className="font-bold text-yellow-800">Billing Information Missing</h4>
                <p className="text-sm text-yellow-700 mt-1">We couldn't find your billing ID. If you just upgraded, this might take a moment to sync. Contact support if this persists.</p>
             </div>
         </div>
      )}
    </div>
  );
};

export default BillingSettings;