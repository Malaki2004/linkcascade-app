import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/contexts/SupabaseAuthContext';
import { SITE_URL } from '@/lib/brand';
import { Toaster } from '@/components/ui/toaster';
import ProtectedRoute from '@/components/ProtectedRoute';
import AppLayout from '@/layouts/AppLayout';

// Layout Imports
import SettingsLayout from '@/layouts/SettingsLayout';

// Page imports
import LoginPage from '@/pages/LoginPage';
import Signup from '@/pages/Signup';
import ForgotPasswordPage from '@/pages/ForgotPasswordPage';
import ResetPassword from '@/pages/ResetPassword';
import Dashboard from '@/pages/Dashboard';
import LinkVault from '@/pages/LinkVault';
import CampaignBuilder from '@/pages/CampaignBuilder';
import MessageTemplates from '@/pages/MessageTemplates';
import TemplateLibrary from '@/pages/TemplateLibrary';
import CopyGenerator from '@/pages/CopyGenerator';
import EarningsTracker from '@/pages/EarningsTracker';
import Analytics from '@/pages/Analytics';
import BuyerAttribution from '@/pages/BuyerAttribution';
import LeadAttribution from '@/pages/LeadAttribution';
import LeadCaptureSetup from '@/pages/LeadCaptureSetup';
import LeadCapturePage from '@/pages/LeadCapturePage';
import AccountSettings from '@/pages/AccountSettings';
import BillingSettings from '@/pages/BillingSettings';
import SecuritySettings from '@/pages/SecuritySettings';
import Redirect from '@/pages/Redirect';
import Pricing from '@/pages/Pricing';
import BillingStripeSuccess from '@/pages/BillingStripeSuccess';
import NotFound from '@/pages/NotFound';

// Public marketing site
import MarketingLayout from '@/components/marketing/MarketingLayout';
import HomePage from '@/pages/marketing/HomePage';
import FeaturesPage from '@/pages/marketing/FeaturesPage';
import HowItWorksPage from '@/pages/marketing/HowItWorksPage';
import EarnMorePage from '@/pages/marketing/EarnMorePage';
import EarlyAccessPage from '@/pages/marketing/EarlyAccessPage';
import ContactPage from '@/pages/marketing/ContactPage';
import FaqPage from '@/pages/marketing/FaqPage';
import PrivacyPage from '@/pages/marketing/PrivacyPage';
import TermsPage from '@/pages/marketing/TermsPage';

// App Force Rebuild Trigger: 2026-03-28

// Host-aware routing: this single project may serve both the public marketing
// site (linkcascade.app / linkcascade.com) and the application
// (app.linkcascade.app / app.linkcascade.com). On an "app." host the root "/"
// must land on the application, not the marketing homepage. On every other
// host (including preview domains and localhost) the root shows the marketing
// site. All other routes are unchanged, so this is safe regardless of which
// production hosts are actually bound to this project.
const APP_HOSTS = ['app.linkcascade.app', 'app.linkcascade.com'];
const isAppHost = () => {
  if (typeof window === 'undefined') return false;
  const host = window.location.hostname || '';
  return APP_HOSTS.includes(host) || host.startsWith('app.');
};

const MARKETING_BASE = SITE_URL; // https://linkcascade.app

// Marketing-only routes redirect to the public marketing site on the app
// subdomain so app.linkcascade.app stays application-only. On non-app hosts
// (preview domains) the page still renders so it can be reviewed.
const ExternalRedirect = ({ to, fallback }) => {
  const shouldRedirect = isAppHost();
  useEffect(() => {
    if (shouldRedirect) {
      window.location.replace(to);
    }
  }, [shouldRedirect, to]);
  if (shouldRedirect) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-500">
        Redirecting…
      </div>
    );
  }
  return fallback;
};

// /pricing is used by authenticated upgrade/billing flows (Dashboard, Link
// Vault, Campaigns, Billing Settings all navigate here for Stripe upgrades),
// so it must stay for signed-in users. Only anonymous/marketing access on the
// app subdomain redirects to the public marketing pricing page.
const PricingRoute = () => {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-500">
        Loading…
      </div>
    );
  }
  if (user) return <Pricing />;
  return <ExternalRedirect to={`${MARKETING_BASE}/pricing`} fallback={<Pricing />} />;
};

const HomeRoute = () =>
  isAppHost() ? <Navigate to="/dashboard" replace /> : <HomePage />;

function App() {
  console.log('[APP_INIT] React Router initialized - Forced Rebuild');

  useEffect(() => {
    const handler = (e) => {
      const elements = document.elementsFromPoint(e.clientX, e.clientY);
      for (const el of elements) {
        const link = el.closest("[data-stripe-link]");
        if (link) {
          const url = link.getAttribute("data-stripe-link");
          if (url) {
            e.preventDefault();
            e.stopPropagation();
            window.location.assign(url);
            return;
          }
        }
      }
    };

    document.addEventListener("pointerdown", handler, true);
    return () => document.removeEventListener("pointerdown", handler, true);
  }, []);

  return (
    <AuthProvider>
      <Router>
        <div className="app-root flex flex-col min-h-screen w-full relative">
          <main className="flex-grow flex flex-col">
            <Routes>
              {/* ✅ SPECIFIC ROUTES FIRST - Unwrapped and Top Level */}
              {/* CRITICAL: /go/:slug MUST be the very first route evaluated */}
              <Route path="/go/:slug" element={<Redirect />} />
              <Route path="/r/:slug" element={<Redirect />} />
              
              <Route path="/capture/:linkId" element={<LeadCapturePage />} />
              
              {/* Public Routes - Accessible without auth */}
              <Route path="/login" element={<LoginPage />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/forgot-password" element={<ForgotPasswordPage />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/billing/stripe-success" element={<BillingStripeSuccess />} />

              {/* Public marketing site — on the app subdomain these routes
                  redirect to https://linkcascade.app so app.linkcascade.app
                  stays application-only. On non-app hosts (preview) the pages
                  still render for review. */}
              <Route element={<MarketingLayout />}>
                <Route path="/" element={<HomeRoute />} />
                <Route path="/features" element={<ExternalRedirect to={`${MARKETING_BASE}/features`} fallback={<FeaturesPage />} />} />
                <Route path="/how-it-works" element={<ExternalRedirect to={`${MARKETING_BASE}/how-it-works`} fallback={<HowItWorksPage />} />} />
                <Route path="/pricing" element={<PricingRoute />} />
                <Route path="/earn-more" element={<ExternalRedirect to={`${MARKETING_BASE}/earn-more`} fallback={<EarnMorePage />} />} />
                <Route path="/early-access" element={<ExternalRedirect to={`${MARKETING_BASE}/early-access`} fallback={<EarlyAccessPage />} />} />
                <Route path="/testimonials" element={<ExternalRedirect to={`${MARKETING_BASE}/early-access`} fallback={<EarlyAccessPage />} />} />
                <Route path="/contact" element={<ExternalRedirect to={`${MARKETING_BASE}/contact`} fallback={<ContactPage />} />} />
                <Route path="/faq" element={<ExternalRedirect to={`${MARKETING_BASE}/faq`} fallback={<FaqPage />} />} />
                <Route path="/privacy" element={<ExternalRedirect to={`${MARKETING_BASE}/privacy`} fallback={<PrivacyPage />} />} />
                <Route path="/terms" element={<ExternalRedirect to={`${MARKETING_BASE}/terms`} fallback={<TermsPage />} />} />
              </Route>
              
              {/* Protected Routes - Require auth */}
              <Route
                element={
                  <ProtectedRoute>
                    <AppLayout />
                  </ProtectedRoute>
                }
              >
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/links" element={<LinkVault />} />
                <Route path="/campaigns" element={<CampaignBuilder />} />
                <Route path="/message-templates" element={<MessageTemplates />} />
                <Route path="/template-library" element={<TemplateLibrary />} />
                <Route path="/templates" element={<Navigate to="/message-templates" replace />} />
                <Route path="/copy" element={<CopyGenerator />} />
                <Route path="/earnings" element={<EarningsTracker />} />
                <Route path="/analytics" element={<Analytics />} />
                
                {/* Buyer Attribution - Redirected to dashboard for future release */}
                <Route path="/buyer-attribution" element={<Navigate to="/dashboard" replace />} />
                
                <Route path="/lead-attribution" element={<LeadAttribution />} />
                <Route path="/lead-capture-setup" element={<LeadCaptureSetup />} />
                
                {/* Settings Nested Routes */}
                <Route path="/settings" element={<SettingsLayout />}>
                  <Route index element={<AccountSettings />} />
                  <Route path="billing" element={<BillingSettings />} />
                  <Route path="security" element={<SecuritySettings />} />
                </Route>

              </Route>

              {/* ✅ CATCH-ALL ROUTE LAST */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          
          <Toaster />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;