import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  TrendingUp,
  Link2,
  MousePointerClick,
  Target,
  Copy,
  Plus,
  AlertTriangle
} from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Helmet } from 'react-helmet';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import DashboardOnboardingBanner from '@/components/DashboardOnboardingBanner';
import UpgradePromptBox from '@/components/UpgradePromptBox';
import { useLinkData } from '@/hooks/useLinkData';

const ActivationPendingBanner = () => {
  const navigate = useNavigate();

  return (
    <div className="bg-red-50 border border-red-200 text-red-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm mb-2 mt-4">
      <div className="flex items-center gap-3">
        <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0" />
        <div>
          <h3 className="font-semibold text-sm text-red-900">Activation Pending</h3>
          <p className="text-sm text-red-800 mt-0.5">
            We couldn't verify your payment yet. Your plan features may be restricted.
          </p>
        </div>
      </div>
      <Button
        variant="outline"
        className="border-red-200 text-red-700 hover:bg-red-100 hover:text-red-800 bg-white whitespace-nowrap"
        onClick={() => navigate('/settings?tab=billing')}
      >
        Check Billing
      </Button>
    </div>
  );
};

const Dashboard = () => {
  const { user, userProfile, loading: authLoading, refreshProfile } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const activationAttempted = useRef(false);

  // Use the shared hook with internal metric calculations
  const { links, totalClicks, topLink, loading, error } = useLinkData();

  const totalLinks = links?.length || 0;

  // Billing / activation state
  const [paymentVerified, setPaymentVerified] = useState(true);
  const [isActivationChecking, setIsActivationChecking] = useState(false);

  const currentPlan = userProfile?.plan || 'free';
  const pendingSessionId = localStorage.getItem('stripe_session_id_pending');

  useEffect(() => {
    refreshProfile();
  }, [refreshProfile]);

  useEffect(() => {
    if (authLoading || !user || activationAttempted.current) return;

    if (!pendingSessionId) {
      setPaymentVerified(true);
      return;
    }

    if (currentPlan === 'pro' || currentPlan === 'agency') {
      localStorage.removeItem('stripe_session_id_pending');
      setPaymentVerified(true);
      return;
    }

    activationAttempted.current = true;
    setIsActivationChecking(true);

    const activatePlan = async () => {
      toast({
        title: 'Activating your plan...',
        description: 'Verifying payment details with Stripe.'
      });

      try {
        const { data, activateError } = await supabase.functions.invoke('stripe-activate', {
          body: { session_id: pendingSessionId, user_id: user.id }
        });

        if (activateError) throw activateError;

        if (data?.success) {
          localStorage.removeItem('stripe_session_id_pending');
          await supabase.auth.refreshSession();
          await refreshProfile();

          setPaymentVerified(true);

          toast({
            title: 'Pro activated 🎉',
            description: `You are now on the ${data.plan} plan!`,
            className: 'bg-green-50 border-green-200 text-green-900'
          });
        } else {
          setPaymentVerified(false);
        }
      } catch (err) {
        console.error('Stripe activation error:', err);
        setPaymentVerified(false);
        toast({
          title: 'Activation pending',
          description: "We couldn't verify your payment yet.",
          variant: 'destructive'
        });
      } finally {
        setIsActivationChecking(false);
      }
    };

    activatePlan();
  }, [user, authLoading, pendingSessionId, currentPlan, toast, refreshProfile]);

  const statsCards = [
    {
      title: 'Total Links',
      value: totalLinks,
      icon: Link2,
      color: 'text-lc-tealdark',
      bg: 'bg-lc-teal/15'
    },
    {
      title: 'Total Clicks',
      value: totalClicks,
      icon: MousePointerClick,
      color: 'text-lc-tealdark',
      bg: 'bg-lc-teal/15'
    },
    {
      title: 'Top Link',
      value: topLink ? (topLink.title || topLink.short_code) : 'No links yet',
      icon: TrendingUp,
      color: 'text-green-600',
      bg: 'bg-green-100'
    }
  ];

  const quickActions = [
    { title: 'Create Link', path: '/links', icon: Link2, color: 'purple' },
    { title: 'New Campaign', path: '/campaigns', icon: Target, color: 'purple' },
    { title: 'Generate Copy', path: '/copy', icon: Copy, color: 'purple' }
  ];

  const shouldShowActivationPending =
    !authLoading &&
    !isActivationChecking &&
    (currentPlan === 'pro' || currentPlan === 'agency') &&
    paymentVerified === false;

  return (
    <>
      <Helmet>
        <title>Dashboard - LinkCascade</title>
      </Helmet>

      <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-8 relative">
        <DashboardOnboardingBanner />
        <UpgradePromptBox />

        {shouldShowActivationPending && <ActivationPendingBanner />}

        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mt-2">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Dashboard</h1>
            <p className="text-gray-500 mt-2 text-lg">Overview of your performance</p>
          </div>
          <div className="flex gap-3">
            {currentPlan === 'free' && (
              <Button
                variant="outline"
                onClick={() => navigate('/pricing')}
                className="border-lc-border text-lc-tealdark hover:bg-lc-teal/10"
              >
                Upgrade Plan
              </Button>
            )}
            <Button onClick={() => navigate('/links')} className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
              <Plus className="w-4 h-4 mr-2" /> Create Link
            </Button>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 text-red-800 p-4 rounded-xl border border-red-200">
            Failed to load dashboard data. Please try refreshing the page.
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {statsCards.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 rounded-lg ${stat.bg}`}>
                    <Icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                </div>
                <div>
                  <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                    {stat.title}
                  </h3>
                  {loading ? (
                    <Skeleton className="h-8 w-24" />
                  ) : (
                    <p className="text-2xl font-bold text-gray-900 truncate" title={String(stat.value)}>
                      {stat.value}
                    </p>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
          <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm p-6">
            <h2 className="text-lg font-bold text-gray-900 mb-6">Quick Actions</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {quickActions.map((action) => (
                <button
                  key={action.title}
                  onClick={() => navigate(action.path)}
                  className="flex flex-col items-center justify-center p-6 rounded-xl border border-gray-100 bg-gray-50 hover:bg-white hover:border-lc-border hover:shadow-md transition-all group text-center h-full"
                >
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center mb-3 bg-lc-teal/15 text-lc-tealdark group-hover:scale-110 transition-transform"
                  >
                    <action.icon className="w-6 h-6" />
                  </div>
                  <span className="font-semibold text-gray-900">{action.title}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
            <h2 className="text-lg font-bold text-gray-900 mb-6">System Status</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-100">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                  <span className="text-sm font-medium text-green-900">All Systems Operational</span>
                </div>
              </div>
              <div className="text-sm text-gray-500">
                Current Plan:{' '}
                <span className="font-semibold text-gray-900 capitalize">{currentPlan}</span>
              </div>
            </div>
          </div>
        </div>

        {!loading && totalLinks === 0 && (
          <div className="bg-white rounded-xl border border-dashed border-gray-300 p-12 text-center mt-8">
            <div className="w-16 h-16 bg-lc-teal/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Link2 className="w-8 h-8 text-lc-teal" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">No data available</h3>
            <p className="text-gray-500 mb-6 max-w-sm mx-auto">
              Start by creating your first tracking link to see analytics and insights here.
            </p>
            <Button onClick={() => navigate('/links')} className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite">
              Create First Link
            </Button>
          </div>
        )}
      </div>
    </>
  );
};

export default Dashboard;