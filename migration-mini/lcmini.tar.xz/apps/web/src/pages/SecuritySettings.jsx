import React, { useState } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Shield, Key, LogOut, Loader2, Lock } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { useNavigate } from 'react-router-dom';

const SecuritySettings = () => {
  const { user, signOut } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [resetLoading, setResetLoading] = useState(false);
  const [signoutLoading, setSignoutLoading] = useState(false);

  const handleChangePassword = async () => {
    setResetLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(user.email, {
        redirectTo: `${window.location.origin}/auth/reset-password`,
      });
      
      if (error) throw error;
      
      toast({
        title: "Password Reset Email Sent",
        description: "Check your inbox for instructions to reset your password.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setResetLoading(false);
    }
  };

  const handleGlobalSignOut = async () => {
    if (!confirm("Are you sure you want to sign out of all sessions? You will need to log in again.")) return;
    
    setSignoutLoading(true);
    try {
      // Supabase standard sign out handles current session.
      // Global sign out usually requires admin capabilities or scoped sessions, 
      // but for client side, we generally just sign out the current client effectively.
      // However, supabase.auth.signOut({ scope: 'global' }) is the method if supported by version.
      // For standard client, we'll just use signOut() which invalidates the current token.
      
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      
      navigate('/login');
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to sign out.",
        variant: "destructive"
      });
      setSignoutLoading(false);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-8">
      <div>
        <h2 className="text-xl font-bold text-gray-900">Security</h2>
        <p className="text-gray-500 text-sm mt-1">Manage your password and session security.</p>
      </div>

      <div className="space-y-6">
        <div className="flex items-start gap-4 p-4 rounded-lg bg-gray-50 border border-gray-200">
           <div className="p-2 bg-white rounded-lg border border-gray-100 shadow-sm">
              <Key className="w-5 h-5 text-gray-600" />
           </div>
           <div className="flex-1">
              <h3 className="font-bold text-gray-900 mb-1">Password</h3>
              <p className="text-sm text-gray-600 mb-4">Send a password reset link to your email address: <span className="font-medium text-gray-900">{user?.email}</span></p>
              <Button 
                onClick={handleChangePassword} 
                disabled={resetLoading}
                variant="outline"
                className="bg-white"
              >
                {resetLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                   "Change Password"
                )}
              </Button>
           </div>
        </div>

        <div className="flex items-start gap-4 p-4 rounded-lg bg-red-50 border border-red-100">
           <div className="p-2 bg-white rounded-lg border border-red-100 shadow-sm">
              <LogOut className="w-5 h-5 text-red-600" />
           </div>
           <div className="flex-1">
              <h3 className="font-bold text-red-900 mb-1">Session Management</h3>
              <p className="text-sm text-red-700 mb-4">Sign out of all active sessions on all devices.</p>
              <Button 
                onClick={handleGlobalSignOut} 
                disabled={signoutLoading}
                variant="destructive"
                className="bg-white text-red-600 border border-red-200 hover:bg-red-50 hover:text-red-700"
              >
                {signoutLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Signing out...
                  </>
                ) : (
                   "Sign Out of All Sessions"
                )}
              </Button>
           </div>
        </div>
      </div>
      
      <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
        <div className="flex items-center gap-2 mb-2 text-blue-800 font-bold">
            <Lock className="w-4 h-4" />
            Security Tips
        </div>
        <ul className="list-disc list-inside text-sm text-blue-700 space-y-1">
            <li>Use a strong, unique password for your account.</li>
            <li>Regularly check your billing history for unrecognized charges.</li>
            <li>Sign out from public computers immediately after use.</li>
        </ul>
      </div>
    </div>
  );
};

export default SecuritySettings;