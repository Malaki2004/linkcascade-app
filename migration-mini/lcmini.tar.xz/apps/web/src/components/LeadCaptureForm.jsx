import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

const LeadCaptureForm = ({ linkId, campaignId, sourceChannel, userId, linkTitle, destinationUrl, slug }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: ''
  });
  const [status, setStatus] = useState('idle'); // 'idle', 'submitting', 'success', 'error'
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.email.trim()) {
      setStatus('error');
      setErrorMessage('Please fill in all required fields.');
      return;
    }

    setStatus('submitting');

    try {
      const { data, error: insertError } = await supabase.from('leads').insert([{
        link_id: linkId,
        campaign_id: campaignId || null,
        user_id: userId,
        lead_name: formData.name,
        lead_email: formData.email,
        lead_phone: formData.phone || null,
        form_name: 'lead_capture_form',
        source_channel: sourceChannel || 'short_link',
        status: 'new'
      }]);

      if (insertError) {
        throw insertError;
      }
      
      // Fire-and-forget last_activity update
      supabase.from('links').update({ last_activity: new Date().toISOString() }).eq('id', linkId).then();

      setStatus('success');

      setTimeout(() => {
        if (destinationUrl) {
          window.location.replace(destinationUrl);
        }
      }, 1000);

    } catch (err) {
      console.error(err);
      setStatus('error');
      setErrorMessage('An error occurred. Please try again.');
    }
  };

  const isSubmitting = status === 'submitting';
  const isSuccess = status === 'success';

  return (
    <div style={{
      width: '100vw',
      height: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#FFFFFF',
      position: 'fixed',
      top: 0,
      left: 0,
      zIndex: 9999,
      padding: '20px',
      boxSizing: 'border-box',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    }}>
      <div style={{
        backgroundColor: '#FFFFFF',
        padding: '40px',
        borderRadius: '8px',
        boxShadow: '0 2px 12px rgba(0, 0, 0, 0.08)',
        border: '1px solid #eaeaea',
        width: '100%',
        maxWidth: '400px',
        boxSizing: 'border-box'
      }}>
        {isSuccess ? (
          <div style={{ textAlign: 'center', padding: '20px 0' }}>
            <h2 style={{ color: '#333333', margin: '0 0 10px 0', fontSize: '20px', fontWeight: '500' }}>
              Redirecting...
            </h2>
          </div>
        ) : (
          <>
            <h2 style={{
              marginTop: 0,
              marginBottom: '24px',
              fontSize: '22px',
              color: '#333333',
              textAlign: 'center',
              fontWeight: '600'
            }}>
              {linkTitle ? `Access: ${linkTitle}` : 'Get Started'}
            </h2>

            {status === 'error' && (
              <div style={{
                backgroundColor: '#fff',
                border: '1px solid #ffcdd2',
                color: '#d32f2f',
                padding: '12px',
                borderRadius: '4px',
                marginBottom: '20px',
                fontSize: '13px',
                textAlign: 'center'
              }}>
                {errorMessage}
              </div>
            )}

            <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column' }}>
              <input
                type="text"
                required
                disabled={isSubmitting}
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: '4px',
                  border: '1px solid #ddd',
                  fontSize: '14px',
                  marginBottom: '12px',
                  boxSizing: 'border-box',
                  color: '#333333'
                }}
                placeholder="Name *"
              />

              <input
                type="email"
                required
                disabled={isSubmitting}
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: '4px',
                  border: '1px solid #ddd',
                  fontSize: '14px',
                  marginBottom: '12px',
                  boxSizing: 'border-box',
                  color: '#333333'
                }}
                placeholder="Email *"
              />

              <input
                type="tel"
                disabled={isSubmitting}
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: '4px',
                  border: '1px solid #ddd',
                  fontSize: '14px',
                  marginBottom: '20px',
                  boxSizing: 'border-box',
                  color: '#333333'
                }}
                placeholder="Phone (Optional)"
              />

              <button
                type="submit"
                disabled={isSubmitting}
                style={{
                  width: '100%',
                  padding: '12px',
                  minHeight: '44px',
                  backgroundColor: isSubmitting ? '#e0e0e0' : '#333333',
                  color: isSubmitting ? '#666666' : '#FFFFFF',
                  border: 'none',
                  borderRadius: '4px',
                  fontSize: '14px',
                  fontWeight: '500',
                  cursor: isSubmitting ? 'not-allowed' : 'pointer',
                  transition: 'background-color 0.2s',
                }}
              >
                {isSubmitting ? 'Submitting...' : 'Continue'}
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default LeadCaptureForm;