export const FEATURED_TEMPLATES = [
  {
    id: 'featured-1',
    title: 'Welcome Email',
    body: "Hi [Name],\n\nWelcome to the community! We're thrilled to have you here.\n\nHere are a few resources to get you started:\n[Link 1]\n[Link 2]\n\nLet us know if you have any questions!\n\nBest,\n[Your Name]",
    platform: 'Email',
    tone: 'Friendly'
  },
  {
    id: 'featured-2',
    title: 'Follow-up Message',
    body: "Hey [Name], just checking in to see if you had a chance to look at the info I sent over?\n\nLet me know if you need anything else!\n\nCheers,\n[Your Name]",
    platform: 'LinkedIn',
    tone: 'Casual'
  },
  {
    id: 'featured-3',
    title: 'Promotional Post',
    body: "🔥 Flash Sale Alert! 🔥\n\nGet 50% off for the next 24 hours only. Don't miss out on this exclusive deal.\n\nShop now: [Link] 🚀\n\n#Sale #Deal #Discount",
    platform: 'Instagram',
    tone: 'Urgent'
  },
  {
    id: 'featured-4',
    title: 'Product Launch',
    body: "We've been working on this for months, and it's finally here... 🥁\n\nIntroducing [Product Name] – the solution you've been waiting for.\n\nCheck it out: [Link]",
    platform: 'Twitter',
    tone: 'Excited'
  },
  {
    id: 'featured-5',
    title: 'Customer Support',
    body: "Hi [Name],\n\nThanks for reaching out. I'm sorry to hear you're experiencing issues with [Product].\n\nI've escalated this to our technical team, and we'll get back to you within 24 hours.\n\nBest,\nSupport Team",
    platform: 'Email',
    tone: 'Professional'
  },
  {
    id: 'featured-6',
    title: 'Event Invitation',
    body: "You're invited! 🎉\n\nJoin us for an exclusive webinar on [Topic] this [Date].\n\nReserve your spot here: [Link]\n\nSee you there!",
    platform: 'Email',
    tone: 'Friendly'
  },
  {
    id: 'featured-7',
    title: 'Thank You Note',
    body: "Thank you so much for your purchase! We truly appreciate your support.\n\nWe hope you love your new [Product]. If you do, feel free to tag us in your photos! 📸",
    platform: 'Email',
    tone: 'Warm'
  },
  {
    id: 'featured-8',
    title: 'Feedback Request',
    body: "Hi [Name],\n\nHow did we do? We'd love to hear your thoughts on your recent experience.\n\nTake 30 seconds to leave feedback: [Link]\n\nThanks for helping us improve!",
    platform: 'Email',
    tone: 'Professional'
  },
  {
    id: 'featured-9',
    title: 'Engagement Post',
    body: "Question of the day: What's one tool you can't live without in your daily workflow? 👇\n\nDrop your answers below!",
    platform: 'LinkedIn',
    tone: 'Casual'
  },
  {
    id: 'featured-10',
    title: 'Networking Message',
    body: "Hi [Name],\n\nI've been following your work on [Topic] and love your recent insights on [Specific Point].\n\nWould love to connect and keep up with your updates!\n\nBest,\n[Your Name]",
    platform: 'LinkedIn',
    tone: 'Professional'
  }
];