import React from 'react';
import { Helmet } from 'react-helmet';
import Seo from '@/components/Seo';
import { SITE_URL, OG_IMAGE, SUPPORT_EMAIL } from '@/lib/brand';

const TITLE = 'Privacy Policy | LinkCascade';
const DESCRIPTION =
  'How LinkCascade collects, uses, and protects personal information when you use the website and the link-tracking application.';

const sections = [
  {
    title: 'Information we collect',
    body: [
      'Account information. When you create an account, we collect your email address and the password you use to sign in (passwords are handled by our authentication provider and are not stored in plain text).',
      'Content you create. We store the links, campaigns, templates, earnings records, and related information you add to your account so the service can work for you.',
      'Usage and tracking data. When someone opens one of your short links, we record the click event so we can show you link and campaign performance.',
      'Communications. If you contact us, we keep the messages you send so we can respond and follow up.',
    ],
  },
  {
    title: 'How we use information',
    body: [
      'To provide and operate the service, including your dashboard, links, campaigns, and reports.',
      'To respond to support requests and communicate with you about your account.',
      'To maintain the security and reliability of the service.',
      'We do not sell your personal information.',
    ],
  },
  {
    title: 'Service providers',
    body: [
      'We use third-party providers to operate LinkCascade, including Supabase (authentication and database), Stripe (payment processing for paid plans), and an email delivery provider (support and account emails). These providers process information only as needed to deliver their services to us.',
    ],
  },
  {
    title: 'Cookies and storage',
    body: [
      'We use cookies and similar browser storage to keep you signed in and to remember your preferences. You can control cookies through your browser settings, though some features may not work without them.',
    ],
  },
  {
    title: 'Data retention and your choices',
    body: [
      'We keep your account information for as long as your account is active. You can request access to, correction of, or deletion of your personal information by contacting us. Some records may be retained where required for legitimate business or legal purposes.',
    ],
  },
  {
    title: 'Security',
    body: [
      'We use reasonable administrative and technical measures to protect your information. No method of transmission or storage is completely secure, so we cannot guarantee absolute security.',
    ],
  },
  {
    title: 'Changes to this policy',
    body: [
      'If we update this Privacy Policy, we will post the revised version on this page and update the date below.',
    ],
  },
  {
    title: 'Contact',
    body: [`Questions about this policy? Email us at ${SUPPORT_EMAIL}.`],
  },
];

const PrivacyPage = () => {
  return (
    <>
      <Helmet>
        <title>{TITLE}</title>
        <meta name="description" content={DESCRIPTION} />
      </Helmet>
      <Seo title={TITLE} description={DESCRIPTION} image={OG_IMAGE} url={`${SITE_URL}/privacy`} />

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-4xl px-6 py-16">
          <p className="font-serif text-lg italic text-lc-tealdark">Legal</p>
          <h1 className="mt-3 text-4xl font-extrabold tracking-tight text-lc-graphite md:text-5xl">Privacy Policy</h1>
          <p className="mt-4 text-sm text-lc-slate">Last updated: September 13, 2026</p>
          <p className="mt-6 max-w-2xl leading-relaxed text-lc-slate">
            This Privacy Policy explains what information LinkCascade collects when you use our website and
            application, and how we use it.
          </p>

          <div className="mt-12 space-y-10">
            {sections.map((section) => (
              <section key={section.title} className="border-t-2 border-lc-graphite pt-6">
                <h2 className="text-xl font-extrabold tracking-tight text-lc-graphite">{section.title}</h2>
                <div className="mt-4 space-y-3">
                  {section.body.map((paragraph, i) => (
                    <p key={i} className="text-sm leading-relaxed text-lc-slate">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </section>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default PrivacyPage;
