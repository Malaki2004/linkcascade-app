import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Lock, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Helmet } from 'react-helmet';

const ResetPassword = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);

  // null = still verifying, true = ok, false = invalid
  const [sessionValid, setSessionValid] = useState(null);

  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    let mounted = true;

    const verifyRecoverySession = async () => {
      try {
        // IMPORTANT:
        // Supabase recovery flow does NOT always provide ?code=
        // It often comes from /auth/v1/verify?token=...&type=recovery
        // which creates a session and redirects here WITHOUT a code.
        //
        // So we must WAIT and listen for auth state changes.

        // 1) Listen for auth state changes
        const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
          if (!mounted) return;

          // PASSWORD_RECOVERY is the expected event
          // SIGNED_IN can also occur depending on the SDK behavior
          if ((event === 'PASSWORD_RECOVERY' || event === 'SIGNED_IN') && session) {
            setSessionValid(true);
          }
        });

        // 2) Also check session repeatedly for a short window
        // This prevents the "instant invalid" bug.
        const start = Date.now();
        const maxWaitMs = 6000; // wait up to 6 seconds
        const intervalMs = 500;

        const interval = setInterval(async () => {
          if (!mounted) return;

          const { data: { session }, error } = await supabase.auth.getSession();

          if (session && !error) {
            clearInterval(interval);
            subscription.unsubscribe();
            if (mounted) setSessionValid(true);
            return;
          }

          // timeout after maxWaitMs
          if (Date.now() - start > maxWaitMs) {
            clearInterval(interval);
            subscription.unsubscribe();
            if (mounted) setSessionValid(false);
          }
        }, intervalMs);

      } catch (error) {
        console.error('Reset session verify error:', error);
        if (mounted) setSessionValid(false);
      }
    };

    verifyRecoverySession();

    return () => {
      mounted = false;
    };
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (password.length < 6) {
      toast({
        title: 'Invalid Password',
        description: 'Password must be at least 6 characters long.',
        variant: 'destructive',
      });
      return;
    }

    if (password !== confirmPassword) {
      toast({
        title: 'Passwords do not match',
        description: 'Please ensure both passwords match.',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);

    try {
      // Must have a valid recovery session for this to work
      const { error } = await supabase.auth.updateUser({ password });

      if (error) throw error;

      toast({
        title: 'Success!',
        description: 'Your password has been updated successfully.',
      });

      // Sign out after successful reset to force clean login
      await supabase.auth.signOut();

      navigate('/login', {
        state: { message: 'Password reset successful. Please log in with your new password.' }
      });

    } catch (error) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update password.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (sessionValid === false) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-lc-graphite p-4">
        <Helmet>
          <title>Invalid Link - LinkCascade</title>
          <meta name="robots" content="noindex, nofollow" />
        </Helmet>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full text-center"
        >
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-8 h-8 text-red-600" />
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Invalid or Expired Link
          </h2>

          <p className="text-gray-600 mb-6">
            This password reset link is no longer valid. Please request a new one.
          </p>

          <Button
            onClick={() => navigate('/forgot-password')}
            className="w-full bg-lc-teal hover:bg-lc-tealdark text-lc-graphite"
          >
            Request New Link
          </Button>
        </motion.div>
      </div>
    );
  }

  if (sessionValid === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-lc-graphite">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-lc-teal"></div>
          <p className="text-white font-medium animate-pulse">
            Verifying reset link...
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Reset Password - LinkCascade</title>
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>

      <div className="min-h-screen flex items-center justify-center bg-lc-graphite p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <div className="bg-white rounded-xl shadow-2xl p-8">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-lc-teal/15 rounded-full mb-4">
                <Lock className="w-8 h-8 text-lc-tealdark" />
              </div>

              <h1 className="text-2xl font-bold text-gray-900">
                Set New Password
              </h1>

              <p className="text-gray-600 mt-2">
                Enter your new password below.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  New Password
                </label>

                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />

                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={6}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-lc-teal focus:border-transparent transition outline-none bg-white text-gray-900"
                    placeholder="••••••••"
                  />
                </div>

                <p className="text-xs text-gray-500 mt-1">
                  Must be at least 6 characters long
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Confirm Password
                </label>

                <div className="relative">
                  <CheckCircle className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />

                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    minLength={6}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-lc-teal focus:border-transparent transition outline-none bg-white text-gray-900"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-lc-teal hover:bg-lc-tealdark text-lc-graphite py-3 rounded-lg font-bold shadow-lg transition-all hover:shadow-xl"
              >
                {loading ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                    Updating Password...
                  </>
                ) : (
                  'Update Password'
                )}
              </Button>
            </form>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default ResetPassword;