import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { Search, Library, AlertCircle } from 'lucide-react';
import TemplateCard from '@/components/TemplateCard';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';

const CATEGORIES = [
  'All', 
  'Lead Generation', 
  'Follow-Up & Nurture', 
  'Product Launch & Promotions', 
  'Customer Retention & Loyalty', 
  'Networking & Partnerships'
];

const PLATFORMS = [
  'All', 
  'Email', 
  'LinkedIn', 
  'Instagram', 
  'Twitter', 
  'SMS'
];

const TONES = [
  'All', 
  'Professional', 
  'Friendly', 
  'Urgent', 
  'Casual', 
  'Exciting', 
  'Warm', 
  'Respectful'
];

const TemplateLibrary = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const [loading, setLoading] = useState(true);
  const [systemTemplates, setSystemTemplates] = useState([]);
  const [filters, setFilters] = useState({ search: '', category: 'All', platform: 'All', tone: 'All' });

  useEffect(() => {
    fetchSystemTemplates();
  }, []);

  const fetchSystemTemplates = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('message_templates')
        .select('*')
        .is('user_id', null)
        .order('id', { ascending: true });

      if (error) throw error;
      // IMPORTANT: Do not apply any slicing/limiting here. Show all available templates.
      setSystemTemplates(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Error fetching system templates:', error);
      toast({
        title: 'Error',
        description: 'Failed to load template library.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  // Memoized filtering logic to replace separate state
  const filteredTemplates = useMemo(() => {
    const search = (filters.search || '').trim().toLowerCase();

    return systemTemplates.filter((t) => {
      if (filters.category !== 'All' && t.category !== filters.category) return false;
      if (filters.platform !== 'All' && t.platform !== filters.platform) return false;
      if (filters.tone !== 'All' && t.tone !== filters.tone) return false;

      if (search) {
        const haystack = [
          t.title,
          t.body,
          t.description,
          t.cta,
          typeof t.placeholders === 'string' ? t.placeholders : JSON.stringify(t.placeholders || '')
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase();

        if (!haystack.includes(search)) return false;
      }
      return true;
    });
  }, [systemTemplates, filters]);

  const handleUseCreate = (template) => {
    navigate('/message-templates', { state: { createFromTemplate: template } });
  };

  const handleToggleFavorite = () => {
    toast({
      title: 'Not implemented',
      description: 'Favoriting system templates will be saved to your profile soon.'
    });
  };

  return (
    <>
      <Helmet>
        <title>Template Library - LinkCascade</title>
      </Helmet>

      <div className="p-6 md:p-8 max-w-7xl mx-auto min-h-screen">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight flex items-center gap-2">
              <Library className="w-8 h-8 text-lc-tealdark" />
              Template Library
            </h1>
            <p className="text-gray-500 mt-2">Browse 50+ high-converting system templates for any scenario.</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm mb-8 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search templates by keyword, title, or content..."
              value={filters.search}
              onChange={(e) => setFilters(f => ({ ...f, search: e.target.value }))}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-lc-teal focus:border-transparent outline-none bg-white text-gray-900"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Category</label>
              <select
                value={filters.category}
                onChange={(e) => setFilters(f => ({ ...f, category: e.target.value }))}
                className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-gray-900"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Platform</label>
              <select
                value={filters.platform}
                onChange={(e) => setFilters(f => ({ ...f, platform: e.target.value }))}
                className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-gray-900"
              >
                {PLATFORMS.map((p) => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Tone</label>
              <select
                value={filters.tone}
                onChange={(e) => setFilters(f => ({ ...f, tone: e.target.value }))}
                className="w-full border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-gray-900"
              >
                {TONES.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-lc-teal"></div>
          </div>
        ) : filteredTemplates.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-xl border border-dashed border-gray-300">
            <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-gray-900">No templates found</h3>
            <p className="text-gray-500 mb-6">Try adjusting your filters or search query.</p>
            <button
              onClick={() => setFilters({ search: '', category: 'All', platform: 'All', tone: 'All' })}
              className="text-lc-tealdark hover:text-lc-tealdark font-medium"
            >
              Clear all filters
            </button>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm text-gray-500">
                Showing <span className="font-semibold text-gray-900">{filteredTemplates.length}</span> templates
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTemplates.map((template) => (
                <TemplateCard
                  key={template.id}
                  template={template}
                  isCustom={false}
                  onUseCreate={handleUseCreate}
                  onToggleFavorite={handleToggleFavorite}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default TemplateLibrary;