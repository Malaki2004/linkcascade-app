import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { User, Camera, Loader2, Save, LogOut } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';

const AccountSettings = () => {
  const { user, signOut } = useAuth();
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  
  const [isLoading, setIsLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  // Consolidated profile state as requested
  const [profile, setProfile] = useState({
    full_name: '',
    website: '',
    avatar_url: null
  });

  useEffect(() => {
    if (user?.id) {
      fetchUserProfile();
    }
  }, [user?.id]);

  const fetchUserProfile = async () => {
    try {
      setIsLoading(true);
      console.log('Fetching profile for user:', user.id);
      
      const { data, error } = await supabase
        .from('profiles')
        .select('avatar_url, full_name, website')
        .eq('id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        console.log('Profile data fetched:', data);
        setProfile({
          full_name: data.full_name || user?.user_metadata?.full_name || '',
          website: data.website || '',
          avatar_url: data.avatar_url || null
        });
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
      toast({
        title: "Error Loading Profile",
        description: "Could not load your profile data. Please refresh.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    console.log('Saving profile data:', profile);

    try {
      // Update profiles table
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          full_name: profile.full_name,
          website: profile.website,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);

      if (profileError) throw profileError;

      // Also update auth metadata for redundancy
      const { error: authError } = await supabase.auth.updateUser({
        data: {
          full_name: profile.full_name,
          website: profile.website,
        }
      });

      if (authError) {
        console.warn('Auth metadata update failed, but DB update succeeded:', authError);
      }

      toast({
        title: "Profile Updated",
        description: "Your account information has been saved successfully.",
      });
    } catch (error) {
      console.error('Save error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to update profile.",
        variant: "destructive"
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleAvatarUpload = async (event) => {
    try {
      const file = event.target.files?.[0];
      if (!file) return;

      console.log('Starting avatar upload for file:', file.name);

      // 1. Validation
      const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
      if (!allowedTypes.includes(file.type)) {
        toast({
          title: "Invalid File Type",
          description: "Please upload a PNG, JPG, or WebP image.",
          variant: "destructive"
        });
        return;
      }

      if (file.size > 5 * 1024 * 1024) { // 5MB
        toast({
          title: "File Too Large",
          description: "Image size must be less than 5MB.",
          variant: "destructive"
        });
        return;
      }

      setIsUploading(true);

      // 2. Upload to Supabase Storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `${user.id}/${fileName}`;
      
      console.log('Uploading to path:', filePath);

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file, { upsert: true });

      if (uploadError) throw uploadError;

      // 3. Get Public URL
      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      console.log('Generated public URL:', publicUrl);

      // 4. Update Profile Table immediately
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ 
          avatar_url: publicUrl,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (updateError) throw updateError;

      // 5. Update Local State
      setProfile(prev => ({ ...prev, avatar_url: publicUrl }));
      
      toast({
        title: "Success",
        description: "Profile photo updated successfully.",
      });

    } catch (error) {
      console.error('Upload flow error:', error);
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload profile photo.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
      // Reset input to allow selecting same file again if needed
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      toast({ title: "Signed out", description: "You have been logged out successfully." });
    } catch (error) {
      toast({ title: "Error", description: "Failed to sign out.", variant: "destructive" });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 text-lc-tealdark animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 space-y-8 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Account Information</h2>
          <p className="text-gray-500 text-sm mt-1">Update your personal details and public profile.</p>
        </div>
        <Button variant="outline" onClick={handleSignOut} className="text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200">
          <LogOut className="w-4 h-4 mr-2" />
          Sign Out
        </Button>
      </div>

      <div className="flex items-center gap-6 pb-8 border-b border-gray-100">
        <div 
          className="relative group cursor-pointer" 
          onClick={handleFileSelect}
        >
          <div className="w-24 h-24 bg-lc-teal/15 rounded-full flex items-center justify-center border-4 border-white shadow-lg overflow-hidden relative">
             {isUploading ? (
               <div className="absolute inset-0 bg-black/40 flex items-center justify-center z-10 transition-all">
                 <Loader2 className="w-8 h-8 text-white animate-spin" />
               </div>
             ) : null}
             
             {profile.avatar_url ? (
                 <img 
                   src={profile.avatar_url} 
                   alt="Profile" 
                   className="w-full h-full object-cover"
                   onError={(e) => {
                     // Fallback if image fails to load
                     e.target.style.display = 'none';
                     e.target.parentNode.classList.add('flex', 'items-center', 'justify-center');
                     const icon = document.createElement('div');
                     icon.innerHTML = '<svg class="w-10 h-10 text-lc-teal" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
                     e.target.parentNode.appendChild(icon);
                   }}
                 />
             ) : (
                 <User className="w-10 h-10 text-lc-teal" />
             )}
          </div>
          
          <div className="absolute bottom-0 right-0 p-1.5 bg-white rounded-full shadow-md border border-gray-100 group-hover:scale-110 transition-transform z-20">
            <Camera className="w-4 h-4 text-lc-tealdark" />
          </div>
          
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleAvatarUpload}
            accept="image/png, image/jpeg, image/jpg, image/webp"
            className="hidden"
          />
        </div>
        
        <div>
          <h3 className="font-bold text-gray-900 text-lg">Profile Photo</h3>
          <p className="text-sm text-gray-500 mb-3 max-w-xs">
            Supports PNG, JPG, JPEG, or WebP. Max size 5MB.
          </p>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleFileSelect}
            disabled={isUploading}
          >
            {isUploading ? 'Uploading...' : 'Upload Photo'}
          </Button>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6 max-w-xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Full Name</label>
            <input
              type="text"
              value={profile.full_name}
              onChange={(e) => setProfile({ ...profile, full_name: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-lc-teal focus:border-transparent outline-none bg-white text-gray-900 transition-all"
              placeholder="e.g. John Doe"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Website</label>
            <input
              type="url"
              value={profile.website}
              onChange={(e) => setProfile({ ...profile, website: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-lc-teal focus:border-transparent outline-none bg-white text-gray-900 transition-all"
              placeholder="https://example.com"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700">Email Address</label>
          <div className="flex items-center gap-2">
            <input
              type="email"
              value={user?.email || ''}
              disabled
              className="w-full px-3 py-2 border border-gray-200 rounded-lg bg-gray-50 text-gray-500 cursor-not-allowed"
            />
            <span className="text-xs font-medium text-green-600 bg-green-50 px-2.5 py-1 rounded-full border border-green-100 shrink-0 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
              Verified
            </span>
          </div>
          <p className="text-xs text-gray-400">Email address cannot be changed directly.</p>
        </div>
        
        <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">User ID</label>
            <code className="block w-full px-3 py-2 border border-gray-200 rounded-lg bg-gray-50 text-gray-500 font-mono text-xs">
                {user?.id}
            </code>
        </div>

        <div className="pt-4 flex gap-4">
          <Button type="submit" disabled={isSaving || isUploading} className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite min-w-[140px]">
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default AccountSettings;