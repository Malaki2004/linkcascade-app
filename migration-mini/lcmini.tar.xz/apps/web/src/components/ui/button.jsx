import { cn } from '@/lib/utils';
import { Slot } from '@radix-ui/react-slot';
import { cva } from 'class-variance-authority';
import React from 'react';

const buttonVariants = cva(
	'inline-flex items-center justify-center rounded-lg text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-lc-teal focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none ring-offset-white',
	{
		variants: {
			variant: {
				default: 'bg-lc-teal text-lc-graphite hover:bg-lc-tealdark shadow-sm hover:shadow-md',
				destructive:
          'bg-red-500 text-white hover:bg-red-600 shadow-sm hover:shadow-md',
				outline:
          'border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 shadow-sm',
				secondary:
          'bg-lc-teal/10 text-lc-tealdark hover:bg-lc-teal/20 border border-lc-border',
				ghost: 'hover:bg-lc-teal/10 text-gray-700 hover:text-lc-tealdark',
				link: 'text-lc-tealdark underline-offset-4 hover:underline',
			},
			size: {
				default: 'h-10 px-4 py-2',
				sm: 'h-9 px-3 rounded-md',
				lg: 'h-12 px-8 rounded-lg text-base',
				icon: 'h-10 w-10',
			},
		},
		defaultVariants: {
			variant: 'default',
			size: 'default',
		},
	},
);

const Button = React.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	const Comp = asChild ? Slot : 'button';
	return (
		<Comp
			className={cn(buttonVariants({ variant, size, className }))}
			ref={ref}
			{...props}
		/>
	);
});
Button.displayName = 'Button';

export { Button, buttonVariants };