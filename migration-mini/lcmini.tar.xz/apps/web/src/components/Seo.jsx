import React from 'react';
import { Helmet } from 'react-helmet';

/**
 * Social / canonical tags. Deliberately renders no <title> —
 * each page keeps its own <Helmet> title + meta description.
 */
const Seo = ({ title, description, image, url, siteName = 'LinkCascade', type = 'website' }) => {
  return (
    <Helmet>
      {url && <link rel="canonical" href={url} />}
      {title && <meta property="og:title" content={title} />}
      {description && <meta property="og:description" content={description} />}
      {image && <meta property="og:image" content={image} />}
      {url && <meta property="og:url" content={url} />}
      {siteName && <meta property="og:site_name" content={siteName} />}
      {type && <meta property="og:type" content={type} />}
      <meta name="twitter:card" content="summary_large_image" />
      {title && <meta name="twitter:title" content={title} />}
      {description && <meta name="twitter:description" content={description} />}
      {image && <meta name="twitter:image" content={image} />}
    </Helmet>
  );
};

export default Seo;
