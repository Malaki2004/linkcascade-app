import React, { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FileQuestion, Home, LogIn } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Helmet } from 'react-helmet';

const NotFound = () => {
  console.log('[NOT_FOUND] mounted');
  
  const { user } = useAuth();
  const location = useLocation();

  useEffect(() => {
    console.log(`[NOT_FOUND_ROUTE] Catch-all route hit for path: ${location.pathname}`);
  }, [location]);

  return (
    <>
      <Helmet>
        <title>404 - Page Not Found | LinkCascade</title>
        <meta name="description" content="The page you are looking for does not exist." />
      </Helmet>
      
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="text-center w-full max-w-lg"
        >
          <motion.div 
            initial={{ y: -20 }}
            animate={{ y: 0 }}
            transition={{ delay: 0.1, type: "spring", stiffness: 200 }}
            className="w-24 h-24 bg-lc-teal/15 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <FileQuestion className="w-12 h-12 text-lc-tealdark" />
          </motion.div>

          <h1 className="text-4xl font-extrabold text-gray-900 mb-2">Page not found</h1>
          <p className="text-gray-600 mb-8 text-lg">
            Oops! The page you're looking for doesn't exist or has been moved.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {user ? (
              <Button asChild size="lg" className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite shadow-md">
                <Link to="/dashboard" className="flex items-center gap-2">
                  <Home className="w-4 h-4" />
                  Return to Dashboard
                </Link>
              </Button>
            ) : (
              <Button asChild size="lg" className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite shadow-md">
                <Link to="/login" className="flex items-center gap-2">
                  <LogIn className="w-4 h-4" />
                  Go to Login
                </Link>
              </Button>
            )}
            
            <Button asChild variant="outline" size="lg">
              <Link to={user ? "/dashboard" : "/"}>
                Go Back Home
              </Link>
            </Button>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default NotFound;