import React, { useState } from 'react';
import { ChevronRight, ChevronDown, Folder, Plus, Edit2, Trash2, FolderOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';
import TemplateCard from './TemplateCard';

const FolderItem = ({ folder, templates, onEditFolder, onDeleteFolder, onCreateTemplate, onTemplateActions }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const folderTemplates = templates.filter(t => t.folder_id === folder.id);

  return (
    <div className="border border-gray-200 rounded-lg bg-white overflow-hidden mb-3 shadow-sm">
      <div 
        className="flex items-center justify-between p-4 cursor-pointer hover:bg-lc-teal/10 transition-colors"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-3">
          {isExpanded ? (
            <ChevronDown className="w-5 h-5 text-gray-400" />
          ) : (
            <ChevronRight className="w-5 h-5 text-gray-400" />
          )}
          <div className="p-2 bg-lc-teal/15 rounded-lg text-lc-tealdark">
            {isExpanded ? <FolderOpen className="w-5 h-5" /> : <Folder className="w-5 h-5" />}
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{folder.name}</h3>
            <p className="text-xs text-gray-500">{folderTemplates.length} templates</p>
          </div>
        </div>

        <div className="flex items-center gap-2" onClick={e => e.stopPropagation()}>
          <Button variant="ghost" size="sm" onClick={() => onEditFolder(folder)} className="hover:text-lc-tealdark hover:bg-lc-teal/10">
            <Edit2 className="w-4 h-4 text-gray-500" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => onDeleteFolder(folder)}>
            <Trash2 className="w-4 h-4 text-red-500" />
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-gray-100 bg-gray-50/50"
          >
            <div className="p-4">
              <div className="flex justify-end mb-4">
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="bg-white border-dashed border-lc-border text-lc-tealdark hover:bg-lc-teal/10"
                  onClick={() => onCreateTemplate(folder.id)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Template to Folder
                </Button>
              </div>

              {folderTemplates.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {folderTemplates.map(template => (
                    <TemplateCard
                      key={template.id}
                      template={template}
                      isCustom={true}
                      onEdit={onTemplateActions.onEdit}
                      onDelete={onTemplateActions.onDelete}
                      onMove={onTemplateActions.onMove}
                      onToggleFavorite={onTemplateActions.onToggleFavorite}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-gray-400">
                  <p>No templates in this folder yet.</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const FolderList = ({ folders, templates, onEditFolder, onDeleteFolder, onCreateTemplate, onTemplateActions }) => {
  if (folders.length === 0) {
    return (
      <div className="text-center py-12 bg-lc-teal/5 rounded-xl border-2 border-dashed border-lc-border">
        <Folder className="w-12 h-12 text-lc-teal mx-auto mb-3" />
        <h3 className="text-lg font-medium text-gray-900">No Folders</h3>
        <p className="text-gray-500">Create folders to organize your templates.</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {folders.map(folder => (
        <FolderItem 
          key={folder.id} 
          folder={folder} 
          templates={templates}
          onEditFolder={onEditFolder}
          onDeleteFolder={onDeleteFolder}
          onCreateTemplate={onCreateTemplate}
          onTemplateActions={onTemplateActions}
        />
      ))}
    </div>
  );
};

export default FolderList;