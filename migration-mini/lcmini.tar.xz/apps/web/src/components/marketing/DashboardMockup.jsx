import React from 'react';
import { cn } from '@/lib/utils';

const bars = [42, 58, 36, 70, 52, 88, 64];

/**
 * Stylized product visual built in HTML/CSS so it stays honest,
 * lightweight, and crawlable — not a fake screenshot.
 */
const DashboardMockup = ({ caption = 'LinkCascade dashboard — product preview', float = false, className = '' }) => (
  <figure className={className}>
    <div
      role="img"
      aria-label="Stylized preview of the LinkCascade dashboard showing click totals, a weekly bar chart, and a list of trackable links"
      className={cn(
        'overflow-hidden rounded-xl border-2 border-lc-graphite bg-white shadow-[10px_10px_0_0_#0B1318]',
        float && 'lc-float'
      )}
    >
      {/* Window chrome */}
      <div className="flex items-center gap-1.5 border-b-2 border-lc-graphite bg-lc-offwhite px-4 py-2.5">
        <span className="h-2.5 w-2.5 rounded-full bg-lc-coral" />
        <span className="h-2.5 w-2.5 rounded-full bg-lc-border" />
        <span className="h-2.5 w-2.5 rounded-full bg-lc-teal" />
        <span className="ml-3 hidden rounded border border-lc-border bg-white px-2 py-0.5 text-[10px] text-lc-slate sm:block">
          app.linkcascade.app/dashboard
        </span>
      </div>

      <div className="flex">
        {/* Mini sidebar */}
        <div className="hidden w-12 flex-col items-center gap-3 border-r-2 border-lc-graphite bg-lc-graphite py-4 sm:flex">
          <span className="h-5 w-5 rounded bg-lc-teal" />
          <span className="h-2 w-6 rounded-full bg-lc-offwhite/25" />
          <span className="h-2 w-6 rounded-full bg-lc-offwhite/25" />
          <span className="h-2 w-6 rounded-full bg-lc-offwhite/25" />
          <span className="h-2 w-6 rounded-full bg-lc-coral/80" />
        </div>

        <div className="flex-1 p-4 sm:p-5">
          {/* Stat row */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Clicks', value: '1,284' },
              { label: 'Leads', value: '96' },
              { label: 'Campaigns', value: '4' },
            ].map((stat) => (
              <div key={stat.label} className="rounded-md border border-lc-border bg-lc-offwhite p-2.5">
                <p className="text-[10px] font-semibold uppercase tracking-wider text-lc-slate">{stat.label}</p>
                <p className="mt-1 text-lg font-extrabold text-lc-graphite">{stat.value}</p>
              </div>
            ))}
          </div>

          {/* Chart */}
          <div className="mt-4 rounded-md border border-lc-border p-3">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-lc-slate">Clicks this week</p>
              <span className="h-2 w-2 rounded-full bg-lc-coral" aria-hidden="true" />
            </div>
            <div className="mt-3 flex h-20 items-end gap-1.5">
              {bars.map((height, i) => (
                <span
                  key={i}
                  style={{ height: `${height}%` }}
                  className={cn('flex-1 rounded-sm', i === 5 ? 'bg-lc-coral' : 'bg-lc-teal')}
                />
              ))}
            </div>
          </div>

          {/* Link rows */}
          <div className="mt-4 space-y-2">
            {[
              { slug: 'linkcascade.app/go/spring-launch', clicks: '412 clicks' },
              { slug: 'linkcascade.app/go/email-course', clicks: '238 clicks' },
            ].map((row) => (
              <div key={row.slug} className="flex items-center justify-between rounded-md border border-lc-border px-3 py-2">
                <span className="truncate text-xs font-medium text-lc-tealdark">{row.slug}</span>
                <span className="ml-3 shrink-0 text-xs font-semibold text-lc-graphite">{row.clicks}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
    <figcaption className="mt-4 flex items-center gap-3 text-xs text-lc-slate">
      <span className="h-0.5 w-8 bg-lc-graphite" aria-hidden="true" />
      {caption}
    </figcaption>
  </figure>
);

export default DashboardMockup;
