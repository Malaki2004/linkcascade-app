export const generateShortLink = (slug) => `app.linkcascade.app/go/${slug}`;

export const getShortLinkUrl = (slug) => `https://app.linkcascade.app/go/${slug}`;

export const getShortLinkPath = (slug) => `/go/${slug}`;