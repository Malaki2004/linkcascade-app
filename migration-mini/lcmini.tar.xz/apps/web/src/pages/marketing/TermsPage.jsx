import React from 'react';
import { Helmet } from 'react-helmet';
import Seo from '@/components/Seo';
import { SITE_URL, OG_IMAGE, SUPPORT_EMAIL } from '@/lib/brand';

const TITLE = 'Terms and Conditions | LinkCascade';
const DESCRIPTION =
  'The terms that govern your use of the LinkCascade website and link-tracking application, including accounts, plans, and acceptable use.';

const sections = [
  {
    title: 'The service',
    body: [
      'LinkCascade provides a link-tracking and campaign-organization platform that lets you create trackable links, organize them into campaigns, and review the activity those links produce. The features available to you depend on your plan.',
    ],
  },
  {
    title: 'Your account',
    body: [
      'You are responsible for keeping your account credentials confidential and for the activity that happens under your account. You must provide an accurate email address when you sign up.',
    ],
  },
  {
    title: 'Acceptable use',
    body: [
      'You agree not to use LinkCascade to share links to content that is unlawful, deceptive, harmful, or infringing, and not to use the service to spam, phish, or mislead the people who click your links. We may suspend accounts that violate these terms.',
    ],
  },
  {
    title: 'Plans and payments',
    body: [
      'Paid plans are billed through Stripe. You can manage or cancel a paid subscription from the billing settings inside the app. Plan prices and included limits are shown on the pricing page.',
    ],
  },
  {
    title: 'Your content and data',
    body: [
      'You retain ownership of the links, campaigns, templates, and records you create. You are responsible for the accuracy of information you record in your account, including earnings and attribution records.',
    ],
  },
  {
    title: 'Service availability',
    body: [
      'The service is provided "as is" and "as available." We work to keep LinkCascade reliable, but we do not guarantee uninterrupted availability or error-free operation.',
    ],
  },
  {
    title: 'Limitation of liability',
    body: [
      'To the maximum extent permitted by law, LinkCascade is not liable for indirect, incidental, or consequential damages arising from your use of the service, including lost profits or lost data.',
    ],
  },
  {
    title: 'Changes to these terms',
    body: [
      'If we update these Terms and Conditions, we will post the revised version on this page and update the date below. Continued use of the service after changes take effect constitutes acceptance of the revised terms.',
    ],
  },
  {
    title: 'Contact',
    body: [`Questions about these terms? Email us at ${SUPPORT_EMAIL}.`],
  },
];

const TermsPage = () => {
  return (
    <>
      <Helmet>
        <title>{TITLE}</title>
        <meta name="description" content={DESCRIPTION} />
      </Helmet>
      <Seo title={TITLE} description={DESCRIPTION} image={OG_IMAGE} url={`${SITE_URL}/terms`} />

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-4xl px-6 py-16">
          <p className="font-serif text-lg italic text-lc-tealdark">Legal</p>
          <h1 className="mt-3 text-4xl font-extrabold tracking-tight text-lc-graphite md:text-5xl">
            Terms and Conditions
          </h1>
          <p className="mt-4 text-sm text-lc-slate">Last updated: September 13, 2026</p>
          <p className="mt-6 max-w-2xl leading-relaxed text-lc-slate">
            These Terms and Conditions govern your use of the LinkCascade website and application. By using
            LinkCascade, you agree to them.
          </p>

          <div className="mt-12 space-y-10">
            {sections.map((section) => (
              <section key={section.title} className="border-t-2 border-lc-graphite pt-6">
                <h2 className="text-xl font-extrabold tracking-tight text-lc-graphite">{section.title}</h2>
                <div className="mt-4 space-y-3">
                  {section.body.map((paragraph, i) => (
                    <p key={i} className="text-sm leading-relaxed text-lc-slate">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </section>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default TermsPage;
