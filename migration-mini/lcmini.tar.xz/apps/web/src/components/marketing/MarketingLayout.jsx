import React, { useState } from 'react';
import { Link, NavLink, Outlet } from 'react-router-dom';
import { Link2, Menu, X } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { APP_SIGNUP_URL, SUPPORT_EMAIL } from '@/lib/brand';
import { cn } from '@/lib/utils';

const navItems = [
  { to: '/features', label: 'Features' },
  { to: '/how-it-works', label: 'How It Works' },
  { to: '/pricing', label: 'Pricing' },
  { to: '/earn-more', label: 'Earn More' },
  { to: '/faq', label: 'FAQ' },
  { to: '/contact', label: 'Contact' },
];

const ctaPrimary =
  'inline-flex items-center justify-center rounded-md bg-lc-teal px-5 py-2.5 text-sm font-semibold text-lc-graphite transition-colors hover:bg-lc-teal/85 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark active:scale-[0.98]';

const Logo = ({ light = false }) => (
  <span className="flex items-center gap-2">
    <span className="flex h-8 w-8 items-center justify-center rounded-md bg-lc-teal">
      <Link2 className="h-5 w-5 text-lc-graphite" aria-hidden="true" />
    </span>
    <span className={cn('text-xl font-extrabold tracking-tight', light ? 'text-lc-offwhite' : 'text-lc-graphite')}>
      LinkCascade
    </span>
  </span>
);

const MarketingLayout = () => {
  const { user } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="flex min-h-screen flex-col bg-lc-offwhite text-lc-graphite">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[60] focus:rounded-md focus:bg-lc-graphite focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-lc-offwhite"
      >
        Skip to content
      </a>

      <header className="sticky top-0 z-50 border-b-2 border-lc-graphite bg-lc-offwhite/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
          <Link to="/" aria-label="LinkCascade home" className="focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark">
            <Logo />
          </Link>

          <nav aria-label="Primary" className="hidden items-center gap-6 lg:flex">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  cn(
                    'text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark',
                    isActive ? 'text-lc-tealdark underline underline-offset-4' : 'text-lc-slate hover:text-lc-graphite'
                  )
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="hidden items-center gap-4 lg:flex">
            {user ? (
              <Link to="/dashboard" className={ctaPrimary}>
                Open Dashboard
              </Link>
            ) : (
              <>
                <Link
                  to="/login"
                  className="text-sm font-medium text-lc-tealdark hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark"
                >
                  Log in
                </Link>
                <a href={APP_SIGNUP_URL} className={ctaPrimary}>
                  Start Free
                </a>
              </>
            )}
          </div>

          <button
            type="button"
            className="inline-flex h-11 w-11 items-center justify-center rounded-md text-lc-graphite focus-visible:outline focus-visible:outline-2 focus-visible:outline-lc-tealdark lg:hidden"
            aria-expanded={menuOpen}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            onClick={() => setMenuOpen((open) => !open)}
          >
            {menuOpen ? <X className="h-6 w-6" aria-hidden="true" /> : <Menu className="h-6 w-6" aria-hidden="true" />}
          </button>
        </div>

        {menuOpen && (
          <nav aria-label="Mobile" className="border-t border-lc-border bg-lc-offwhite px-6 py-4 lg:hidden">
            <ul className="space-y-1">
              {navItems.map((item) => (
                <li key={item.to}>
                  <NavLink
                    to={item.to}
                    onClick={() => setMenuOpen(false)}
                    className={({ isActive }) =>
                      cn(
                        'block rounded-md px-3 py-3 text-base font-medium',
                        isActive ? 'bg-lc-teal/15 text-lc-tealdark' : 'text-lc-slate hover:bg-black/5'
                      )
                    }
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
              <li className="border-t border-lc-border pt-3">
                {user ? (
                  <Link to="/dashboard" onClick={() => setMenuOpen(false)} className={cn(ctaPrimary, 'w-full')}>
                    Open Dashboard
                  </Link>
                ) : (
                  <div className="flex flex-col gap-2">
                    <a href={APP_SIGNUP_URL} className={cn(ctaPrimary, 'w-full')}>
                      Start Free
                    </a>
                    <Link
                      to="/login"
                      onClick={() => setMenuOpen(false)}
                      className="inline-flex items-center justify-center rounded-md border-2 border-lc-graphite px-5 py-2.5 text-sm font-semibold text-lc-graphite"
                    >
                      Log in
                    </Link>
                  </div>
                )}
              </li>
            </ul>
          </nav>
        )}
      </header>

      <div id="main-content" className="flex-grow">
        <Outlet />
      </div>

      <footer className="border-t-2 border-lc-graphite bg-lc-graphite text-lc-offwhite">
        <div className="mx-auto max-w-6xl px-6 py-14">
          <div className="grid gap-10 md:grid-cols-4">
            <div>
              <Link to="/" aria-label="LinkCascade home">
                <Logo light />
              </Link>
              <p className="mt-4 max-w-xs text-sm text-lc-offwhite/70">
                Easy link tracking and campaign organization for creators, affiliates, consultants, agencies, and small businesses.
              </p>
              <p className="mt-4 text-sm">
                <a href={`mailto:${SUPPORT_EMAIL}`} className="text-lc-teal underline-offset-4 hover:underline">
                  {SUPPORT_EMAIL}
                </a>
              </p>
            </div>

            <nav aria-label="Product">
              <h2 className="text-xs font-semibold uppercase tracking-widest text-lc-offwhite/60">Product</h2>
              <ul className="mt-4 space-y-2 text-sm">
                <li><Link className="text-lc-offwhite/80 hover:text-lc-teal" to="/features">Features</Link></li>
                <li><Link className="text-lc-offwhite/80 hover:text-lc-teal" to="/how-it-works">How It Works</Link></li>
                <li><Link className="text-lc-offwhite/80 hover:text-lc-teal" to="/pricing">Pricing</Link></li>
                <li><Link className="text-lc-offwhite/80 hover:text-lc-teal" to="/earn-more">Earn More</Link></li>
              </ul>
            </nav>

            <nav aria-label="Company">
              <h2 className="text-xs font-semibold uppercase tracking-widest text-lc-offwhite/60">Company</h2>
              <ul className="mt-4 space-y-2 text-sm">
                <li><Link className="text-lc-offwhite/80 hover:text-lc-teal" to="/early-access">Early Access</Link></li>
                <li><Link className="text-lc-offwhite/80 hover:text-lc-teal" to="/contact">Contact</Link></li>
                <li><Link className="text-lc-offwhite/80 hover:text-lc-teal" to="/faq">FAQ</Link></li>
              </ul>
            </nav>

            <nav aria-label="Legal">
              <h2 className="text-xs font-semibold uppercase tracking-widest text-lc-offwhite/60">Legal</h2>
              <ul className="mt-4 space-y-2 text-sm">
                <li><Link className="text-lc-offwhite/80 hover:text-lc-teal" to="/privacy">Privacy Policy</Link></li>
                <li><Link className="text-lc-offwhite/80 hover:text-lc-teal" to="/terms">Terms and Conditions</Link></li>
              </ul>
            </nav>
          </div>

          <div className="mt-12 flex flex-col gap-2 border-t border-lc-offwhite/15 pt-6 text-sm text-lc-offwhite/60 md:flex-row md:items-center md:justify-between">
            <p>© 2026 LinkCascade. All rights reserved.</p>
            <p>
              Questions? <a href={`mailto:${SUPPORT_EMAIL}`} className="text-lc-teal underline-offset-4 hover:underline">{SUPPORT_EMAIL}</a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default MarketingLayout;
