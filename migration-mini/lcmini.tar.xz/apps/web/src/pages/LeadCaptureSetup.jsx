import React, { useState, useEffect } from 'react';
import { Copy, CheckCircle, Key, RefreshCw, Send, AlertTriangle, Lock, Loader2, Sparkles, Code } from 'lucide-react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const LeadCaptureSetup = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [copiedStates, setCopiedStates] = useState({
    endpoint: false,
    payload: false,
    js: false,
    rawKey: false
  });

  const [keyRecord, setKeyRecord] = useState(null);
  const [showRawKey, setShowRawKey] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generatingKey, setGeneratingKey] = useState(false);
  const [testingLead, setTestingLead] = useState(false);
  const [testMessage, setTestMessage] = useState(null);

  const [userPlan, setUserPlan] = useState('free');
  const [planLoading, setPlanLoading] = useState(true);

  const endpointUrl = "https://nummuwbshryqcmdftygs.supabase.co/functions/v1/lead-capture";

  useEffect(() => {
    const fetchPlan = async () => {
      if (!user) {
        setPlanLoading(false);
        setLoading(false);
        return;
      }
      try {
        const { data, error } = await supabase
          .from('profiles')
          .select('plan')
          .eq('id', user.id)
          .single();
        if (error) throw error;
        setUserPlan(data?.plan || 'free');
      } catch (err) {
        console.error('Error fetching plan:', err);
        setUserPlan('free');
      } finally {
        setPlanLoading(false);
      }
    };
    fetchPlan();
  }, [user]);

  const hasProAccess = userPlan === 'pro' || userPlan === 'agency';

  useEffect(() => {
    if (user && !planLoading) {
      if (hasProAccess) {
        fetchActiveKey();
      } else {
        setLoading(false);
      }
    }
  }, [user, planLoading, hasProAccess]);

  const fetchActiveKey = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('lead_capture_keys')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .maybeSingle();
      
      if (error) {
        console.error('Error fetching key:', error);
      } else {
        setKeyRecord(data);
      }
    } catch (error) {
      console.error('Error fetching key:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (key, text) => {
    navigator.clipboard.writeText(text);
    setCopiedStates((prev) => ({ ...prev, [key]: true }));
    setTimeout(() => {
      setCopiedStates((prev) => ({ ...prev, [key]: false }));
    }, 2000);
  };

  const handleGenerateKey = async () => {
    setGeneratingKey(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-api-key', {
        method: 'POST'
      });
      
      if (error) throw error;
      if (!data || !data.keyRecord) throw new Error("Invalid response from server");
      
      setKeyRecord(data.keyRecord);
      setShowRawKey(data.rawKey);
      toast({
        title: "API Key Generated",
        description: "Please copy your new API key now. It will not be shown again.",
      });
    } catch (error) {
      toast({
        title: "Error Generating Key",
        description: error.message || "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setGeneratingKey(false);
    }
  };

  const handleRegenerateKey = async () => {
    if (!window.confirm("Are you sure? This will invalidate your existing API key immediately.")) return;
    
    setGeneratingKey(true);
    try {
      const { data, error } = await supabase.functions.invoke('regenerate-api-key', {
        method: 'POST',
        body: { keyId: keyRecord.id }
      });
      
      if (error) throw error;
      if (!data || !data.keyRecord) throw new Error("Invalid response from server");
      
      setKeyRecord(data.keyRecord);
      setShowRawKey(data.rawKey);
      setTestMessage(null);
      toast({
        title: "API Key Regenerated",
        description: "Your old key has been revoked. Update your integrations with the new key.",
      });
    } catch (error) {
      toast({
        title: "Error Regenerating Key",
        description: error.message || "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setGeneratingKey(false);
    }
  };

  const handleSendTestLead = async () => {
    setTestingLead(true);
    setTestMessage(null);
    try {
      const { data, error } = await supabase.functions.invoke('send-test-lead', {
        method: 'POST'
      });

      if (error) throw error;
      if (!data?.success) throw new Error(data?.error || 'Failed to send test lead');
      
      setTestMessage({ type: 'success', text: 'Test lead sent successfully!' });
      toast({
        title: "Test Lead Sent!",
        description: "The lead has been captured successfully.",
      });
    } catch (error) {
      setTestMessage({ type: 'error', text: error.message });
      toast({
        title: "Test Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setTestingLead(false);
    }
  };

  const samplePayload = `{
  "name": "Jane Smith",
  "email": "jane@example.com",
  "phone": "+1-555-1234",
  "form_name": "Contact Form",
  "source_channel": "Instagram Bio"
}`;

  const jsExample = `fetch("${endpointUrl}", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "x-linkcascade-key": "YOUR_API_KEY"
  },
  body: JSON.stringify({
    name: "Jane Smith",
    email: "jane@example.com",
    phone: "+1-555-1234",
    "form_name": "Contact Form",
    "source_channel": "Instagram Bio"
  })
})
  .then(response => response.json())
  .then(data => console.log("Lead captured:", data))
  .catch(error => console.error("Error:", error));`;

  if (planLoading) {
    return (
      <div className="p-6 md:p-8 max-w-7xl mx-auto min-h-[80vh] flex flex-col items-center justify-center">
        <Loader2 className="w-10 h-10 text-lc-tealdark animate-spin mb-4" />
        <p className="text-gray-500">Checking your plan...</p>
      </div>
    );
  }

  if (!hasProAccess) {
    return (
      <div className="p-6 md:p-8 max-w-7xl mx-auto min-h-[80vh] flex flex-col items-center justify-center">
        <Helmet>
          <title>Lead Capture Setup - LinkCascade</title>
        </Helmet>
        <div className="bg-lc-teal/10 border border-lc-border rounded-2xl p-8 max-w-md w-full text-center shadow-sm">
          <div className="w-16 h-16 bg-lc-teal/15 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lock className="w-8 h-8 text-lc-tealdark" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Pro Feature</h2>
          <p className="text-gray-600 mb-6">
            Lead Capture Setup is only available on Pro and Agency plans. Upgrade your account to unlock this feature.
          </p>
          <Button 
            onClick={() => navigate('/settings?tab=billing')}
            className="w-full bg-lc-teal hover:bg-lc-tealdark text-lc-graphite"
          >
            Upgrade to Pro
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Lead Capture Setup - LinkCascade</title>
      </Helmet>

      <div className="bg-gray-50 min-h-screen py-12 px-4">
        <div className="max-w-4xl mx-auto">
          
          <div className="mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Lead Capture Setup</h1>
            <p className="text-lg text-gray-600 mb-2">
              Discover how to funnel valuable lead information directly into LinkCascade and tie it back to your campaigns.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-8 mb-8 border border-blue-100">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Two Ways to Capture Leads</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                <div className="w-12 h-12 bg-lc-teal text-lc-graphite rounded-lg flex items-center justify-center mb-4">
                  <Sparkles className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-blue-900 mb-2">Option A: Built-in Form <span className="bg-blue-200 text-blue-800 text-xs px-2 py-1 rounded ml-2 uppercase font-semibold">Recommended</span></h3>
                <p className="text-blue-800 mb-4 text-sm">
                  The easiest way to start capturing leads. No coding or setup required. LinkCascade hosts a fast, mobile-friendly capture page.
                </p>
                <ul className="space-y-2 text-sm text-blue-800 font-medium list-disc pl-5">
                  <li>Automatic setup and routing</li>
                  <li>Zero coding required</li>
                  <li>Enable per-link in Link Vault</li>
                </ul>
              </div>

              <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
                <div className="w-12 h-12 bg-gray-800 text-white rounded-lg flex items-center justify-center mb-4">
                  <Code className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Option B: External API <span className="bg-gray-200 text-gray-700 text-xs px-2 py-1 rounded ml-2 uppercase font-semibold">Advanced</span></h3>
                <p className="text-gray-600 mb-4 text-sm">
                  Send leads directly from your own website forms, funnels, or CRMs using our secure API endpoint.
                </p>
                <ul className="space-y-2 text-sm text-gray-700 font-medium list-disc pl-5">
                  <li>Full design control</li>
                  <li>Custom form fields integration</li>
                  <li>Requires backend API key setup</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">API Documentation (For Option B)</h2>
            <p className="text-gray-600 mb-6">Use the details below to integrate your custom forms with LinkCascade.</p>
            
            <h3 className="text-lg font-bold text-gray-900 mb-2">Endpoint URL</h3>
            <div className="relative mb-8">
              <pre className="bg-gray-900 text-gray-100 font-mono p-4 rounded-lg overflow-x-auto">
                {endpointUrl}
              </pre>
              <button
                onClick={() => handleCopy('endpoint', endpointUrl)}
                className="absolute top-2 right-2 bg-lc-teal text-lc-graphite hover:bg-lc-tealdark transition-colors px-3 py-1.5 rounded flex items-center gap-2 text-sm font-medium"
              >
                {copiedStates.endpoint ? <><CheckCircle className="w-4 h-4" />Copied!</> : <><Copy className="w-4 h-4" />Copy</>}
              </button>
            </div>

            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Key className="w-5 h-5 text-lc-tealdark" />
              API Key Management
            </h3>

            {loading ? (
              <div className="text-gray-500 mb-8">Loading your API key...</div>
            ) : !keyRecord ? (
              <div className="bg-gray-50 p-6 rounded-lg border border-gray-200 text-center mb-8">
                <p className="text-gray-600 mb-4">You do not have an active API key.</p>
                <Button 
                  onClick={handleGenerateKey} 
                  disabled={generatingKey}
                  className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite"
                >
                  {generatingKey ? "Generating..." : "Generate API Key"}
                </Button>
              </div>
            ) : (
              <div className="space-y-6 mb-8">
                <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-700">Active Key Prefix</span>
                    <span className="text-xs text-green-600 bg-green-100 px-2 py-1 rounded-full font-medium">Active</span>
                  </div>
                  <div className="font-mono text-xl text-gray-900">
                    {keyRecord.key_prefix}••••••••••••••••••••••••
                  </div>
                  <div className="mt-4 flex gap-3 flex-wrap">
                    <Button 
                      variant="outline" 
                      onClick={handleRegenerateKey}
                      disabled={generatingKey}
                      className="flex gap-2"
                    >
                      <RefreshCw className="w-4 h-4" />
                      {generatingKey ? "Regenerating..." : "Regenerate Key"}
                    </Button>
                    <Button 
                      onClick={handleSendTestLead}
                      disabled={!keyRecord || testingLead}
                      className="bg-lc-teal hover:bg-lc-tealdark text-lc-graphite flex gap-2"
                    >
                      <Send className="w-4 h-4" />
                      {testingLead ? "Sending..." : "Send Test Lead"}
                    </Button>
                  </div>
                  {testMessage && (
                    <div className={`mt-4 p-3 rounded text-sm ${testMessage.type === 'error' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-green-50 text-green-700 border border-green-200'}`}>
                      {testMessage.text}
                    </div>
                  )}
                </div>

                {showRawKey && (
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="w-6 h-6 text-yellow-600 flex-shrink-0" />
                      <div className="flex-1">
                        <h3 className="text-yellow-800 font-bold mb-2">Save your API Key</h3>
                        <p className="text-yellow-700 text-sm mb-4">
                          This is the only time your full API key will be shown. Please copy it and store it somewhere safe.
                        </p>
                        <div className="relative">
                          <input
                            type="text"
                            readOnly
                            value={showRawKey}
                            className="w-full bg-white border border-yellow-300 text-gray-900 px-4 py-2 rounded font-mono text-sm pr-24"
                          />
                          <button
                            onClick={() => handleCopy('rawKey', showRawKey)}
                            className="absolute top-1 right-1 bg-yellow-600 text-white hover:bg-yellow-700 transition-colors px-3 py-1 rounded flex items-center gap-1 text-xs font-medium"
                          >
                            {copiedStates.rawKey ? <><CheckCircle className="w-3 h-3" />Copied!</> : <><Copy className="w-3 h-3" />Copy</>}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            <h3 className="text-lg font-bold text-gray-900 mb-4">Field Reference</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-3 border-b pb-2 uppercase tracking-wider">Required</h4>
                <ul className="space-y-4">
                  <li><span className="text-lc-tealdark font-mono font-medium block text-sm">name (string)</span><span className="text-gray-600 text-sm">Lead's full name</span></li>
                  <li><span className="text-lc-tealdark font-mono font-medium block text-sm">email (string)</span><span className="text-gray-600 text-sm">Lead's email address</span></li>
                </ul>
              </div>
              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-3 border-b pb-2 uppercase tracking-wider">Optional</h4>
                <ul className="space-y-4">
                  <li><span className="text-gray-600 font-mono font-medium block text-sm">phone (string)</span><span className="text-gray-600 text-sm">Lead's phone number</span></li>
                  <li><span className="text-gray-600 font-mono font-medium block text-sm">form_name (string)</span><span className="text-gray-600 text-sm">Name of the form submitted</span></li>
                  <li><span className="text-gray-600 font-mono font-medium block text-sm">source_channel (string)</span><span className="text-gray-600 text-sm">Where the lead came from</span></li>
                  <li><span className="text-gray-600 font-mono font-medium block text-sm">click_id (string)</span><span className="text-gray-600 text-sm">Unique click identifier</span></li>
                  <li><span className="text-gray-600 font-mono font-medium block text-sm">link_id (UUID)</span><span className="text-gray-600 text-sm">LinkCascade link ID</span></li>
                  <li><span className="text-gray-600 font-mono font-medium block text-sm">campaign_id (UUID)</span><span className="text-gray-600 text-sm">LinkCascade campaign ID</span></li>
                </ul>
              </div>
            </div>

            <h3 className="text-lg font-bold text-gray-900 mb-3">Sample Payload</h3>
            <div className="relative mb-8">
              <pre className="bg-gray-900 text-gray-100 font-mono p-4 rounded-lg overflow-x-auto whitespace-pre text-sm">
                {samplePayload}
              </pre>
              <button
                onClick={() => handleCopy('payload', samplePayload)}
                className="absolute top-2 right-2 bg-lc-teal text-lc-graphite hover:bg-lc-tealdark transition-colors px-3 py-1.5 rounded flex items-center gap-2 text-xs font-medium"
              >
                {copiedStates.payload ? <><CheckCircle className="w-3 h-3" />Copied!</> : <><Copy className="w-3 h-3" />Copy</>}
              </button>
            </div>

            <h3 className="text-lg font-bold text-gray-900 mb-3">JavaScript Example</h3>
            <div className="relative mb-8">
              <pre className="bg-gray-900 text-gray-100 font-mono p-4 rounded-lg overflow-x-auto whitespace-pre text-sm">
                {jsExample}
              </pre>
              <button
                onClick={() => handleCopy('js', jsExample)}
                className="absolute top-2 right-2 bg-lc-teal text-lc-graphite hover:bg-lc-tealdark transition-colors px-3 py-1.5 rounded flex items-center gap-2 text-xs font-medium"
              >
                {copiedStates.js ? <><CheckCircle className="w-3 h-3" />Copied!</> : <><Copy className="w-3 h-3" />Copy</>}
              </button>
            </div>

          </div>

        </div>
      </div>
    </>
  );
};

export default LeadCaptureSetup;