import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Seo from '@/components/Seo';
import { SITE_URL, APP_SIGNUP_URL, OG_IMAGE, SUPPORT_EMAIL } from '@/lib/brand';

const TITLE = 'Frequently Asked Questions | LinkCascade';
const DESCRIPTION =
  'Answers to common questions about LinkCascade: how link tracking works, plans and pricing, lead capture, data export, and support.';

const faqs = [
  {
    question: 'What is LinkCascade?',
    answer:
      'LinkCascade is an easy link-tracking and campaign-organization platform. It helps creators, affiliates, consultants, agencies, and small businesses understand which shared links produce clicks, leads, and attributable results.',
  },
  {
    question: 'Who is LinkCascade for?',
    answer:
      'LinkCascade is built for people who share links for a business reason: creators sharing content and offers, affiliates promoting products, consultants and agencies sharing links for clients, and small businesses tracking which channels produce results.',
  },
  {
    question: 'How does link tracking work?',
    answer:
      'You paste a destination URL into the Link Vault and LinkCascade gives you a short, trackable link. When someone opens that short link, the click is recorded automatically before the visitor is sent to your destination. You can review clicks per link and per campaign in your dashboard.',
  },
  {
    question: 'Does LinkCascade automatically verify my affiliate commissions or sales?',
    answer:
      'No. Clicks and leads captured through LinkCascade lead forms are recorded automatically. Sales and earnings figures come from what you record in your account or capture through supported methods—LinkCascade does not automatically verify commissions or sales that happen on external platforms.',
  },
  {
    question: 'What plans are available?',
    answer:
      'There are three plans: Free ($0/month) with 5 trackable links and 2 campaigns, Pro ($27/month) with 50 links, 10 campaigns, advanced analytics, and lead attribution, and Agency ($97/month) with unlimited links and campaigns. See the pricing page for full details.',
  },
  {
    question: 'Can I capture leads with my links?',
    answer:
      'Yes, on Pro and Agency plans. You can attach a lead-capture form to a tracked link, and LinkCascade records the people who respond so you can connect them to the link that brought them in.',
  },
  {
    question: 'Can I export my data?',
    answer:
      'Pro and Agency plans include CSV export of your earnings records, so you can use the data in your own reporting or bookkeeping.',
  },
  {
    question: 'How do I contact support?',
    answer: `You can email ${SUPPORT_EMAIL} or use the contact form on the Contact page. If you have an account, the support widget inside the app reaches the same team.`,
  },
];

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: faqs.map((faq) => ({
    '@type': 'Question',
    name: faq.question,
    acceptedAnswer: { '@type': 'Answer', text: faq.answer },
  })),
};

const ctaPrimary =
  'inline-flex items-center justify-center rounded-md bg-lc-teal px-6 py-3 text-base font-semibold text-lc-graphite transition-colors hover:bg-lc-teal/85 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lc-tealdark active:scale-[0.98]';

const FaqPage = () => {
  return (
    <>
      <Helmet>
        <title>{TITLE}</title>
        <meta name="description" content={DESCRIPTION} />
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      </Helmet>
      <Seo title={TITLE} description={DESCRIPTION} image={OG_IMAGE} url={`${SITE_URL}/faq`} />

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <p className="font-serif text-lg italic text-lc-tealdark">FAQ</p>
          <h1 className="mt-3 max-w-3xl text-4xl font-extrabold tracking-tight text-lc-graphite md:text-5xl">
            Frequently asked questions
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-lc-slate">
            Straight answers about what LinkCascade does, how tracking works, and what each plan includes.
          </p>
        </div>
      </section>

      <section className="border-b-2 border-lc-graphite">
        <div className="mx-auto max-w-4xl px-6 py-16">
          <div className="space-y-4">
            {faqs.map((faq) => (
              <details
                key={faq.question}
                className="group rounded-xl border-2 border-lc-graphite bg-white shadow-[4px_4px_0_0_#0B1318]"
              >
                <summary className="cursor-pointer list-none px-6 py-5 text-base font-bold text-lc-graphite focus-visible:outline focus-visible:outline-2 focus-visible:outline-lc-tealdark [&::-webkit-details-marker]:hidden">
                  <span className="flex items-center justify-between gap-4">
                    {faq.question}
                    <span className="font-serif text-xl italic text-lc-tealdark transition-transform group-open:rotate-45" aria-hidden="true">
                      +
                    </span>
                  </span>
                </summary>
                <p className="border-t border-lc-border px-6 py-5 text-sm leading-relaxed text-lc-slate">
                  {faq.answer}
                </p>
              </details>
            ))}
          </div>

          <div className="mt-12 flex flex-wrap items-center gap-4">
            <a href={APP_SIGNUP_URL} className={ctaPrimary}>
              Start Free
            </a>
            <Link
              to="/contact"
              className="font-semibold text-lc-tealdark underline-offset-4 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-lc-tealdark"
            >
              Still have a question? Contact us
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default FaqPage;
