import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { Helmet } from 'react-helmet';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Loader2, ArrowRight, ShieldCheck, Link2 } from 'lucide-react';
import { motion } from 'framer-motion';

const LeadCapturePage = () => {
  const { linkId } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [linkData, setLinkData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  
  const clickId = searchParams.get('lc_click_id');
  const campaignId = searchParams.get('lc_campaign_id');

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: ''
  });

  useEffect(() => {
    const fetchLinkData = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('links')
          .select('id, title, original_url, campaign_id, user_id, enable_lead_capture')
          .eq('id', linkId)
          .single();

        if (error || !data) throw new Error('Link not found');

        const { data: profile } = await supabase
          .from('profiles')
          .select('plan')
          .eq('id', data.user_id)
          .single();

        const plan = profile?.plan || 'free';
        if (plan !== 'pro' && plan !== 'agency') {
          navigate('/pricing', { replace: true });
          return;
        }

        setLinkData(data);
      } catch (err) {
        toast({ title: 'Error', description: err.message, variant: 'destructive' });
      } finally {
        setLoading(false);
      }
    };

    if (linkId) {
      fetchLinkData();
    }
  }, [linkId, navigate, toast]);

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const proceedToDestination = () => {
    if (!linkData) return;
    const destUrl = new URL(linkData.original_url);
    destUrl.searchParams.set('lc_link_id', linkData.id);
    if (clickId) destUrl.searchParams.set('lc_click_id', clickId);
    if (campaignId || linkData.campaign_id) destUrl.searchParams.set('lc_campaign_id', campaignId || linkData.campaign_id);
    
    window.location.replace(destUrl.toString());
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email) return;

    setSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke('lead-capture', {
        body: {
          lead_name: formData.name,
          lead_email: formData.email,
          lead_phone: formData.phone,
          link_id: linkId,
          click_id: clickId,
          campaign_id: campaignId || linkData.campaign_id,
          form_name: linkData.title || 'Built-in Capture Form',
          source_channel: 'LinkCascade Built-in Form'
        }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast({ title: 'Success!', description: 'Taking you to the link...' });
      
      setTimeout(() => {
        proceedToDestination();
      }, 1000);

    } catch (err) {
      toast({ title: 'Submission Failed', description: err.message || 'Please try again', variant: 'destructive' });
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-lc-offwhite flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-lc-tealdark animate-spin" />
      </div>
    );
  }

  if (!linkData) {
    return (
      <div className="min-h-screen bg-lc-offwhite flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-xl shadow-lg max-w-md w-full text-center">
          <ShieldCheck className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Link Not Found</h2>
          <p className="text-gray-500">The link you're trying to access doesn't exist or is unavailable.</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{linkData.title || 'Lead Capture'} - LinkCascade</title>
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>
      
      <div className="min-h-screen bg-lc-offwhite flex flex-col items-center justify-center p-4 sm:p-8">
        
        <div className="w-full max-w-md">
          <div className="flex justify-center mb-8">
            <div className="w-12 h-12 bg-lc-teal rounded-xl flex items-center justify-center shadow-lg">
              <Link2 className="w-6 h-6 text-lc-graphite" />
            </div>
          </div>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-xl border border-lc-border overflow-hidden"
          >
            <div className="px-8 pt-8 pb-6 text-center border-b border-gray-100 bg-gray-50/50">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">
                {linkData.title || 'Get Started'}
              </h1>
              <p className="text-gray-500 text-sm">
                Please provide your details to continue to the destination.
              </p>
            </div>

            <div className="p-8">
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    required
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 text-gray-900 rounded-lg focus:ring-2 focus:ring-lc-teal focus:border-transparent outline-none transition-all"
                    placeholder="John Doe"
                    disabled={submitting}
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Email Address <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 text-gray-900 rounded-lg focus:ring-2 focus:ring-lc-teal focus:border-transparent outline-none transition-all"
                    placeholder="john@example.com"
                    disabled={submitting}
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-1.5">
                    Phone Number <span className="text-gray-400 font-normal">(Optional)</span>
                  </label>
                  <input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 text-gray-900 rounded-lg focus:ring-2 focus:ring-lc-teal focus:border-transparent outline-none transition-all"
                    placeholder="+1 (555) 000-0000"
                    disabled={submitting}
                  />
                </div>

                <div className="pt-2">
                  <Button 
                    type="submit" 
                    disabled={submitting}
                    className="w-full h-12 text-base font-bold bg-lc-teal hover:bg-lc-tealdark text-lc-graphite shadow-md shadow-lc-teal/20 transition-all"
                  >
                    {submitting ? (
                      <span className="flex items-center gap-2">
                        <Loader2 className="w-5 h-5 animate-spin" /> Processing...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        Continue to Link <ArrowRight className="w-5 h-5" />
                      </span>
                    )}
                  </Button>
                </div>
              </form>

              <div className="mt-6 text-center">
                <button 
                  type="button"
                  onClick={proceedToDestination}
                  className="text-xs text-gray-400 hover:text-gray-600 underline underline-offset-2 transition-colors"
                >
                  Skip and continue to destination
                </button>
              </div>
            </div>
          </motion.div>
          
          <div className="text-center mt-8">
            <span className="text-sm font-medium text-gray-400 flex items-center justify-center gap-1.5">
              Powered by <Link2 className="w-4 h-4 text-lc-teal" /> LinkCascade
            </span>
          </div>
        </div>
      </div>
    </>
  );
};

export default LeadCapturePage;