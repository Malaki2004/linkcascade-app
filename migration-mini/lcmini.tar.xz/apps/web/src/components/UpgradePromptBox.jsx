import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';

const UpgradePromptBox = () => {
  const [userPlan, setUserPlan] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserPlan = async () => {
      try {
        const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError) {
          console.error('Session error:', sessionError);
          setLoading(false);
          return;
        }

        const session = sessionData?.session;
        
        if (session?.user) {
          console.log('User ID:', session.user.id);
          // Querying the 'profiles' table as requested
          const { data, error } = await supabase
            .from('profiles')
            .select('plan')
            .eq('id', session.user.id)
            .single();

          if (error) {
            console.error('Query error fetching user plan:', error);
          } else if (data) {
            const plan = data.plan ? data.plan.toLowerCase() : 'free';
            console.log('Plan value:', plan);
            setUserPlan(plan);
          }
        } else {
          console.log('No active user session.');
        }
      } catch (error) {
        console.error('Unexpected error fetching user plan:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserPlan();
  }, []);

  if (loading || userPlan !== 'free') {
    return null;
  }

  return (
    <div className="bg-white border border-[#7634BF]/30 shadow-sm rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 w-full">
      <div className="flex-1">
        <p className="text-gray-800 text-sm sm:text-base font-medium">
          Unlock advanced analytics, unlimited campaigns, and CSV exports with Pro.
        </p>
      </div>
      <div className="flex-shrink-0 self-end sm:self-auto mt-2 sm:mt-0">
        <button
          onClick={() => navigate('/upgrade')}
          className="bg-[#7634BF] hover:bg-[#5a2792] text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-colors w-full sm:w-auto"
        >
          Upgrade to Pro
        </button>
      </div>
    </div>
  );
};

export default UpgradePromptBox;