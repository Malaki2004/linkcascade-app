const CACHE_BUST = new Date().getTime(); // Force fresh load

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import '@/index.css';

// Force HMR / Rebuild trigger: 2026-03-28

const lcStripeCapture = (e) => {
  const x = e.clientX;
  const y = e.clientY;
  const els = document.elementsFromPoint(x, y) || [];
  for (const el of els) {
    const target = el?.closest?.("[data-stripe-link]");
    const url = target?.getAttribute?.("data-stripe-link");
    if (url) {
      e.preventDefault();
      e.stopPropagation();
      window.location.assign(url);
      return;
    }
  }
};

document.addEventListener("pointerdown", lcStripeCapture, true);

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
);