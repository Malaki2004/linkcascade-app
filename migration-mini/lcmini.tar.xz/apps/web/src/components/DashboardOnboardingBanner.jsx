import React, { useState } from 'react';
import { ArrowRight, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const DashboardOnboardingBanner = () => {
  const [isVisible, setIsVisible] = useState(true);
  const navigate = useNavigate();

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, height: 0, marginBottom: 0, overflow: 'hidden' }}
          className="bg-[#7634BF]/10 border border-[#7634BF]/20 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative w-full shadow-sm"
        >
          <div className="flex-1 pr-8 sm:pr-0">
            <p className="text-sm sm:text-base font-medium text-gray-800">
              Start by creating your first link to begin tracking what makes you money.
            </p>
          </div>
          
          <div className="flex items-center gap-4 mt-2 sm:mt-0 self-end sm:self-auto">
            <button
              onClick={() => navigate('/links')}
              className="flex items-center gap-1.5 text-sm font-bold text-[#7634BF] hover:text-[#5a2792] transition-colors group"
            >
              Create Link
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <button
            onClick={() => setIsVisible(false)}
            className="absolute top-3 right-3 sm:top-auto sm:relative sm:right-auto p-1.5 text-[#7634BF]/60 hover:text-[#7634BF] hover:bg-[#7634BF]/10 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#7634BF]/30"
            aria-label="Dismiss onboarding banner"
          >
            <X className="w-4 h-4" />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default DashboardOnboardingBanner;