import React from 'react';
import { motion } from 'framer-motion';
import { User, CreditCard, Shield, Check } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Helmet } from 'react-helmet';
import { PRO_PAYMENT_LINK, AGENCY_PAYMENT_LINK } from '@/lib/constants';

const Settings = () => {
  const { user, userProfile, signOut } = useAuth();
  const currentPlan = userProfile?.plan || 'free';
  const plans = { free: { name: 'Free', price: '$0' }, pro: { name: 'Pro', price: '$27/mo', link: PRO_PAYMENT_LINK }, agency: { name: 'Agency', price: '$97/mo', link: AGENCY_PAYMENT_LINK } };
  
  return (
    <>
      <Helmet><title>Settings - LinkCascade</title></Helmet>
      <div className="p-6 md:p-8 max-w-5xl mx-auto min-h-screen">
        <h1 className="text-3xl font-bold text-gray-900 mb-8 tracking-tight">Settings</h1>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
           <div className="md:col-span-3 space-y-1">
              <button className="w-full text-left px-4 py-2 bg-purple-50 text-purple-700 font-bold rounded-lg text-sm">Account</button>
              <button className="w-full text-left px-4 py-2 text-gray-600 hover:bg-gray-50 font-medium rounded-lg text-sm">Billing</button>
              <button className="w-full text-left px-4 py-2 text-gray-600 hover:bg-gray-50 font-medium rounded-lg text-sm">Security</button>
           </div>

           <div className="md:col-span-9 space-y-8">
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl border border-gray-200 shadow-sm p-8">
                 <div className="flex items-center gap-3 mb-6 pb-6 border-b border-gray-100">
                    <div className="p-2 bg-gray-100 rounded-lg"><User className="w-5 h-5 text-gray-600" /></div>
                    <h2 className="text-lg font-bold text-gray-900">Personal Information</h2>
                 </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                       <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Email Address</label>
                       <div className="text-sm font-medium text-gray-900 bg-gray-50 px-3 py-2 rounded-lg border border-gray-200">{user?.email}</div>
                    </div>
                    <div>
                       <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Plan ID</label>
                       <div className="text-sm font-medium text-gray-900 bg-gray-50 px-3 py-2 rounded-lg border border-gray-200">{user?.id}</div>
                    </div>
                 </div>
              </motion.div>

              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-xl border border-gray-200 shadow-sm p-8">
                 <div className="flex items-center gap-3 mb-6 pb-6 border-b border-gray-100">
                    <div className="p-2 bg-purple-100 rounded-lg"><CreditCard className="w-5 h-5 text-purple-600" /></div>
                    <h2 className="text-lg font-bold text-gray-900">Current Plan</h2>
                 </div>
                 
                 <div className="bg-purple-50/50 rounded-xl border border-purple-100 p-6 flex items-center justify-between">
                    <div>
                       <h3 className="text-xl font-bold text-gray-900 capitalize">{plans[currentPlan].name} Plan</h3>
                       <p className="text-purple-600 font-bold mt-1">{plans[currentPlan].price}</p>
                    </div>
                    <div className="flex items-center gap-2 text-sm font-bold text-green-600 bg-white px-3 py-1.5 rounded-full border border-green-100 shadow-sm">
                       <Check className="w-4 h-4" /> Active
                    </div>
                 </div>

                 {currentPlan === 'free' && (
                    <div className="mt-6 flex justify-end">
                       <Button onClick={() => window.location.href = PRO_PAYMENT_LINK} className="bg-purple-600 hover:bg-purple-700">Upgrade to Pro</Button>
                    </div>
                 )}
              </motion.div>

              <div className="flex justify-end pt-8">
                 <Button variant="destructive" onClick={signOut}>Sign Out</Button>
              </div>
           </div>
        </div>
      </div>
    </>
  );
};

export default Settings;