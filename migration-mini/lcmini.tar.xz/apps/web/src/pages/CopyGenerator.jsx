import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Copy, MessageSquare, Settings2, Target, Link2, Smartphone, Share2, Briefcase, Check, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useNavigate } from 'react-router-dom';

const CopyGenerator = () => {
  const { toast } = useToast();
  const { userProfile } = useAuth();
  const navigate = useNavigate();
  
  const [topic, setTopic] = useState('');
  const [shortLink, setShortLink] = useState('');
  const [loading, setLoading] = useState(false);
  const [outputs, setOutputs] = useState({
    shortDM: '',
    socialPost: '',
    professional: ''
  });

  const isPro = userProfile?.plan === 'pro' || userProfile?.plan === 'agency';

  // Mock AI generation function
  const generateWithAI = async (prompt) => {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Simple heuristic to determine which template to use based on the prompt content
    // In a real app, this would call an OpenAI wrapper Edge Function
    let generatedText = "";
    const linkText = shortLink ? shortLink : "[Link]";
    
    if (prompt.includes("short, conversational")) {
      // Short DM Logic
      generatedText = `Hey! 👋 Thought you'd be interested in ${topic}. Check it out here: ${linkText}`;
    } else if (prompt.includes("engaging social media post")) {
      // Social Post Logic
      generatedText = `🚀 Exciting news! ${topic} is finally here.\n\nIt’s a total game-changer. Don't miss out on this opportunity!\n\n👇 Check it out:\n${linkText}\n\n#Growth #New`;
    } else if (prompt.includes("professional LinkedIn-style")) {
      // Professional Logic
      generatedText = `I am pleased to share some updates regarding ${topic}.\n\nThis solution offers significant value by streamlining processes and enhancing efficiency. It represents a step forward in our commitment to excellence.\n\nIf you are looking to improve your workflow, I highly recommend exploring this further.\n\nLearn more here: ${linkText}`;
    } else {
      generatedText = `Here is the generated copy for: ${topic}\nLink: ${linkText}`;
    }

    return generatedText;
  };

  const handleGenerate = async () => {
    if (!topic.trim()) {
      toast({ title: "Topic Required", description: "Please enter what you are promoting.", variant: "destructive" });
      return;
    }

    setLoading(true);
    setOutputs({ shortDM: '', socialPost: '', professional: '' });

    try {
      const linkStr = shortLink ? shortLink : "[Link]";
      
      const prompts = {
        shortDM: `Generate a short, conversational direct message (1-2 lines) promoting ${topic}. Keep it friendly and non-spammy. ${shortLink ? `Include this link naturally: ${shortLink}` : ''} Focus on the key benefit in a casual tone.`,
        socialPost: `Generate an engaging social media post (5-8 lines) promoting ${topic}. Include a clear call-to-action. Use maximum 2 emojis. ${shortLink ? `Include this link naturally: ${shortLink}` : ''} Keep it authentic and non-spammy. Make it shareable and engaging.`,
        professional: `Generate a professional LinkedIn-style post (8-12 lines) promoting ${topic}. Use a persuasive, business-focused tone. Do NOT use emojis. ${shortLink ? `Include this link naturally: ${shortLink}` : ''} Focus on benefits, credibility, and value proposition. Keep it non-spammy and professional.`
      };

      // Generate all 3 in parallel
      const [dmResult, socialResult, proResult] = await Promise.all([
        generateWithAI(prompts.shortDM),
        generateWithAI(prompts.socialPost),
        generateWithAI(prompts.professional)
      ]);

      setOutputs({
        shortDM: dmResult,
        socialPost: socialResult,
        professional: proResult
      });

      toast({ title: "Success!", description: "Copy generated successfully." });
    } catch (error) {
      toast({ title: "Error", description: "Failed to generate copy. Please try again.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    toast({ 
      title: "Copied!", 
      description: "Text copied to clipboard.",
      action: <Check className="w-4 h-4 text-green-500" />
    });
  };

  const OutputSection = ({ title, icon: Icon, content, delay }) => (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="bg-white rounded-xl p-6 border border-gray-200 shadow-sm relative group"
    >
      <div className="flex items-center gap-2 mb-4 text-gray-900 font-bold border-b border-gray-100 pb-3">
        <Icon className="w-5 h-5 text-lc-tealdark" />
        <h3>{title}</h3>
      </div>
      
      <div className="min-h-[80px] text-gray-700 font-medium whitespace-pre-wrap leading-relaxed text-sm mb-4">
        {content || <span className="text-gray-300 italic">Waiting for generation...</span>}
      </div>

      <div className="flex justify-end">
        <button
          onClick={() => handleCopy(content)}
          disabled={!content}
          className="px-4 py-2 bg-lc-teal text-lc-graphite rounded-lg text-sm font-medium hover:bg-lc-tealdark transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
        >
          <Copy className="w-4 h-4" /> Copy
        </button>
      </div>
    </motion.div>
  );

  return (
    <>
      <Helmet><title>Copy Generator - LinkCascade</title></Helmet>
      <div className="p-6 md:p-8 max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Copy Generator</h1>
          <p className="text-gray-500 mt-2 text-sm font-medium">Create perfect messages for every platform in seconds.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Configuration Column */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-6">
              <div className="flex items-center gap-2 mb-6">
                <Settings2 className="w-5 h-5 text-lc-tealdark" />
                <h2 className="font-bold text-gray-900">Configuration</h2>
              </div>
              
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    What are you promoting? <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Target className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <textarea 
                      value={topic}
                      onChange={(e) => setTopic(e.target.value)}
                      placeholder="Example: LinkCascade Pro upgrade for $27/mo"
                      className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-lc-teal outline-none text-sm bg-gray-50/50 min-h-[100px] resize-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Short Link (optional)</label>
                  <div className="relative">
                    <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input 
                      type="text"
                      value={shortLink}
                      onChange={(e) => setShortLink(e.target.value)}
                      placeholder="Example: https://lc.app/abc123"
                      className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-lc-teal outline-none text-sm bg-gray-50/50"
                    />
                  </div>
                </div>

                <Button 
                  onClick={handleGenerate} 
                  disabled={loading}
                  className="w-full h-12 text-base shadow-md mt-4 bg-lc-teal hover:bg-lc-tealdark text-lc-graphite"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" /> Generate All Versions
                    </>
                  )}
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Output Column */}
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-7">
            <div className="space-y-6">
              {!outputs.shortDM && !loading ? (
                 <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center h-full flex flex-col justify-center items-center">
                    <div className="w-16 h-16 bg-lc-teal/10 rounded-full flex items-center justify-center mb-4">
                      <MessageSquare className="w-8 h-8 text-lc-teal" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">No copy generated yet</h3>
                    <p className="text-gray-500 max-w-sm mx-auto">Enter your topic and link on the left, then click Generate to create 3 unique variations.</p>
                 </div>
              ) : (
                <>
                  <OutputSection 
                    title="Short DM" 
                    icon={Smartphone} 
                    content={outputs.shortDM} 
                    delay={0.1}
                  />
                  
                  <OutputSection 
                    title="Social Post" 
                    icon={Share2} 
                    content={outputs.socialPost} 
                    delay={0.2} 
                  />
                  
                  <OutputSection 
                    title="Professional / LinkedIn" 
                    icon={Briefcase} 
                    content={outputs.professional} 
                    delay={0.3} 
                  />
                </>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default CopyGenerator;